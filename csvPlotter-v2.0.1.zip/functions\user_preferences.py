"""Helpers for saving and loading small user-specific GUI preferences."""

from __future__ import annotations

import json
from pathlib import Path


PREFERENCES_FILE_NAME = ".csvplotter_settings.json"
THEME_KEY = "theme"
DEFAULT_THEME_NAME = "light"


def get_preferences_file_path(root_dir: Path) -> Path:
    """Return the local file that stores settings for this unpacked copy."""
    return root_dir / PREFERENCES_FILE_NAME


def load_theme_preference(root_dir: Path) -> str:
    """Read the last selected theme and fall back safely when the file is missing."""
    preferences_file = get_preferences_file_path(root_dir)
    try:
        preferences = json.loads(preferences_file.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return DEFAULT_THEME_NAME
    except (OSError, json.JSONDecodeError):
        return DEFAULT_THEME_NAME

    theme_name = preferences.get(THEME_KEY, DEFAULT_THEME_NAME)
    if not isinstance(theme_name, str):
        return DEFAULT_THEME_NAME
    return theme_name


def save_theme_preference(root_dir: Path, theme_name: str) -> None:
    """Persist the selected theme so the next start can restore it automatically."""
    preferences_file = get_preferences_file_path(root_dir)
    preferences = {THEME_KEY: theme_name}
    preferences_file.write_text(
        json.dumps(preferences, indent=2, sort_keys=True),
        encoding="utf-8",
    )
