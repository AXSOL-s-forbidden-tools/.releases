# Funktions-Abhaengigkeiten

Dieses Dokument beschreibt, welche Dateien und Funktionen im Projekt
voneinander abhaengen und welche Aufgabe sie im Gesamtablauf haben.

## 1. Gesamtueberblick

Es gibt einen Einstiegspunkt:

- `main/csvPlotter.py`

`main/csvPlotter.py` startet die Desktop-Anwendung direkt.

## 2. Abhaengigkeiten der Einstiegspunkte

### `main/csvPlotter.py`

Verantwortung:

- stellt den benannten Startpunkt `csvPlotter` bereit
- startet die GUI-Anwendung direkt

Abhaengigkeiten:

```text
main/csvPlotter.py
 -> functions.dependencies.ensure_dependencies
 -> functions.csv_parser.open_csv_with_fallbacks
 -> functions.csv_parser.TIMESTAMP_COLUMN
 -> tkinter
 -> matplotlib
```

Wichtig:

- Der Plotter benutzt bewusst **nicht** direkt `functions.csv_parser.parse_csv`
  fuer alle Faelle.
- Grund: In der GUI kann die X-Achse frei gewaehlt werden.
- `parse_csv` aus `functions/csv_parser.py` bleibt ein spezialisierter
  Parser fuer strukturierte Datenreihen und erwartet immer `TimeStamp`
  als X-Achse.

## 3. Kernmodule im Ordner `functions`

### `functions/models.py`

Enthaelt die gemeinsamen Datenmodelle:

- `ParsedSeries`
- `ThresholdEvent`

Davon abhaengig:

```text
functions.models
 -> verwendet von csv_parser
```

### `functions/csv_parser.py`

Verantwortung:

- CSV-Datei mit geeigneter Textkodierung oeffnen
- APS/APU-Datenblock aus der Datei lesen
- Zeitstempel und numerische Werte in `ParsedSeries` umwandeln

Abhaengigkeiten:

```text
functions.csv_parser
 -> functions.models.ParsedSeries
```

### `functions/dependencies.py`

Verantwortung:

- fehlende Python-Pakete bei Bedarf nachinstallieren

Aktuell genutzt von:

```text
functions.dependencies
 -> verwendet von csvPlotter.py
```

## 4. Datenfluss

### Plot-Lauf in der GUI

```text
CSV-Datei
 -> csvPlotter._load_metadata
 -> csvPlotter._parse_structured_csv oder _parse_plain_csv
 -> csvPlotter._convert_x_values
 -> matplotlib-Plot im Fenster
```

## 5. Wartungshinweise

- Wenn sich das APS/APU-Dateiformat aendert, zuerst `functions/csv_parser.py`
  und die strukturierten Leser im Plotter pruefen.
- Wenn sich nur das Plot-Verhalten aendert, moeglichst
  `main/csvPlotter.py` oder die `functions/csv_plotter_*`-Module aendern,
  nicht den Parser.
- Wenn neue gemeinsame Daten gebraucht werden, zuerst pruefen, ob sie in
  `ParsedSeries` oder in einem neuen Dataclass-Modell sauberer aufgehoben sind.
