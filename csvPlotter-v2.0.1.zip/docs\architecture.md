# Architektur

Dieses Dokument beschreibt den groben Systemaufbau und den Datenfluss des Projekts.

## Zielbild

Das Projekt besteht aus einem Einstiegspunkt:

- `main/csvPlotter.py` als Startpunkt fuer die Desktop-Anwendung

Die eigentliche Fachlogik liegt moeglichst gesammelt im Ordner `functions/`.
Dadurch bleiben die Einstiegspunkte schlank und die Wiederverwendung wird einfacher.

## Modulaufbau

```mermaid
flowchart TD
  A[GUI] --> B[CSV einlesen]
  B --> C[Datenmodell und Metadaten]
  C --> D[GUI-Auswahl und Aufbereitung]
  D --> E[Interaktiver Plot im Fenster]
```

## Verantwortlichkeiten

- `main/`: startet die GUI und verbindet die einzelnen Verarbeitungsschritte
- `functions/csv_parser.py`: liest CSV-Dateien und baut daraus nutzbare Messreihen
- `main/csvPlotter.py` plus `functions/csv_plotter_*`: stellen die interaktive GUI bereit

## Datenfluss

### GUI fuer interaktives Plotten

```mermaid
flowchart LR
  A[CSV-Datei] --> B[Metadaten erkennen]
  B --> C[Spalten und X-Achse waehlen]
  C --> D[Datenreihen laden]
  D --> E[Matplotlib im Fenster]
```

## Strukturprinzip

- Gemeinsame Logik gehoert nach `functions/`, nicht mehrfach in einzelne Startdateien.
- Einstiegspunkte sollen moeglichst nur steuern, nicht selbst Fachlogik enthalten.
- Wenn einzelne Dateien zu gross werden, sollen neue Hilfsfunktionen in passende Module ausgelagert werden.
