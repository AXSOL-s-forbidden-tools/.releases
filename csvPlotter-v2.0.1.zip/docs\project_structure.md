# Projektstruktur

Diese Datei ist als schneller Einstieg fuer spaetere Wartung gedacht.

## Ordner

### `main/`

Einstiegspunkte fuer die direkt ausfuehrbaren Tools:

- `csvPlotter.py`: benannter Startpunkt fuer die Desktop-Anwendung

### `functions/`

Gemeinsame Logik fuer:

- CSV lesen
- GUI-Interaktionen
- GUI-Export
- GUI-Protokollierung

### `input/`

Beispiel- und Testdateien.

### `docs/`

Technische Dokumentation fuer Menschen, die das Projekt spaeter pflegen:

- `function_dependencies.md`: wer von wem abhaengt
- `project_structure.md`: schneller Einstieg in die Struktur

## Wichtigste Dateien

### `main/csvPlotter.py`

Startet die Desktop-Anwendung unter dem Produktnamen `csvPlotter`.

## Grundidee der Architektur

Die Kernlogik ist moeglichst in kleine Module zerlegt:

- Eingabe
- Parsen
- GUI-Zustand
- Interaktion
- Darstellen
- Exportieren

Der Vorteil ist, dass spaetere Aenderungen gezielter moeglich sind:

- neue GUI-Funktionen aendern meist nur die Einstiegspunkte oder GUI-Helfer
- neue Plot-Darstellung aendert meist nur den Plotter oder die GUI-Helfer
- neues CSV-Format betrifft meist zuerst Parser und Plotter-Metadaten
