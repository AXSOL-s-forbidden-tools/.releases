@echo off
setlocal
cd /d "%~dp0"

set "PYTHON_CMD="
set "APP_VERSION=unknown"

if exist "VERSION" (
    set /p APP_VERSION=<VERSION
)

where py >nul 2>nul
if not errorlevel 1 (
    set "PYTHON_CMD=py -3"
)

if not defined PYTHON_CMD (
    where python >nul 2>nul
    if not errorlevel 1 (
        set "PYTHON_CMD=python"
    )
)

if not defined PYTHON_CMD (
    echo Python was not found. Starting installation through winget...
    where winget >nul 2>nul
    if errorlevel 1 (
        echo winget was not found. Please install Python 3.10 or newer manually:
        echo https://www.python.org/downloads/windows/
        goto :error
    )

    winget install -e --id Python.Python.3.12
    if errorlevel 1 goto :error

    where py >nul 2>nul
    if not errorlevel 1 (
        set "PYTHON_CMD=py -3"
    )
)

if not defined PYTHON_CMD (
    where python >nul 2>nul
    if not errorlevel 1 (
        set "PYTHON_CMD=python"
    )
)

if not defined PYTHON_CMD (
    echo Python was installed, but it is not available in PATH for this terminal yet.
    echo Please close this window and run start_csvPlotter.bat again.
    goto :error
)

if not exist ".venv" (
    %PYTHON_CMD% -m venv .venv
    if errorlevel 1 goto :error
)

if not exist ".venv\Scripts\python.exe" (
    echo The virtual Python environment could not be created correctly.
    echo Expected file is missing: .venv\Scripts\python.exe
    goto :error
)

echo csvPlotter version: %APP_VERSION%

set "VENV_PYTHON=.venv\Scripts\python.exe"
set "VENV_PYTHONW=.venv\Scripts\pythonw.exe"

%VENV_PYTHON% -m pip install --upgrade pip
if errorlevel 1 goto :error

%VENV_PYTHON% -m pip install -r requirements.txt
if errorlevel 1 goto :error

if not exist "%VENV_PYTHONW%" (
    echo pythonw.exe was not found in the virtual environment.
    goto :error
)

start "" "%VENV_PYTHONW%" "main\csvPlotter.py"
if errorlevel 1 goto :error

exit /b 0

:error
echo.
echo Error while starting csvPlotter. Please review the output above.
pause
exit /b 1
