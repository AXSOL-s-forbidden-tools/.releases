"""Shared helper package for the csvPlotter project."""
