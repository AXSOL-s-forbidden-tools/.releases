# csvPlotter

`csvPlotter` is a small Python project for analyzing CSV log files through a desktop GUI. The project can load selected datasets, render interactive plots, and export filtered plot data.

## Features

- Install missing runtime packages automatically on first start
- Use the interactive GUI for file, axis, and column selection
- Detect the GUI CSV delimiter automatically on file load
- Override the detected GUI CSV delimiter manually through a dropdown: `;`, `,`, or `Tab (text export)`
- Review technical project documentation in `docs/`

## Requirements

- Python 3.10 or newer
- `pip` available in the active Python environment

## Versioning

The project version is stored centrally in [VERSION](VERSION). The same version number is used by both the GUI and `start_csvPlotter.bat`, so you can verify the current build in the window title or in the batch launcher output.

Release packages are created in `release/`. This folder is treated as a local build artifact directory and is not tracked by Git.

To create and optionally publish a GitHub release, run:

```powershell
.\release\publish_release.ps1
```

To create only the local ZIP package without publishing to GitHub, run:

```powershell
.\release\publish_release.ps1 -SkipGitHubRelease
```

The release package always includes the required project folders `docs/`, `functions/`, `icons/`, and `main/`.

The GUI stores the last selected `Light Mode` or `Dark Mode` in a small local settings file and restores that choice automatically on the next start.

## Documentation

Additional project documentation for maintenance and onboarding:

- [Project structure](docs/project_structure.md)
- [Function dependencies](docs/function_dependencies.md)
- [Architecture](docs/architecture.md)
- [Local development](docs/development.md)
- [Architecture decisions](docs/decisions/adr-001-projektstruktur.md)
- [Manifest: work instructions](manifest/instructions.md)
- [Manifest: dependencies](manifest/dependencies.md)

## Usage

### Interactive plotter

Start the desktop GUI:

```powershell
python .\main\csvPlotter.py
```

`main\csvPlotter.py` is the single GUI start file for the application.

Or on Windows:

```powershell
.\start_csvPlotter.bat
```

The batch launcher creates a local virtual environment in `.\.venv` on first start and then runs the GUI directly with that interpreter. The console window closes automatically after the application starts successfully. Errors during setup and dependency checks remain visible in the console window. While the GUI is running, messages and errors are written to timestamped files in `.\log`. At startup, the GUI also removes log files older than 30 days. The current project version is printed briefly in the console and shown in the window title.

The GUI provides:

- true multi-window behavior inside one Tk process
- a new plotter window through `Datei > Neues Fenster`
- file selection for arbitrary CSV files
- drag and drop directly onto the plotter window
- support for the existing APS/APU multi-block format
- support for regular CSV files with a single header row
- support for regular CSV files that contain a few metadata lines before the actual header row
- automatic timestamp column detection for standard CSV files
- automatic delimiter detection for standard CSV files and APS/APU exports
- selectable X-axis values for all CSV files: row number or any CSV column
- `Record Type` and `System` selection for APS/APU files
- selection of available numeric columns
- an interactive plot with toolbar actions for zoom, pan, reset, and save
- mouse wheel zoom centered on the current cursor position
- panning with the middle mouse button
- point picking with a left click, including marker, tooltip, and status text
- a dedicated datapicker icon button placed directly next to the zoom tool to enable or disable point picking explicitly
- disabling the datapicker clears all visible datapicks immediately
- multi-point picking with `CTRL` + left click to add or remove individual datapicks
- draggable datapick text boxes with free positioning
- right click on a datapick text box to switch through preset positions
- automatic X and Y difference display in the status bar when exactly two datapicks are active
- stable plot redraw even when a point marker already exists
- CSV export of the currently plotted data through `Datei > Export`
- light and dark themes through `Ansicht`
- an optional extra toolbar icon button next to the datapicker icon to show or hide a per-signal `min` / `max` legend for the current visible plot section
- an additional toolbar icon button next to the `min` / `max` legend toggle that marks the visible `min` / `max` points directly in the graph
- tooltips on the datapicker, Min/Max legend, and Min/Max marker toolbar icons for quick identification
- cached plot coordinates keep visible-range Min/Max updates responsive even on larger datasets
- mouse-wheel zoom is committed in short bursts, which reduces redraw and history overhead during rapid scrolling
- datapicker hit-testing is limited to the visible X range and uses vectorized screen-distance checks for faster point selection
- draggable plot legends, including the optional `min` / `max` legend
- log files with information and error messages in `log`
- automatic cleanup of GUI log files older than 30 days

If you need several plotters in parallel, open them through `Datei > Neues Fenster`. Each window keeps its own plot, zoom, and selection state while still sharing one process.

Plot interaction:

- `Mouse wheel`: zooms around the current pointer position regardless of the toolbar mode
- `Middle mouse button drag`: moves the visible plot area
- `Datapicker` icon toggle directly next to the zoom tool: enables or disables point picking explicitly
- `Min/Max` icon toggle directly next to the datapicker icon: shows or hides the extra legend for the current visible plot section
- `Min/Max marker` icon toggle directly next to the `Min/Max` legend icon: marks the visible `min` and `max` points of each plotted signal in the graph
- `Mouse wheel`, drag pan, or rectangle zoom: updates Min/Max only after the view has settled, not during every intermediate zoom step
- `Left click` with active datapicker: replaces the current datapick selection with the nearest data point
- `CTRL` + `Left click` with active datapicker: adds the nearest data point to the active datapicks or removes it when it is already selected
- `Left click` on an already selected single datapick: removes that datapick
- `Left click and drag` on a datapick text box: moves that text box freely
- `Right click` on a datapick text box: switches that text box to the next preset position
- `Status bar with exactly two datapicks`: shows `Delta X` and `Delta Y` for the two active points
- `Drag` a legend with the mouse: repositions the regular signal legend or the optional `Min / Max` legend
- `Toolbar`: provides Matplotlib standard actions such as Home, Back, Forward, Zoom, Pan, and Save

GUI CSV export:

- `Datei > Export > Gesamten Plot exportieren`: exports all currently plotted points
- `Datei > Export > Sichtbaren Ausschnitt exportieren`: exports only points inside the visible X and Y axis range
- The exported CSV contains the current X-axis as the first column, followed by all plotted Y columns

For standard CSV files:

- the first row is interpreted as the header
- plottable columns are detected from numeric values
- detected timestamp columns may be named `timestamp`, `time`, `datetime`, `date`, `Datum`, or `Zeit`
- the X-axis can be set to `Zeilennummer`, a timestamp column, a numeric column, or a text column
- the delimiter is detected automatically when the file is loaded
- the detected delimiter can still be changed manually in the GUI to `Semicolon (;)`, `Comma (,)`, or `Tab (text export)`

For APS/APU files:

- `Record Type` and `System` still select the logical data block
- the X-axis can be set to `Zeilennummer`, `TimeStamp`, or any column of the selected record type

## Scope

This project is GUI-only. CLI-based plot generation and threshold search are no longer part of the supported workflow.
