#!/usr/bin/env python3
"""Interactive CSV plotter with column selection and zoomable charts."""

from __future__ import annotations

import csv
from bisect import bisect_left, bisect_right
from datetime import datetime
from pathlib import Path
import sys
import traceback

import numpy as np
ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from functions.csv_parser import TIMESTAMP_COLUMN, open_csv_with_fallbacks
from functions.dependencies import ensure_dependencies, ensure_package

ensure_dependencies()
ensure_package("tkinterdnd2")

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
except ImportError as exc:
    raise SystemExit(
        "Missing dependency: tkinter. Install Python with Tcl/Tk support to run csvPlotter.py."
    ) from exc

try:
    from tkinterdnd2 import DND_FILES, TkinterDnD  # noqa: E402
except ImportError:
    DND_FILES = None
    TkinterDnD = None

from matplotlib.backends._backend_tk import add_tooltip  # noqa: E402
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk  # noqa: E402
from matplotlib import dates as mdates  # noqa: E402
from matplotlib.figure import Figure  # noqa: E402
from matplotlib.legend import Legend  # noqa: E402
from PIL import Image, ImageTk  # noqa: E402
from functions.csv_plotter_export import get_export_row_indices, write_plot_export  # noqa: E402
from functions.csv_plotter_interactions import (  # noqa: E402
    find_nearest_point,
    is_control_modifier_active,
    is_left_mouse_button,
    is_middle_mouse_button,
    is_right_mouse_button,
    pan_axes_from_drag,
    zoom_axes_around_cursor,
)
from functions.csv_plotter_logging import configure_csv_plotter_logging, log_exception  # noqa: E402
from functions.csv_plotter_utils import (  # noqa: E402
    XValue,
    convert_x_values,
    detect_csv_delimiter,
    detect_timestamp_column,
    format_x_difference,
    format_x_value,
    get_row_value,
    is_float_row_value,
    normalize_header,
    split_plain_csv_header_and_rows,
)
from functions.csv_plotter_theme import THEMES  # noqa: E402
from functions.user_preferences import load_theme_preference, save_theme_preference  # noqa: E402
from functions.version_utils import read_project_version  # noqa: E402


APP_VERSION = read_project_version(ROOT_DIR)
LOGGER, LOG_FILE_PATH = configure_csv_plotter_logging(ROOT_DIR)
LOGGER.info("CSV-Plotter-Protokollierung gestartet. Version: %s | Log-Datei: %s", APP_VERSION, LOG_FILE_PATH)

PickedPointKey = tuple[str, int]
PickerOffset = tuple[float, float]
PICKER_OFFSET_CYCLE: tuple[PickerOffset, ...] = (
    (12.0, 12.0),
    (12.0, -12.0),
    (-12.0, 12.0),
    (-12.0, -12.0),
    (24.0, 0.0),
    (-24.0, 0.0),
    (0.0, 24.0),
    (0.0, -24.0),
)

DELIMITER_OPTIONS: tuple[tuple[str, str], ...] = (
    ("Semicolon (;)", ";"),
    ("Comma (,)", ","),
    ("Tab (text export)", "\t"),
)
DELIMITER_LABEL_TO_VALUE = {label: value for label, value in DELIMITER_OPTIONS}
DELIMITER_VALUE_TO_LABEL = {value: label for label, value in DELIMITER_OPTIONS}
ICON_BUTTON_SIZE = 18
MIN_MAX_REFRESH_DELAY_MS = 350
WHEEL_ZOOM_COMMIT_DELAY_MS = 180


def handle_unexpected_exception(
    exc_type: type[BaseException],
    exc_value: BaseException,
    exc_traceback: object,
) -> None:
    """Protokolliert ungefangene Prozessfehler in die Log-Datei."""
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_traceback)
        return
    LOGGER.error(
        "Unbehandelter Prozessfehler\n%s",
        "".join(traceback.format_exception(exc_type, exc_value, exc_traceback)),
    )


class CsvPlotterManager:
    """Verwaltet mehrere Plotter-Fenster innerhalb eines einzigen Tk-Prozesses."""

    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.windows: list[CsvPlotterApp] = []
        self.root.withdraw()
        self.root.report_callback_exception = self._handle_tk_exception
        LOGGER.info("Fensterverwaltung initialisiert.")

    def open_new_window(self) -> "CsvPlotterApp":
        """Erzeugt ein neues, komplett eigenstaendiges Plotter-Fenster."""
        window = tk.Toplevel(self.root)
        app = CsvPlotterApp(window, manager=self)
        self.windows.append(app)
        LOGGER.info("Neues Plotter-Fenster geoeffnet. Aktive Fenster: %s", len(self.windows))
        return app

    def close_window(self, app: "CsvPlotterApp") -> None:
        """Schliesst den Prozess automatisch, wenn das letzte Fenster weg ist."""
        if app in self.windows:
            self.windows.remove(app)
            LOGGER.info("Plotter-Fenster geschlossen. Verbleibende Fenster: %s", len(self.windows))
        if not self.windows:
            LOGGER.info("Letztes Plotter-Fenster geschlossen. Anwendung wird beendet.")
            self.root.quit()
            self.root.destroy()

    def _handle_tk_exception(
        self,
        exc_type: type[BaseException],
        exc_value: BaseException,
        exc_traceback: object,
    ) -> None:
        """Faengt Tk-Callback-Fehler ab und schreibt sie in die Log-Datei."""
        LOGGER.error(
            "Unbehandelter Tk-Fehler\n%s",
            "".join(traceback.format_exception(exc_type, exc_value, exc_traceback)),
        )
        messagebox.showerror(
            "Unerwarteter Fehler",
            f"Der Plotter hat einen Fehler protokolliert.\nLog-Datei: {LOG_FILE_PATH}",
        )


class DatapickerNavigationToolbar(NavigationToolbar2Tk):
    """Toolbar extension that embeds the datapicker toggle next to the zoom tool."""

    def __init__(self, canvas: FigureCanvasTkAgg, window: tk.Misc, app: "CsvPlotterApp") -> None:
        self.app = app
        self._custom_button_images: list[ImageTk.PhotoImage] = []
        super().__init__(canvas, window, pack_toolbar=False)
        self.datapicker_button = self._create_icon_toggle_button(
            image_path=ROOT_DIR / "icons" / "datapicker.jpg",
            command=self._on_datapicker_button_pressed,
            tooltip_text="Datapicker aktivieren oder deaktivieren",
        )
        zoom_button = self._buttons.get("Zoom")
        if zoom_button is not None:
            self.datapicker_button.pack_configure(after=zoom_button)
        self.min_max_button = self._create_icon_toggle_button(
            image_path=ROOT_DIR / "icons" / "minmax.png",
            command=self._on_min_max_button_pressed,
            tooltip_text="Min/Max-Legende fuer den sichtbaren Ausschnitt anzeigen oder ausblenden",
        )
        if zoom_button is not None:
            self.min_max_button.pack_configure(after=self.datapicker_button)
        self.min_max_marker_button = self._create_icon_toggle_button(
            image_path=ROOT_DIR / "icons" / "minmaxcursor.png",
            command=self._on_min_max_marker_button_pressed,
            tooltip_text="Min/Max-Markierungen im sichtbaren Ausschnitt anzeigen oder ausblenden",
        )
        if zoom_button is not None:
            self.min_max_marker_button.pack_configure(after=self.min_max_button)
        self._sync_datapicker_button()
        self._sync_min_max_button()
        self._sync_min_max_marker_button()

    def pan(self, *args: object) -> None:
        """Disable datapicking when pan mode becomes active."""
        super().pan(*args)
        if self.mode:
            self.app._set_datapicker_mode(False, status_message=None)

    def zoom(self, *args: object) -> None:
        """Disable datapicking when zoom mode becomes active."""
        super().zoom(*args)
        if self.mode:
            self.app._set_datapicker_mode(False, status_message=None)

    def home(self, *args: object) -> None:
        """Refresh the visible-range legend after restoring the original view."""
        super().home(*args)
        self.app._schedule_min_max_legend_refresh()

    def back(self, *args: object) -> None:
        """Refresh the visible-range legend after navigating back in view history."""
        super().back(*args)
        self.app._schedule_min_max_legend_refresh()

    def forward(self, *args: object) -> None:
        """Refresh the visible-range legend after navigating forward in view history."""
        super().forward(*args)
        self.app._schedule_min_max_legend_refresh()

    def release_zoom(self, event: object) -> None:
        """Refresh the visible-range legend after rectangle zoom finishes."""
        super().release_zoom(event)
        self.app._schedule_min_max_legend_refresh()

    def release_pan(self, event: object) -> None:
        """Refresh the visible-range legend after toolbar pan finishes."""
        super().release_pan(event)
        self.app._schedule_min_max_legend_refresh()

    def _on_datapicker_button_pressed(self) -> None:
        """Mirror the toolbar toggle state into the application state."""
        self.app._set_datapicker_mode(bool(self.datapicker_button.var.get()))

    def _on_min_max_button_pressed(self) -> None:
        """Mirror the toolbar toggle state into the Min/Max legend visibility."""
        self.app._set_min_max_legend_visibility(bool(self.min_max_button.var.get()))

    def _on_min_max_marker_button_pressed(self) -> None:
        """Mirror the toolbar toggle state into the Min/Max marker visibility."""
        self.app._set_min_max_marker_visibility(bool(self.min_max_marker_button.var.get()))

    def _sync_datapicker_button(self) -> None:
        """Keep the visual toggle state aligned with the application mode."""
        if self.app.datapicker_mode_var.get():
            self.datapicker_button.select()
            return
        self.datapicker_button.deselect()

    def _sync_min_max_button(self) -> None:
        """Keep the visual toggle state aligned with the Min/Max legend state."""
        if self.app.show_min_max_legend_var.get():
            self.min_max_button.select()
            return
        self.min_max_button.deselect()

    def _sync_min_max_marker_button(self) -> None:
        """Keep the visual toggle state aligned with the Min/Max marker state."""
        if self.app.show_min_max_markers_var.get():
            self.min_max_marker_button.select()
            return
        self.min_max_marker_button.deselect()

    def _create_icon_toggle_button(
        self,
        image_path: Path,
        command: object,
        tooltip_text: str,
    ) -> tk.Checkbutton:
        """Create a toolbar toggle button that displays only a custom icon."""
        button = self._Button("", None, True, command)
        button.configure(text="", padx=0, pady=0)
        button_image = self._load_toolbar_icon(image_path)
        button.configure(image=button_image, selectimage=button_image)
        button._ntimage = button_image
        button._ntimage_alt = button_image
        add_tooltip(button, tooltip_text)
        self._custom_button_images.append(button_image)
        return button

    def _load_toolbar_icon(self, image_path: Path) -> ImageTk.PhotoImage:
        """Load and normalize one toolbar icon from the project icons directory."""
        with Image.open(image_path) as source_image:
            icon_image = source_image.convert("RGBA")
            # Bright backgrounds are made transparent so the icon sits naturally
            # inside the existing Matplotlib toolbar button chrome.
            normalized_pixels: list[tuple[int, int, int, int]] = []
            for red, green, blue, alpha in icon_image.getdata():
                if red >= 245 and green >= 245 and blue >= 245:
                    normalized_pixels.append((red, green, blue, 0))
                else:
                    normalized_pixels.append((red, green, blue, alpha))
            icon_image.putdata(normalized_pixels)
            icon_image = icon_image.resize((ICON_BUTTON_SIZE, ICON_BUTTON_SIZE), Image.LANCZOS)
            return ImageTk.PhotoImage(icon_image, master=self)


class CsvPlotterApp:
    """Desktop UI for selecting CSV columns and plotting them interactively.

    The UI supports two file structures:

    - APS/APU exports with multiple logical tables in one file
    - regular CSV files with one header row

    Both end up in the same plotting path: choose X-axis values, choose
    numeric Y columns, then render the selected series.
    """

    ROW_INDEX_LABEL = "Zeilennummer"

    def __init__(self, root: tk.Misc, manager: CsvPlotterManager) -> None:
        self.root = root
        self.manager = manager
        self.root.title(f"csvPlotter {APP_VERSION}")
        self.root.geometry("1400x900")
        self.root.protocol("WM_DELETE_WINDOW", self.close_window)
        LOGGER.info("Plotter-Fenster aufgebaut. Version: %s", APP_VERSION)

        self.csv_path: Path | None = None
        self.csv_mode = "structured"
        self.timestamp_column: str | None = None
        self.plain_columns: list[str] = []
        self.record_columns: dict[str, list[str]] = {}
        self.record_systems: dict[str, list[str]] = {}
        self.numeric_columns: dict[tuple[str, str], list[str]] = {}

        self.file_var = tk.StringVar(value="Keine CSV geladen")
        self.delimiter_label_var = tk.StringVar(value=DELIMITER_OPTIONS[0][0])
        self.record_type_var = tk.StringVar()
        self.system_name_var = tk.StringVar()
        self.x_axis_var = tk.StringVar(value="Datum + Zeit")
        self.status_var = tk.StringVar(value="CSV laden, dann Record Type, System und Spalten waehlen.")
        self.datapicker_mode_var = tk.BooleanVar(value=False)
        self.show_min_max_legend_var = tk.BooleanVar(value=False)
        self.show_min_max_markers_var = tk.BooleanVar(value=False)
        self.has_plot = False
        stored_theme_name = load_theme_preference(ROOT_DIR)
        self.theme_name = stored_theme_name if stored_theme_name in THEMES else "light"
        self.drop_label: ttk.Label | None = None
        self.picked_points: dict[PickedPointKey, dict[str, object]] = {}
        self.current_plot_columns: list[str] = []
        self.current_x_values: list[XValue] = []
        self.current_x_plot_values: list[float] = []
        self.current_x_plot_array = np.array([], dtype=float)
        self.current_x_plot_values_are_sorted = False
        self.current_series_map: dict[str, list[float]] = {}
        self.current_series_arrays: dict[str, np.ndarray] = {}
        self.current_x_label = "X"
        self.middle_pan_start: tuple[float, float, tuple[float, float], tuple[float, float]] | None = None
        self.dragged_picker_key: PickedPointKey | None = None
        self.series_legend: Legend | None = None
        self.min_max_legend: Legend | None = None
        self.min_max_marker_artists: list[object] = []
        self.min_max_refresh_after_id: str | None = None
        self.wheel_zoom_commit_after_id: str | None = None
        self.axes_xlim_callback_id: int | None = None
        self.axes_ylim_callback_id: int | None = None

        self._build_menu()
        self._configure_styles()
        self._build_ui()
        self._apply_theme_to_widgets()

    def _build_menu(self) -> None:
        """Create the application menu."""
        menu_bar = tk.Menu(self.root)

        datei_menu = tk.Menu(menu_bar, tearoff=False)
        datei_menu.add_command(label="Neues Fenster", command=self.manager.open_new_window)
        datei_menu.add_separator()
        export_menu = tk.Menu(datei_menu, tearoff=False)
        export_menu.add_command(label="Gesamten Plot exportieren", command=lambda: self.export_current_plot("all"))
        export_menu.add_command(
            label="Sichtbaren Ausschnitt exportieren",
            command=lambda: self.export_current_plot("visible"),
        )
        datei_menu.add_cascade(label="Export", menu=export_menu)
        datei_menu.add_separator()
        datei_menu.add_command(label="Fenster schliessen", command=self.close_window)
        menu_bar.add_cascade(label="Datei", menu=datei_menu)

        ansicht_menu = tk.Menu(menu_bar, tearoff=False)
        ansicht_menu.add_command(label="Dark Mode", command=lambda: self.set_theme("dark"))
        ansicht_menu.add_command(label="Light Mode", command=lambda: self.set_theme("light"))
        menu_bar.add_cascade(label="Ansicht", menu=ansicht_menu)

        hilfe_menu = tk.Menu(menu_bar, tearoff=False)
        hilfe_menu.add_command(label=f"Version: {APP_VERSION}", state="disabled")
        menu_bar.add_cascade(label="Hilfe", menu=hilfe_menu)
        self.root.config(menu=menu_bar)

    def _configure_styles(self) -> None:
        """Apply a dark ttk theme palette."""
        colors = THEMES[self.theme_name]
        self.root.configure(bg=colors["bg"])
        style = ttk.Style(self.root)
        style.theme_use("clam")

        style.configure(".", background=colors["bg"], foreground=colors["text"])
        style.configure("TFrame", background=colors["bg"])
        style.configure("Panel.TFrame", background=colors["panel"])
        style.configure("TLabel", background=colors["bg"], foreground=colors["text"])
        style.configure("Panel.TLabel", background=colors["panel"], foreground=colors["text"])
        style.configure(
            "TButton",
            background=colors["accent"],
            foreground=colors["text"],
            borderwidth=0,
            focusthickness=0,
            padding=6,
        )
        style.map(
            "TButton",
            background=[("active", colors["button_active"]), ("pressed", colors["button_pressed"])],
            foreground=[("disabled", "#7f7f7f")],
        )
        style.configure(
            "TEntry",
            fieldbackground=colors["input"],
            foreground=colors["text"],
            insertcolor=colors["text"],
        )
        style.configure(
            "TCombobox",
            fieldbackground=colors["input"],
            background=colors["input"],
            foreground=colors["text"],
            arrowcolor=colors["text"],
        )
        style.map(
            "TCombobox",
            fieldbackground=[("readonly", colors["input"])],
            foreground=[("readonly", colors["text"])],
            background=[("readonly", colors["input"])],
        )
        style.configure(
            "Status.TLabel",
            background=colors["input"],
            foreground=colors["muted_text"],
            padding=6,
        )

    def _build_ui(self) -> None:
        main = ttk.Frame(self.root, padding=12)
        main.pack(fill=tk.BOTH, expand=True)
        main.columnconfigure(0, weight=0)
        main.columnconfigure(1, weight=1)
        main.rowconfigure(0, weight=1)

        controls = ttk.Frame(main, padding=(0, 0, 12, 0), style="Panel.TFrame")
        controls.grid(row=0, column=0, sticky="ns")
        controls.columnconfigure(0, weight=1)

        ttk.Label(controls, text="CSV-Datei", font=("Segoe UI", 10, "bold"), style="Panel.TLabel").grid(
            row=0, column=0, sticky="w"
        )
        ttk.Button(controls, text="Datei oeffnen", command=self.open_file).grid(
            row=1, column=0, sticky="ew", pady=(4, 8)
        )
        ttk.Label(
            controls,
            textvariable=self.file_var,
            wraplength=320,
            justify=tk.LEFT,
            style="Panel.TLabel",
        ).grid(row=2, column=0, sticky="w")

        self.drop_label = ttk.Label(
            controls,
            text="CSV hier ins Fenster ziehen oder ueber 'Datei oeffnen' laden.",
            wraplength=320,
            justify=tk.LEFT,
            style="Panel.TLabel",
        )
        self.drop_label.grid(row=3, column=0, sticky="ew", pady=(12, 0))

        ttk.Label(controls, text="Trennzeichen", style="Panel.TLabel").grid(row=4, column=0, sticky="w", pady=(16, 0))
        self.delimiter_box = ttk.Combobox(
            controls,
            textvariable=self.delimiter_label_var,
            state="readonly",
            values=[label for label, _ in DELIMITER_OPTIONS],
            width=18,
        )
        self.delimiter_box.grid(row=5, column=0, sticky="w", pady=(4, 0))

        ttk.Label(controls, text="Record Type", style="Panel.TLabel").grid(row=6, column=0, sticky="w", pady=(16, 0))
        self.record_type_box = ttk.Combobox(
            controls,
            textvariable=self.record_type_var,
            state="readonly",
            width=38,
        )
        self.record_type_box.grid(row=7, column=0, sticky="ew", pady=(4, 0))
        self.record_type_box.bind("<<ComboboxSelected>>", self.on_record_type_changed)

        ttk.Label(controls, text="System", style="Panel.TLabel").grid(row=8, column=0, sticky="w", pady=(16, 0))
        self.system_box = ttk.Combobox(
            controls,
            textvariable=self.system_name_var,
            state="readonly",
            width=38,
        )
        self.system_box.grid(row=9, column=0, sticky="ew", pady=(4, 0))
        self.system_box.bind("<<ComboboxSelected>>", self.on_system_changed)

        ttk.Label(controls, text="X-Achse", style="Panel.TLabel").grid(row=10, column=0, sticky="w", pady=(16, 0))
        self.x_axis_box = ttk.Combobox(
            controls,
            textvariable=self.x_axis_var,
            state="readonly",
            width=38,
        )
        self.x_axis_box.grid(row=11, column=0, sticky="ew", pady=(4, 0))

        ttk.Label(controls, text="Spalten", style="Panel.TLabel").grid(row=12, column=0, sticky="w", pady=(16, 0))
        list_frame = ttk.Frame(controls, style="Panel.TFrame")
        list_frame.grid(row=13, column=0, sticky="nsew", pady=(4, 0))
        controls.rowconfigure(13, weight=1)
        list_frame.rowconfigure(0, weight=1)
        list_frame.columnconfigure(0, weight=1)

        self.column_list = tk.Listbox(
            list_frame,
            selectmode=tk.EXTENDED,
            exportselection=False,
            width=42,
            height=24,
            highlightthickness=0,
            borderwidth=0,
        )
        self.column_list.grid(row=0, column=0, sticky="nsew")
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.column_list.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.column_list.configure(yscrollcommand=scrollbar.set)

        button_row = ttk.Frame(controls)
        button_row.grid(row=14, column=0, sticky="ew", pady=(12, 0))
        button_row.columnconfigure(0, weight=1)
        button_row.columnconfigure(1, weight=1)
        ttk.Button(button_row, text="Alle waehlen", command=self.select_all_columns).grid(
            row=0, column=0, sticky="ew", padx=(0, 4)
        )
        ttk.Button(button_row, text="Auswahl loeschen", command=self.clear_column_selection).grid(
            row=0, column=1, sticky="ew", padx=(4, 0)
        )

        ttk.Button(controls, text="Plot anzeigen", command=self.plot_selected_columns).grid(
            row=15, column=0, sticky="ew", pady=(12, 0)
        )
        ttk.Label(
            controls,
            text="Datapicks, Min/Max-Legende und Min/Max-Markierungen werden ueber die Symbol-Buttons neben der Lupe gesteuert. CTRL + Linksklick fuegt weitere Picks hinzu. Datapick-Textboxen koennen mit der Maus verschoben werden.",
            wraplength=320,
            justify=tk.LEFT,
            style="Panel.TLabel",
        ).grid(row=16, column=0, sticky="w", pady=(12, 0))

        plot_frame = ttk.Frame(main)
        plot_frame.grid(row=0, column=1, sticky="nsew")
        plot_frame.rowconfigure(0, weight=1)
        plot_frame.columnconfigure(0, weight=1)

        self.figure = Figure(figsize=(10, 7), dpi=100)
        self.axes = self.figure.add_subplot(111)
        self._style_axes()
        self.axes.set_title("Noch kein Plot geladen")
        self.axes.set_xlabel("Datum + Zeit")
        self.axes.set_ylabel("Wert")

        self.canvas = FigureCanvasTkAgg(self.figure, master=plot_frame)
        self.canvas.get_tk_widget().grid(row=0, column=0, sticky="nsew")
        self.canvas.get_tk_widget().configure(highlightthickness=0)
        self.canvas.mpl_connect("button_press_event", self._on_plot_button_press)
        self.canvas.mpl_connect("scroll_event", self._on_mousewheel_zoom)
        self.canvas.mpl_connect("motion_notify_event", self._on_plot_motion)
        self.canvas.mpl_connect("button_release_event", self._on_plot_button_release)
        self._connect_axes_limit_callbacks()

        toolbar_frame = ttk.Frame(plot_frame)
        toolbar_frame.grid(row=1, column=0, sticky="ew")

        self.toolbar = DatapickerNavigationToolbar(self.canvas, toolbar_frame, app=self)
        self.toolbar.update()
        self.toolbar.pack(fill=tk.X)

        status_bar = ttk.Label(main, textvariable=self.status_var, anchor="w", style="Status.TLabel")
        status_bar.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(8, 0))

        self._enable_drag_and_drop(main, controls, plot_frame, self.canvas.get_tk_widget(), status_bar)

    def _enable_drag_and_drop(self, *widgets: tk.Widget) -> None:
        """Enable dropping CSV files onto the application window."""
        if DND_FILES is None:
            self.status_var.set("Drag & Drop nicht verfuegbar. tkinterdnd2 konnte nicht geladen werden.")
            return

        for widget in widgets:
            widget.drop_target_register(DND_FILES)
            widget.dnd_bind("<<Drop>>", self._on_file_dropped)

    def _connect_axes_limit_callbacks(self) -> None:
        """Attach limit-change listeners that drive the visible-range Min/Max refresh."""
        if self.axes_xlim_callback_id is not None:
            self.axes.callbacks.disconnect(self.axes_xlim_callback_id)
        if self.axes_ylim_callback_id is not None:
            self.axes.callbacks.disconnect(self.axes_ylim_callback_id)
        self.axes_xlim_callback_id = self.axes.callbacks.connect("xlim_changed", self._on_axes_limits_changed)
        self.axes_ylim_callback_id = self.axes.callbacks.connect("ylim_changed", self._on_axes_limits_changed)

    def _on_file_dropped(self, event: object) -> None:
        """Load the first dropped CSV file."""
        dropped_files = self.root.tk.splitlist(event.data)
        if not dropped_files:
            return
        self.load_csv_path(dropped_files[0])

    def close_window(self) -> None:
        """Schliesst nur dieses Fenster und laesst andere Instanzen weiterlaufen."""
        self.root.destroy()
        self.manager.close_window(self)

    def _style_axes(self) -> None:
        """Apply the dark plot palette to the current axes."""
        colors = THEMES[self.theme_name]
        self.figure.set_facecolor(colors["plot_bg"])
        self.axes.set_facecolor(colors["plot_bg"])
        self.axes.grid(True, color=colors["grid"], alpha=0.35)
        self.axes.tick_params(axis="x", colors=colors["axis"])
        self.axes.tick_params(axis="y", colors=colors["axis"])
        self.axes.xaxis.label.set_color(colors["axis"])
        self.axes.yaxis.label.set_color(colors["axis"])
        self.axes.title.set_color(colors["text"])
        for spine in self.axes.spines.values():
            spine.set_color(colors["grid"])

    def _apply_theme_to_widgets(self) -> None:
        """Apply theme colors to non-ttk widgets and the plot canvas."""
        colors = THEMES[self.theme_name]
        self.column_list.configure(
            bg=colors["input"],
            fg=colors["text"],
            selectbackground=colors["accent"],
            selectforeground=colors["text"],
        )
        self.canvas.get_tk_widget().configure(bg=colors["plot_bg"])
        self._style_picker_artists()

    def set_theme(self, theme_name: str) -> None:
        """Switch between light and dark UI themes."""
        if theme_name not in THEMES or theme_name == self.theme_name:
            return
        self.theme_name = theme_name
        save_theme_preference(ROOT_DIR, self.theme_name)
        self._configure_styles()
        self._apply_theme_to_widgets()
        self._style_axes()
        self._style_plot_legends()
        if self._needs_min_max_refresh():
            self._refresh_min_max_overlays()
        self.canvas.draw_idle()
        self.status_var.set(f"Darstellung auf {theme_name} Modus umgestellt.")

    def _style_picker_artists(self) -> None:
        """Update picker annotation and marker colors to match the current theme."""
        colors = THEMES[self.theme_name]
        for picked_point in self.picked_points.values():
            annotation = picked_point["annotation"]
            marker = picked_point["marker"]
            annotation.get_bbox_patch().set_facecolor(colors["input"])
            annotation.get_bbox_patch().set_edgecolor(colors["grid"])
            annotation.get_bbox_patch().set_alpha(0.95)
            # Matplotlib exposes the arrow patch differently across versions.
            arrow_patch = getattr(annotation, "arrow_patch", None)
            if arrow_patch is None and hasattr(annotation, "get_arrow_patch"):
                arrow_patch = annotation.get_arrow_patch()
            if arrow_patch is not None:
                arrow_patch.set_color(colors["grid"])
            annotation.set_color(colors["text"])
            marker.set_markerfacecolor(colors["accent"])
            marker.set_markeredgecolor(colors["axis"])

    def _set_datapicker_mode(self, is_enabled: bool, status_message: str | None = "auto") -> None:
        """Switch datapicking on or off and keep the toolbar state in sync."""
        self.datapicker_mode_var.set(is_enabled)
        if is_enabled:
            self._disable_toolbar_navigation_mode()
        elif self.picked_points:
            self._clear_picker_artists()
            self.canvas.draw_idle()
        if hasattr(self.toolbar, "_sync_datapicker_button"):
            self.toolbar._sync_datapicker_button()

        if status_message is None:
            return
        if status_message == "auto":
            if is_enabled:
                self.status_var.set(
                    "Datapicker aktiv. Linksklick waehlt Punkte, CTRL + Linksklick fuegt weitere hinzu."
                )
            else:
                self.status_var.set("Datapicker deaktiviert. Alle Datapicks wurden entfernt.")
            return
        self.status_var.set(status_message)

    def _disable_toolbar_navigation_mode(self) -> None:
        """Turn off pan or zoom before datapicking starts."""
        toolbar_mode = str(getattr(self.toolbar, "mode", "") or "")
        if "PAN" in toolbar_mode.upper():
            self.toolbar.pan()
        elif "ZOOM" in toolbar_mode.upper():
            self.toolbar.zoom()

    def open_file(self) -> None:
        """Prompt for a CSV file and populate record/system/column selectors."""
        initial_dir = ROOT_DIR / "input"
        file_name = filedialog.askopenfilename(
            title="CSV-Datei waehlen",
            initialdir=initial_dir if initial_dir.exists() else ROOT_DIR,
            filetypes=[("CSV-Dateien", "*.csv"), ("Alle Dateien", "*.*")],
        )
        if not file_name:
            return

        self.load_csv_path(file_name)

    def load_csv_path(self, file_path: str | Path) -> None:
        """Load a CSV file from a path and refresh the selector widgets."""
        path = Path(file_path)
        if path.suffix.lower() != ".csv":
            messagebox.showwarning("Keine CSV", "Bitte eine CSV-Datei ablegen oder auswaehlen.")
            LOGGER.info("Datei verworfen, weil sie keine CSV ist: %s", path)
            return
        if not path.exists():
            messagebox.showerror("Datei nicht gefunden", str(path))
            LOGGER.info("CSV-Datei nicht gefunden: %s", path)
            return

        self.csv_path = path
        self.file_var.set(str(self.csv_path))
        LOGGER.info("CSV-Datei wird geladen: %s", self.csv_path)

        try:
            self._auto_detect_delimiter()
            self._load_metadata()
        except Exception as exc:
            log_exception(LOGGER, f"Fehler beim Laden der CSV-Datei: {path}", exc)
            self._reset_selectors()
            messagebox.showerror("CSV konnte nicht geladen werden", str(exc))
            self.status_var.set("Fehler beim Laden der CSV.")
            return

        record_types = sorted(self.record_columns)
        self.record_type_box["values"] = record_types
        if record_types:
            self.record_type_var.set(record_types[0])
            self.on_record_type_changed()
            if self.csv_mode == "plain":
                if self.timestamp_column is not None:
                    self.status_var.set(
                        f"Datei geladen: {self.csv_path.name}. Standard-CSV erkannt, Trennzeichen {self._describe_current_delimiter()}, Zeitspalte: {self.timestamp_column}."
                    )
                else:
                    self.status_var.set(
                        f"Datei geladen: {self.csv_path.name}. Standard-CSV erkannt, Trennzeichen {self._describe_current_delimiter()}, keine Zeitspalte, X-Achse = Zeilennummer."
                    )
            else:
                self.status_var.set(
                    f"Datei geladen: {self.csv_path.name}. Trennzeichen {self._describe_current_delimiter()} erkannt. Record Type, System, X-Achse und Spalten auswaehlen."
                )
            LOGGER.info(
                "CSV-Datei erfolgreich geladen: %s | Trennzeichen: %s | Modus: %s | Record Types: %s",
                self.csv_path.name,
                self._describe_current_delimiter(),
                self.csv_mode,
                len(record_types),
            )
        else:
            self._reset_selectors()
            self.status_var.set("Keine auswertbaren Datensaetze in der CSV gefunden.")
            LOGGER.info("CSV-Datei enthaelt keine auswertbaren Datensaetze: %s", self.csv_path)

    def _load_metadata(self) -> None:
        """Discover record types, systems, and numeric columns inside the CSV.

        We detect the file structure first, because APS/APU exports need a
        different metadata scan than a standard one-header CSV.
        """
        if self.csv_path is None:
            raise ValueError("Es wurde keine CSV-Datei ausgewaehlt.")

        delimiter = self._get_delimiter()
        self.csv_mode = "structured"
        self.timestamp_column = None
        self.plain_columns = []
        with open_csv_with_fallbacks(self.csv_path) as probe_handle:
            probe_reader = csv.reader(probe_handle, delimiter=delimiter)
            for row in probe_reader:
                if not row:
                    continue
                if len(row) >= 3 and row[2].strip() == TIMESTAMP_COLUMN:
                    self._load_structured_metadata(delimiter)
                    return
        self._load_plain_metadata(delimiter)

    def _auto_detect_delimiter(self) -> None:
        """Detect the delimiter from the loaded file and mirror it in the UI."""
        if self.csv_path is None:
            raise ValueError("Es wurde keine CSV-Datei ausgewaehlt.")

        with open_csv_with_fallbacks(self.csv_path) as handle:
            detected_delimiter = detect_csv_delimiter(handle.getvalue())

        detected_label = DELIMITER_VALUE_TO_LABEL.get(detected_delimiter)
        if detected_label is None:
            LOGGER.warning("Unbekanntes Trennzeichen erkannt, Standard ';' wird verwendet: %r", detected_delimiter)
            detected_label = DELIMITER_VALUE_TO_LABEL[";"]

        self.delimiter_label_var.set(detected_label)
        LOGGER.info("Trennzeichen automatisch erkannt: %s", self._describe_current_delimiter())

    def _load_structured_metadata(self, delimiter: str) -> None:
        """Load metadata for the existing APS/APU export structure.

        APS/APU files contain multiple record blocks. Each block has its own
        schema row and then many data rows for one or more systems.
        """
        record_columns: dict[str, list[str]] = {}
        record_systems: dict[str, set[str]] = {}
        numeric_columns: dict[tuple[str, str], set[str]] = {}

        with open_csv_with_fallbacks(self.csv_path) as handle:
            reader = csv.reader(handle, delimiter=delimiter)
            header_map_by_record: dict[str, dict[int, str]] = {}

            for row in reader:
                if len(row) < 3:
                    continue
                record_type = row[0].strip()
                system_name = row[1].strip()
                third_cell = row[2].strip()

                if third_cell == TIMESTAMP_COLUMN:
                    # Diese Schema-Zeile beschreibt, welche Spalten es fuer
                    # diesen Record Type gibt. Die spaeteren Datenzeilen werden
                    # anhand dieser Spaltenliste gelesen.
                    columns = [value.strip() for value in row[3:] if value.strip()]
                    record_columns[record_type] = columns
                    header_map_by_record[record_type] = {
                        idx: value.strip() for idx, value in enumerate(row[3:], start=3) if value.strip()
                    }
                    continue

                if record_type not in header_map_by_record:
                    continue

                record_systems.setdefault(record_type, set()).add(system_name)
                key = (record_type, system_name)
                numeric_columns.setdefault(key, set())

                for idx, raw_value in enumerate(row[3:], start=3):
                    column_name = header_map_by_record[record_type].get(idx)
                    if not column_name:
                        continue
                    value = raw_value.strip()
                    if not value:
                        continue
                    try:
                        float(value)
                    except ValueError:
                        continue
                    numeric_columns[key].add(column_name)

        self.record_columns = record_columns
        self.record_systems = {
            record_type: sorted(systems)
            for record_type, systems in record_systems.items()
        }
        self.numeric_columns = {}
        for key, columns in numeric_columns.items():
            record_type, _system_name = key
            ordered_columns = [
                column
                for column in self.record_columns.get(record_type, [])
                if column in columns
            ]
            self.numeric_columns[key] = ordered_columns

    def _load_plain_metadata(self, delimiter: str) -> None:
        """Load metadata for a regular CSV with one header row.

        For standard CSV files we expose every numeric column as a possible
        Y series and every header column as a possible X-axis source.
        """
        if self.csv_path is None:
            raise ValueError("Es wurde keine CSV-Datei ausgewaehlt.")

        with open_csv_with_fallbacks(self.csv_path) as handle:
            rows = list(csv.reader(handle, delimiter=delimiter))
            header, data_rows = split_plain_csv_header_and_rows(rows)
            if not header:
                raise ValueError("Die CSV-Datei ist leer.")

            normalized_header = normalize_header(header)
            if not normalized_header:
                raise ValueError("Die CSV-Datei enthaelt keine gueltige Header-Zeile.")

            sample_rows = [row for row in data_rows if any(cell.strip() for cell in row)]

        self.csv_mode = "plain"
        self.plain_columns = normalized_header
        self.timestamp_column = detect_timestamp_column(normalized_header, sample_rows)

        numeric_columns: list[str] = []
        for index, column_name in enumerate(normalized_header):
            if column_name == self.timestamp_column:
                continue
            if any(is_float_row_value(row, index) for row in sample_rows):
                numeric_columns.append(column_name)

        if not numeric_columns:
            raise ValueError("Keine numerischen Spalten in der CSV gefunden.")

        record_type = "CSV"
        system_name = "Alle Daten"
        self.record_columns = {record_type: numeric_columns}
        self.record_systems = {record_type: [system_name]}
        self.numeric_columns = {(record_type, system_name): numeric_columns}

    def _get_delimiter(self) -> str:
        """Return the configured delimiter or fail with a user-friendly message."""
        selected_label = self.delimiter_label_var.get()
        delimiter = DELIMITER_LABEL_TO_VALUE.get(selected_label)
        if delimiter is None:
            raise ValueError("Bitte ein gueltiges Trennzeichen auswaehlen.")
        return delimiter

    def _describe_current_delimiter(self) -> str:
        """Return a short display text for the currently selected delimiter."""
        delimiter = self._get_delimiter()
        if delimiter == "\t":
            return "Tab"
        return repr(delimiter)

    def _reset_selectors(self) -> None:
        """Clear all selector widgets after load errors."""
        self.record_columns = {}
        self.record_systems = {}
        self.numeric_columns = {}
        self.csv_mode = "structured"
        self.timestamp_column = None
        self.plain_columns = []
        self.record_type_var.set("")
        self.system_name_var.set("")
        self.x_axis_var.set("Datum + Zeit")
        self.record_type_box["values"] = []
        self.system_box["values"] = []
        self.x_axis_box["values"] = []
        self._set_column_values([])

    def on_record_type_changed(self, _event: object | None = None) -> None:
        """Refresh systems and columns after record type selection changes."""
        record_type = self.record_type_var.get()
        systems = self.record_systems.get(record_type, [])
        self.system_box["values"] = systems
        if systems:
            self.system_name_var.set(systems[0])
        else:
            self.system_name_var.set("")
        self.on_system_changed()

    def on_system_changed(self, _event: object | None = None) -> None:
        """Refresh the selectable numeric column list."""
        key = (self.record_type_var.get(), self.system_name_var.get())
        columns = self.numeric_columns.get(key)
        if not columns:
            columns = self.record_columns.get(self.record_type_var.get(), [])
        self._set_column_values(columns)
        self._update_x_axis_options()
        self.status_var.set(
            f"{len(columns)} Spalten verfuegbar fuer {self.record_type_var.get()} / {self.system_name_var.get()}."
        )

    def _update_x_axis_options(self) -> None:
        """Refresh X-axis choices for the current CSV mode.

        APS/APU and plain CSV files expose X values differently, but the UI
        presents both through the same selector widget.
        """
        if self.csv_mode == "plain":
            values = [self.ROW_INDEX_LABEL, *self.plain_columns]
            self.x_axis_box["values"] = values
            preferred_value = self.timestamp_column or self.ROW_INDEX_LABEL
            if self.x_axis_var.get() not in values:
                self.x_axis_var.set(preferred_value)
        else:
            record_type = self.record_type_var.get()
            values = [self.ROW_INDEX_LABEL, TIMESTAMP_COLUMN, *self.record_columns.get(record_type, [])]
            self.x_axis_box["values"] = values
            if self.x_axis_var.get() not in values:
                self.x_axis_var.set(TIMESTAMP_COLUMN)

    def _set_column_values(self, columns: list[str]) -> None:
        """Replace the listbox content with the given columns."""
        self.column_list.delete(0, tk.END)
        for column in columns:
            self.column_list.insert(tk.END, column)

    def select_all_columns(self) -> None:
        """Select every currently listed column."""
        self.column_list.selection_set(0, tk.END)

    def clear_column_selection(self) -> None:
        """Clear the current column selection."""
        self.column_list.selection_clear(0, tk.END)

    def plot_selected_columns(self) -> None:
        """Parse the CSV for the selected columns and render them to the canvas."""
        if self.csv_path is None:
            messagebox.showwarning("Keine Datei", "Bitte zuerst eine CSV-Datei laden.")
            return

        selected_columns = [self.column_list.get(idx) for idx in self.column_list.curselection()]
        if not selected_columns:
            messagebox.showwarning("Keine Spalten", "Bitte mindestens eine Spalte auswaehlen.")
            return

        try:
            x_values, series_map, title_suffix, x_label = self._load_selected_series(selected_columns)
        except Exception as exc:
            log_exception(LOGGER, "Fehler beim Erstellen des Plots.", exc)
            messagebox.showerror("Plot fehlgeschlagen", str(exc))
            self.status_var.set("Plot konnte nicht erstellt werden.")
            return

        # Vor dem Neuaufbau des Diagramms werden vorhandene Marker und
        # Hinweisfelder entfernt, solange sie noch an der alten Zeichenflaeche haengen.
        self._clear_picker_artists()
        self.axes.clear()
        self._connect_axes_limit_callbacks()
        self.series_legend = None
        self.min_max_legend = None
        self.min_max_marker_artists.clear()
        self._style_axes()
        for column in selected_columns:
            self.axes.plot(x_values, series_map[column], label=column, linewidth=1.2)

        if x_values and isinstance(x_values[0], datetime):
            locator = mdates.AutoDateLocator()
            self.axes.xaxis.set_major_locator(locator)
            self.axes.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d %H:%M:%S"))
            self.figure.autofmt_xdate()

        self.axes.set_title(f"{self.csv_path.name}\n{title_suffix}")
        self.axes.set_xlabel(x_label)
        self.axes.set_ylabel("Wert")
        self.current_plot_columns = selected_columns
        self.current_x_values = x_values
        self.current_x_plot_values = self._build_plot_x_value_cache(x_values)
        self.current_x_plot_array = np.asarray(self.current_x_plot_values, dtype=float)
        self.current_x_plot_values_are_sorted = self._is_non_decreasing(self.current_x_plot_values)
        self.current_series_map = series_map
        self.current_series_arrays = {
            column_name: np.asarray(series_map.get(column_name, []), dtype=float)
            for column_name in selected_columns
        }
        self.current_x_label = x_label
        self.has_plot = True
        self._rebuild_series_legend()
        self._refresh_min_max_overlays()
        self.canvas.draw_idle()
        self.toolbar.update()

        self.status_var.set(
            f"Plot aktualisiert: {len(selected_columns)} Spalten, {len(x_values)} Datenpunkte."
        )
        LOGGER.info(
            "Plot erstellt: Datei=%s | Spalten=%s | Datenpunkte=%s | X-Achse=%s",
            self.csv_path.name if self.csv_path is not None else "<unbekannt>",
            ", ".join(selected_columns),
            len(x_values),
            x_label,
        )

    def _build_plot_x_value_cache(self, x_values: list[XValue]) -> list[float]:
        """Cache numeric X coordinates once so later view calculations stay cheap."""
        return [float(self._to_plot_coordinate(x_value)) for x_value in x_values]

    def _is_non_decreasing(self, values: list[float]) -> bool:
        """Return True when cached X values are ordered from left to right."""
        return all(left <= right for left, right in zip(values, values[1:]))

    def _set_min_max_legend_visibility(self, is_enabled: bool, status_message: str | None = "auto") -> None:
        """Show or hide the extra legend and keep toolbar state in sync."""
        self.show_min_max_legend_var.set(is_enabled)
        if hasattr(self.toolbar, "_sync_min_max_button"):
            self.toolbar._sync_min_max_button()
        if not self._needs_min_max_refresh() and self.min_max_refresh_after_id is not None:
            self.root.after_cancel(self.min_max_refresh_after_id)
            self.min_max_refresh_after_id = None

        if self.has_plot:
            self._refresh_min_max_overlays()
            self.canvas.draw_idle()

        if status_message is None:
            return
        if status_message == "auto":
            if not self.has_plot and is_enabled:
                self.status_var.set("Min/Max-Legende wird nach dem naechsten Plot angezeigt.")
            elif is_enabled:
                self.status_var.set("Min/Max-Legende eingeblendet. Beide Legenden koennen verschoben werden.")
            else:
                self.status_var.set("Min/Max-Legende ausgeblendet.")
            return
        self.status_var.set(status_message)

    def _set_min_max_marker_visibility(self, is_enabled: bool, status_message: str | None = "auto") -> None:
        """Show or hide the visible-range Min/Max markers and keep toolbar state in sync."""
        self.show_min_max_markers_var.set(is_enabled)
        if hasattr(self.toolbar, "_sync_min_max_marker_button"):
            self.toolbar._sync_min_max_marker_button()
        if not self._needs_min_max_refresh() and self.min_max_refresh_after_id is not None:
            self.root.after_cancel(self.min_max_refresh_after_id)
            self.min_max_refresh_after_id = None

        if self.has_plot:
            self._refresh_min_max_overlays()
            self.canvas.draw_idle()

        if status_message is None:
            return
        if status_message == "auto":
            if not self.has_plot and is_enabled:
                self.status_var.set("Min/Max-Markierungen werden nach dem naechsten Plot angezeigt.")
            elif is_enabled:
                self.status_var.set("Min/Max-Markierungen im Plot eingeblendet.")
            else:
                self.status_var.set("Min/Max-Markierungen ausgeblendet.")
            return
        self.status_var.set(status_message)

    def _on_axes_limits_changed(self, _axes: object) -> None:
        """Delay Min/Max refresh until the current zoom or pan interaction has settled."""
        if not self.has_plot or not self._needs_min_max_refresh():
            return
        self._schedule_min_max_legend_refresh()

    def _schedule_min_max_legend_refresh(self) -> None:
        """Debounce visible-range Min/Max updates during repeated view changes."""
        if self.min_max_refresh_after_id is not None:
            self.root.after_cancel(self.min_max_refresh_after_id)
        self.min_max_refresh_after_id = self.root.after(
            MIN_MAX_REFRESH_DELAY_MS,
            self._refresh_min_max_legend_after_view_change,
        )

    def _schedule_wheel_zoom_commit(self) -> None:
        """Commit one mouse-wheel zoom burst as a single history and legend update step."""
        if self.wheel_zoom_commit_after_id is not None:
            self.root.after_cancel(self.wheel_zoom_commit_after_id)
        self.wheel_zoom_commit_after_id = self.root.after(
            WHEEL_ZOOM_COMMIT_DELAY_MS,
            self._finalize_wheel_zoom,
        )

    def _finalize_wheel_zoom(self) -> None:
        """Store the final wheel zoom view once the user stops scrolling briefly."""
        self.wheel_zoom_commit_after_id = None
        if not self.has_plot:
            return
        self.toolbar.push_current()
        self._schedule_min_max_legend_refresh()

    def _refresh_min_max_legend_after_view_change(self) -> None:
        """Rebuild Min/Max overlays after the visible plot section has changed."""
        self.min_max_refresh_after_id = None
        if not self.has_plot or not self._needs_min_max_refresh():
            return
        self._refresh_min_max_overlays()
        self.canvas.draw_idle()

    def _rebuild_series_legend(self) -> None:
        """Create the static signal legend only when plotted lines change."""
        if self.series_legend is not None:
            self._safe_remove_artist(self.series_legend)
        self.series_legend = self.axes.legend(loc="best")
        self._style_single_legend(self.series_legend)
        self._enable_legend_drag(self.series_legend)

    def _refresh_min_max_legend(self) -> None:
        """Refresh only the dynamic Min/Max legend for the current view."""
        if self.min_max_legend is not None:
            self._safe_remove_artist(self.min_max_legend)
            self.min_max_legend = None
        if self.series_legend is not None:
            self.axes.add_artist(self.series_legend)
        if not self.show_min_max_legend_var.get():
            return
        self.min_max_legend = self._create_min_max_legend()
        if self.min_max_legend is None:
            return
        self._style_single_legend(self.min_max_legend)
        self._enable_legend_drag(self.min_max_legend)

    def _refresh_min_max_overlays(self) -> None:
        """Refresh the visible-range Min/Max legend and plot markers together."""
        self._refresh_min_max_legend()
        self._refresh_min_max_markers()

    def _needs_min_max_refresh(self) -> bool:
        """Return True when any visible-range Min/Max overlay is active."""
        return self.show_min_max_legend_var.get() or self.show_min_max_markers_var.get()

    def _create_min_max_legend(self) -> Legend | None:
        """Create a second legend that lists the min and max values per visible signal."""
        legend_labels: list[str] = []
        legend_handles = []
        for min_max_entry in self._collect_visible_min_max_entries():
            line = min_max_entry["line"]
            legend_handles.append(line)
            legend_labels.append(
                f"{min_max_entry['column_name']}: "
                f"Min {float(min_max_entry['min_y']):g} | Max {float(min_max_entry['max_y']):g}"
            )

        if not legend_handles:
            return None

        return self.axes.legend(
            legend_handles,
            legend_labels,
            loc="upper left",
            title="Min / Max",
            fontsize=9,
            title_fontsize=9,
        )

    def _collect_visible_min_max_entries(self) -> list[dict[str, object]]:
        """Collect visible-range Min/Max values and source indices for each plotted signal."""
        visible_x_mask_or_range = self._get_visible_x_mask_or_range()
        if visible_x_mask_or_range is None:
            return []

        y_lower, y_upper = sorted(self.axes.get_ylim())
        min_max_entries: list[dict[str, object]] = []
        for line, column_name in zip(self.axes.get_lines(), self.current_plot_columns):
            y_values = self.current_series_arrays.get(column_name)
            if y_values is None or y_values.size == 0:
                continue

            if isinstance(visible_x_mask_or_range, tuple):
                start_index, end_index = visible_x_mask_or_range
                source_indices = np.arange(start_index, end_index, dtype=int)
            else:
                source_indices = np.flatnonzero(visible_x_mask_or_range)
            if source_indices.size == 0:
                continue

            visible_y_values = y_values[source_indices]
            visible_y_mask = (visible_y_values >= y_lower) & (visible_y_values <= y_upper)
            if not np.any(visible_y_mask):
                continue

            source_indices = source_indices[visible_y_mask]
            visible_y_values = visible_y_values[visible_y_mask]
            min_position = int(np.argmin(visible_y_values))
            max_position = int(np.argmax(visible_y_values))
            min_index = int(source_indices[min_position])
            max_index = int(source_indices[max_position])
            min_max_entries.append(
                {
                    "line": line,
                    "column_name": column_name,
                    "min_index": min_index,
                    "max_index": max_index,
                    "min_y": float(y_values[min_index]),
                    "max_y": float(y_values[max_index]),
                }
            )

        return min_max_entries

    def _refresh_min_max_markers(self) -> None:
        """Refresh the visible-range Min/Max markers in the current plot."""
        self._clear_min_max_marker_artists()
        if not self.show_min_max_markers_var.get():
            return

        colors = THEMES[self.theme_name]
        for min_max_entry in self._collect_visible_min_max_entries():
            line = min_max_entry["line"]
            line_color = line.get_color()
            min_index = int(min_max_entry["min_index"])
            max_index = int(min_max_entry["max_index"])

            self.min_max_marker_artists.append(
                self.axes.plot(
                    [self.current_x_values[min_index]],
                    [float(min_max_entry["min_y"])],
                    marker="v",
                    markersize=8,
                    linestyle="None",
                    markerfacecolor=line_color,
                    markeredgecolor=colors["axis"],
                    markeredgewidth=1.0,
                    zorder=6,
                )[0]
            )
            self.min_max_marker_artists.append(
                self.axes.plot(
                    [self.current_x_values[max_index]],
                    [float(min_max_entry["max_y"])],
                    marker="^",
                    markersize=8,
                    linestyle="None",
                    markerfacecolor=line_color,
                    markeredgecolor=colors["axis"],
                    markeredgewidth=1.0,
                    zorder=6,
                )[0]
            )
            if min_index == max_index:
                self.min_max_marker_artists.append(
                    self.axes.plot(
                        [self.current_x_values[min_index]],
                        [float(min_max_entry["min_y"])],
                        marker="D",
                        markersize=5,
                        linestyle="None",
                        markerfacecolor=colors["input"],
                        markeredgecolor=colors["axis"],
                        markeredgewidth=0.9,
                        zorder=7,
                    )[0]
                )

    def _get_visible_x_mask_or_range(self) -> tuple[int, int] | np.ndarray | None:
        """Return either a fast contiguous index range or a boolean mask for the visible X window."""
        if self.current_x_plot_array.size == 0:
            return None

        x_lower, x_upper = sorted(self.axes.get_xlim())
        if self.current_x_plot_values_are_sorted:
            start_index = bisect_left(self.current_x_plot_values, x_lower)
            end_index = bisect_right(self.current_x_plot_values, x_upper)
            if end_index <= start_index:
                return None
            return start_index, end_index

        visible_mask = (self.current_x_plot_array >= x_lower) & (self.current_x_plot_array <= x_upper)
        if not np.any(visible_mask):
            return None
        return visible_mask

    def _remove_plot_legends(self) -> None:
        """Detach existing legend artists before they are rebuilt."""
        for legend in (self.series_legend, self.min_max_legend):
            if legend is None:
                continue
            self._safe_remove_artist(legend)
        self.series_legend = None
        self.min_max_legend = None

    def _style_plot_legends(self) -> None:
        """Apply the active theme to every visible plot legend."""
        for legend in (self.series_legend, self.min_max_legend):
            self._style_single_legend(legend)

    def _style_single_legend(self, legend: Legend | None) -> None:
        """Color one legend so it stays readable in both themes."""
        if legend is None:
            return

        colors = THEMES[self.theme_name]
        legend.get_frame().set_facecolor(colors["input"])
        legend.get_frame().set_edgecolor(colors["grid"])
        for text in legend.get_texts():
            text.set_color(colors["text"])
        title = legend.get_title()
        if title is not None:
            title.set_color(colors["text"])

    def _enable_legend_drag(self, legend: Legend | None) -> None:
        """Enable mouse dragging for one legend when Matplotlib supports it."""
        if legend is None:
            return
        draggable = getattr(legend, "set_draggable", None)
        if callable(draggable):
            draggable(True)

    def export_current_plot(self, export_scope: str) -> None:
        """Export the currently plotted data to a standalone CSV file."""
        if not self.has_plot or not self.current_x_values or not self.current_plot_columns:
            messagebox.showwarning("Kein Plot", "Bitte zuerst einen Plot erstellen.")
            return

        row_indices = get_export_row_indices(
            export_scope,
            self.current_x_values,
            self.current_series_map,
            self.current_plot_columns,
            self.axes.get_xlim(),
            self.axes.get_ylim(),
            self._to_plot_coordinate,
        )
        if not row_indices:
            messagebox.showwarning("Keine Daten", "Im gewaehlten Exportbereich liegen keine Datenpunkte.")
            return

        default_name = "plot_export.csv"
        if self.csv_path is not None:
            suffix = "sichtbar" if export_scope == "visible" else "gesamt"
            default_name = f"{self.csv_path.stem}_{suffix}.csv"

        output_path = filedialog.asksaveasfilename(
            title="Plot als CSV exportieren",
            defaultextension=".csv",
            initialdir=str(ROOT_DIR / "output" if (ROOT_DIR / "output").exists() else ROOT_DIR),
            initialfile=default_name,
            filetypes=[("CSV-Dateien", "*.csv"), ("Alle Dateien", "*.*")],
        )
        if not output_path:
            return

        try:
            write_plot_export(
                Path(output_path),
                self._get_delimiter(),
                self.current_x_label,
                self.current_x_values,
                self.current_plot_columns,
                self.current_series_map,
                row_indices,
            )
        except Exception as exc:
            log_exception(LOGGER, f"Fehler beim CSV-Export nach: {output_path}", exc)
            messagebox.showerror("Export fehlgeschlagen", str(exc))
            self.status_var.set("CSV-Export konnte nicht erstellt werden.")
            return

        self.status_var.set(f"CSV exportiert: {Path(output_path).name} ({len(row_indices)} Datenpunkte).")
        LOGGER.info(
            "Plot exportiert: Ziel=%s | Datenpunkte=%s | Modus=%s",
            output_path,
            len(row_indices),
            export_scope,
        )

    def _clear_picker_artists(self) -> None:
        """Remove every visible picker marker and tooltip from the axes."""
        self.dragged_picker_key = None
        for picked_point in self.picked_points.values():
            self._safe_remove_artist(picked_point["annotation"])
            self._safe_remove_artist(picked_point["marker"])
        self.picked_points.clear()

    def _clear_min_max_marker_artists(self) -> None:
        """Remove every visible Min/Max marker from the axes."""
        for marker_artist in self.min_max_marker_artists:
            self._safe_remove_artist(marker_artist)
        self.min_max_marker_artists.clear()

    def _safe_remove_artist(self, artist: object) -> None:
        """Remove one Matplotlib artist only while that artist is still attached."""
        try:
            artist.remove()
        except (AttributeError, NotImplementedError, ValueError):
            # Some Matplotlib artists are already detached after an axes reset.
            # Hiding them is enough until our stale reference is discarded.
            if hasattr(artist, "set_visible"):
                artist.set_visible(False)

    def _on_plot_button_press(self, event: object) -> None:
        """Handle plot mouse presses for picks, tooltip drag, and panning."""
        if not self.has_plot:
            return
        if is_middle_mouse_button(event):
            self._start_middle_pan(event)
            return
        if event.inaxes != self.axes:
            return
        if self.toolbar.mode:
            return
        picker_hit = self._find_picker_hit(event)
        if picker_hit is not None:
            if is_left_mouse_button(event):
                self.dragged_picker_key = picker_hit
                self.status_var.set("Datapick-Textbox wird verschoben.")
                return
            if is_right_mouse_button(event):
                self._cycle_picked_point_position(picker_hit)
                return
        if not self.datapicker_mode_var.get():
            return
        if not is_left_mouse_button(event):
            return
        if event.x is None or event.y is None:
            return
        if not self.current_x_values or not self.current_plot_columns:
            return

        visible_x_mask_or_range = self._get_visible_x_mask_or_range()
        nearest = find_nearest_point(
            self.axes,
            event.x,
            event.y,
            self.current_x_values,
            self.current_x_plot_array,
            self.current_series_arrays,
            self.current_plot_columns,
            visible_x_mask_or_range,
        )
        if nearest is None:
            return

        column_name, point_index, x_value, y_value = nearest
        picked_point_key = (column_name, point_index)
        if is_control_modifier_active(event):
            self._toggle_picked_point(picked_point_key, column_name, point_index, x_value, y_value)
            return
        self._replace_picked_points(column_name, point_index, x_value, y_value)

    def _on_mousewheel_zoom(self, event: object) -> None:
        """Zoom in/out around the mouse cursor."""
        if not self.has_plot or event.inaxes != self.axes:
            return
        if event.xdata is None or event.ydata is None:
            return

        zoom_factor = 1 / 1.2 if event.button == "up" else 1.2
        zoom_axes_around_cursor(self.axes, event.xdata, event.ydata, zoom_factor)
        self._schedule_wheel_zoom_commit()
        self.canvas.draw_idle()

    def _start_middle_pan(self, event: object) -> None:
        """Store the current view before middle-button drag panning starts."""
        if event.x is None or event.y is None:
            return
        self.middle_pan_start = (event.x, event.y, self.axes.get_xlim(), self.axes.get_ylim())

    def _on_plot_motion(self, event: object) -> None:
        """Move dragged datapick textboxes first, otherwise keep middle-button panning."""
        if self.dragged_picker_key is not None:
            self._drag_picked_point(event)
            return
        self._on_middle_pan_motion(event)

    def _on_middle_pan_motion(self, event: object) -> None:
        """Pan the plot while the middle mouse button is dragged."""
        if self.middle_pan_start is None or not self.has_plot:
            return
        if event.inaxes != self.axes or event.x is None or event.y is None:
            return

        start_x, start_y, start_xlim, start_ylim = self.middle_pan_start
        if pan_axes_from_drag(self.axes, start_x, start_y, event.x, event.y, start_xlim, start_ylim):
            self.canvas.draw_idle()

    def _on_plot_button_release(self, event: object) -> None:
        """Finish tooltip dragging or middle-button panning when the mouse is released."""
        if self.dragged_picker_key is not None and is_left_mouse_button(event):
            released_picker_key = self.dragged_picker_key
            self.dragged_picker_key = None
            self._update_picked_points_status(released_picker_key)
            return
        self._on_middle_pan_release(event)

    def _on_middle_pan_release(self, event: object) -> None:
        """Finish middle-button drag panning and add the view to the toolbar history."""
        if self.middle_pan_start is None:
            return
        if is_middle_mouse_button(event):
            self.toolbar.push_current()
            self.middle_pan_start = None
            self._schedule_min_max_legend_refresh()

    def _replace_picked_points(
        self,
        column_name: str,
        point_index: int,
        x_value: datetime | int | float | str,
        y_value: float,
    ) -> None:
        """Replace the current selection with exactly one picked point."""
        picked_point_key = (column_name, point_index)
        if len(self.picked_points) == 1 and picked_point_key in self.picked_points:
            self._clear_picker_artists()
            self.canvas.draw_idle()
            self.status_var.set("Datapick entfernt.")
            return
        self._clear_picker_artists()
        self._add_picked_point(picked_point_key, column_name, point_index, x_value, y_value)

    def _toggle_picked_point(
        self,
        picked_point_key: PickedPointKey,
        column_name: str,
        point_index: int,
        x_value: datetime | int | float | str,
        y_value: float,
    ) -> None:
        """Add or remove one picked point while keeping the others visible."""
        if picked_point_key in self.picked_points:
            self._remove_picked_point(picked_point_key)
            self.canvas.draw_idle()
            self._update_picked_points_status()
            return
        self._add_picked_point(picked_point_key, column_name, point_index, x_value, y_value)

    def _add_picked_point(
        self,
        picked_point_key: PickedPointKey,
        column_name: str,
        point_index: int,
        x_value: datetime | int | float | str,
        y_value: float,
    ) -> None:
        """Draw one marker plus tooltip and keep it in the active selection set."""
        colors = THEMES[self.theme_name]

        marker = self.axes.plot(
            [x_value],
            [y_value],
            marker="o",
            markersize=7,
            linestyle="None",
            markerfacecolor=colors["accent"],
            markeredgecolor=colors["axis"],
            markeredgewidth=1.0,
            zorder=5,
        )[0]

        tooltip_text = (
            f"{column_name}\n"
            f"Punkt: {point_index + 1}\n"
            f"X: {format_x_value(x_value)}\n"
            f"Y: {y_value:g}"
        )
        offset = PICKER_OFFSET_CYCLE[0]
        annotation = self.axes.annotate(
            tooltip_text,
            xy=(x_value, y_value),
            xytext=offset,
            textcoords="offset pixels",
            bbox={"boxstyle": "round,pad=0.3", "fc": colors["input"], "ec": colors["grid"], "alpha": 0.95},
            arrowprops={"arrowstyle": "->", "color": colors["grid"]},
            color=colors["text"],
            fontsize=9,
        )
        self.picked_points[picked_point_key] = {
            "column_name": column_name,
            "point_index": point_index,
            "x_value": x_value,
            "y_value": y_value,
            "offset": offset,
            "marker": marker,
            "annotation": annotation,
        }
        self.canvas.draw_idle()
        self._update_picked_points_status(picked_point_key)

    def _remove_picked_point(self, picked_point_key: PickedPointKey) -> None:
        """Remove one picked point from the current selection set."""
        picked_point = self.picked_points.pop(picked_point_key, None)
        if picked_point is None:
            return
        self._safe_remove_artist(picked_point["annotation"])
        self._safe_remove_artist(picked_point["marker"])

    def _update_picked_points_status(self, focus_key: PickedPointKey | None = None) -> None:
        """Show a concise summary of the active picked points in the status bar."""
        if not self.picked_points:
            self.status_var.set("Keine Datapicks aktiv.")
            return

        active_key = focus_key
        if active_key is None or active_key not in self.picked_points:
            active_key = next(reversed(self.picked_points))

        active_point = self.picked_points[active_key]
        status_text = (
            f"Datapicks: {len(self.picked_points)} | "
            f"Aktiv: {active_point['column_name']} | Punkt {active_point['point_index'] + 1} | "
            f"X={format_x_value(active_point['x_value'])} | Y={active_point['y_value']:g}"
        )
        if len(self.picked_points) == 2:
            picked_point_values = list(self.picked_points.values())
            first_point = picked_point_values[0]
            second_point = picked_point_values[1]
            delta_x = format_x_difference(first_point["x_value"], second_point["x_value"])
            delta_y = second_point["y_value"] - first_point["y_value"]
            status_text += f" | Delta X={delta_x} | Delta Y={delta_y:g}"
        self.status_var.set(status_text)

    def _find_picker_hit(self, event: object) -> PickedPointKey | None:
        """Return the topmost datapick whose text box contains the mouse event."""
        for picked_point_key in reversed(self.picked_points):
            annotation = self.picked_points[picked_point_key]["annotation"]
            contains, _details = annotation.contains(event)
            if contains:
                return picked_point_key
        return None

    def _drag_picked_point(self, event: object) -> None:
        """Move one datapick text box freely in pixel offsets relative to its anchor."""
        if self.dragged_picker_key is None or event.x is None or event.y is None:
            return
        picked_point = self.picked_points.get(self.dragged_picker_key)
        if picked_point is None:
            self.dragged_picker_key = None
            return

        anchor_x, anchor_y = self.axes.transData.transform(
            (self._to_plot_coordinate(picked_point["x_value"]), picked_point["y_value"])
        )
        new_offset = (event.x - anchor_x, event.y - anchor_y)
        self._set_picked_point_offset(self.dragged_picker_key, new_offset)
        self.canvas.draw_idle()

    def _cycle_picked_point_position(self, picked_point_key: PickedPointKey) -> None:
        """Switch a datapick text box through a few safe preset positions around its anchor."""
        picked_point = self.picked_points.get(picked_point_key)
        if picked_point is None:
            return

        current_offset = picked_point["offset"]
        try:
            current_index = PICKER_OFFSET_CYCLE.index(current_offset)
        except ValueError:
            current_index = -1
        new_offset = PICKER_OFFSET_CYCLE[(current_index + 1) % len(PICKER_OFFSET_CYCLE)]
        self._set_picked_point_offset(picked_point_key, new_offset)
        self.canvas.draw_idle()
        self._update_picked_points_status(picked_point_key)

    def _set_picked_point_offset(self, picked_point_key: PickedPointKey, offset: PickerOffset) -> None:
        """Store and apply one datapick text box offset."""
        picked_point = self.picked_points.get(picked_point_key)
        if picked_point is None:
            return
        picked_point["offset"] = (float(offset[0]), float(offset[1]))
        picked_point["annotation"].set_position(picked_point["offset"])

    def _to_plot_coordinate(self, x_value: XValue) -> float | int | str:
        """Convert X values to the numeric representation used by the current Matplotlib axis."""
        if isinstance(x_value, datetime):
            return mdates.date2num(x_value)
        converted = self.axes.xaxis.convert_units(x_value)
        if hasattr(converted, "item"):
            return converted.item()
        return converted

    def _load_selected_series(
        self,
        selected_columns: list[str],
    ) -> tuple[list[datetime] | list[int] | list[float] | list[str], dict[str, list[float]], str, str]:
        """Load the selected series for either structured or plain CSV files.

        This is the single dispatcher that hides the source file structure
        from the plotting code below.
        """
        if self.csv_path is None:
            raise ValueError("Es wurde keine CSV-Datei ausgewaehlt.")

        if self.csv_mode == "structured":
            return self._parse_structured_csv(selected_columns)

        return self._parse_plain_csv(selected_columns)

    def _parse_structured_csv(
        self,
        selected_columns: list[str],
    ) -> tuple[list[datetime] | list[int] | list[float] | list[str], dict[str, list[float]], str, str]:
        """Parse one APS/APU record block with a selectable X-axis column.

        Compared with the CLI parser, this reader is intentionally more
        flexible because the GUI allows the user to choose any column as
        the X axis, not only the timestamp column.
        """
        if self.csv_path is None:
            raise ValueError("Es wurde keine CSV-Datei ausgewaehlt.")

        delimiter = self._get_delimiter()
        record_type = self.record_type_var.get()
        system_name = self.system_name_var.get()
        x_axis_column = self.x_axis_var.get().strip() or TIMESTAMP_COLUMN

        series = {column: [] for column in selected_columns}
        raw_x_values: list[str] = []
        header_map: dict[str, int] | None = None

        with open_csv_with_fallbacks(self.csv_path) as handle:
            reader = csv.reader(handle, delimiter=delimiter)
            for row in reader:
                if not row or len(row) < 3:
                    continue

                if row[0].strip() == record_type and row[2].strip() == TIMESTAMP_COLUMN:
                    # Bei APS/APU-Dateien steht der Zeitstempel fest in Spalte 2.
                    # Alle benannten Daten-Spalten beginnen danach ab Spalte 3.
                    header_map = {TIMESTAMP_COLUMN: 2}
                    for idx, value in enumerate(row[3:], start=3):
                        stripped = value.strip()
                        if stripped:
                            header_map[stripped] = idx
                    continue

                if row[0].strip() != record_type or row[1].strip() != system_name:
                    continue

                if header_map is None:
                    raise ValueError(
                        f"Keine Schema-Zeile fuer Record Type '{record_type}' in {self.csv_path} gefunden."
                    )

                missing_columns = [column for column in selected_columns if column not in header_map]
                if missing_columns:
                    raise ValueError(
                        "Ausgewaehlte Spalten fehlen in der CSV: " + ", ".join(missing_columns)
                    )
                if x_axis_column != self.ROW_INDEX_LABEL and x_axis_column not in header_map:
                    raise ValueError(f"X-Achsen-Spalte fehlt in der CSV: {x_axis_column}")

                parsed_values: list[float] = []
                for column in selected_columns:
                    value = get_row_value(row, header_map[column]).strip()
                    try:
                        parsed_values.append(float(value))
                    except ValueError:
                        parsed_values = []
                        break
                if not parsed_values:
                    continue

                if x_axis_column == self.ROW_INDEX_LABEL:
                    raw_x_values.append(str(len(raw_x_values) + 1))
                else:
                    raw_x_value = get_row_value(row, header_map[x_axis_column]).strip()
                    if not raw_x_value:
                        continue
                    raw_x_values.append(raw_x_value)

                for column, value in zip(selected_columns, parsed_values):
                    series[column].append(value)

        if not raw_x_values:
            raise ValueError(
                f"Keine plottbaren Datenzeilen fuer {record_type} / {system_name} gefunden."
            )

        x_values, x_label, _x_is_datetime = convert_x_values(raw_x_values, x_axis_column, self.ROW_INDEX_LABEL)
        title_suffix = f"{record_type} | {system_name} | X-Achse: {x_label}"
        return x_values, series, title_suffix, x_label

    def _parse_plain_csv(
        self,
        selected_columns: list[str],
    ) -> tuple[list[datetime] | list[int] | list[float] | list[str], dict[str, list[float]], str, str]:
        """Parse a regular CSV with a single header row.

        Rows are only kept when all selected Y columns can be parsed as
        numbers. This prevents misaligned X/Y lists.
        """
        if self.csv_path is None:
            raise ValueError("Es wurde keine CSV-Datei ausgewaehlt.")

        delimiter = self._get_delimiter()
        x_axis_column = self.x_axis_var.get().strip() or self.ROW_INDEX_LABEL
        series = {column: [] for column in selected_columns}
        raw_x_values: list[str] = []

        with open_csv_with_fallbacks(self.csv_path) as handle:
            rows = list(csv.reader(handle, delimiter=delimiter))
            header, data_rows = split_plain_csv_header_and_rows(rows)
            if not header:
                raise ValueError("Die CSV-Datei ist leer.")

            normalized_header = normalize_header(header)
            header_map = {name: idx for idx, name in enumerate(normalized_header)}

            missing_columns = [column for column in selected_columns if column not in header_map]
            if missing_columns:
                raise ValueError(
                    "Ausgewaehlte Spalten fehlen in der CSV: " + ", ".join(missing_columns)
                )
            if x_axis_column != self.ROW_INDEX_LABEL and x_axis_column not in header_map:
                raise ValueError(f"X-Achsen-Spalte fehlt in der CSV: {x_axis_column}")

            row_index = 0
            for row in data_rows:
                if not any(cell.strip() for cell in row):
                    continue

                parsed_values: list[float] = []
                for column in selected_columns:
                    value = get_row_value(row, header_map[column]).strip()
                    try:
                        parsed_values.append(float(value))
                    except ValueError:
                        parsed_values = []
                        break
                if not parsed_values:
                    continue

                if x_axis_column == self.ROW_INDEX_LABEL:
                    row_index += 1
                    raw_x_values.append(str(row_index))
                else:
                    raw_x_value = get_row_value(row, header_map[x_axis_column]).strip()
                    if not raw_x_value:
                        continue
                    raw_x_values.append(raw_x_value)

                for column, value in zip(selected_columns, parsed_values):
                    series[column].append(value)

        if not raw_x_values:
            raise ValueError("Keine plottbaren Datenzeilen fuer die aktuelle Auswahl gefunden.")

        x_values, x_label, x_is_datetime = convert_x_values(raw_x_values, x_axis_column, self.ROW_INDEX_LABEL)
        title_suffix = "Standard CSV"
        if x_axis_column != self.ROW_INDEX_LABEL:
            title_suffix = f"Standard CSV | X-Achse: {x_axis_column}"
        elif x_is_datetime:
            title_suffix = "Standard CSV | X-Achse: Datum + Zeit"
        return x_values, series, title_suffix, x_label

def main() -> int:
    """Start the desktop application."""
    sys.excepthook = handle_unexpected_exception
    LOGGER.info("CSV-Plotter wird gestartet. Version: %s", APP_VERSION)
    if TkinterDnD is not None:
        root = TkinterDnD.Tk()
        LOGGER.info("TkinterDnD aktiviert.")
    else:
        root = tk.Tk()
        LOGGER.info("TkinterDnD nicht verfuegbar. Standard-Tk wird verwendet.")
    manager = CsvPlotterManager(root)
    manager.open_new_window()
    root.mainloop()
    LOGGER.info("CSV-Plotter wurde beendet.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
