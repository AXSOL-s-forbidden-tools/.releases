"""Mouse interaction helpers for the interactive CSV plotter."""

from __future__ import annotations

from typing import Any
import numpy as np

from .csv_plotter_utils import XValue


def is_left_mouse_button(event: object) -> bool:
    """Return True for a normal left-button click across Matplotlib versions."""
    button = getattr(event, "button", None)
    return button == 1 or getattr(button, "name", "").lower() == "left"


def is_middle_mouse_button(event: object) -> bool:
    """Return True for a middle-button click across Matplotlib versions."""
    button = getattr(event, "button", None)
    return button == 2 or getattr(button, "name", "").lower() == "middle"


def is_right_mouse_button(event: object) -> bool:
    """Return True for a right-button click across Matplotlib versions."""
    button = getattr(event, "button", None)
    return button == 3 or getattr(button, "name", "").lower() == "right"


def is_control_modifier_active(event: object) -> bool:
    """Return True when the current Matplotlib event carries a Ctrl modifier."""
    key_value = str(getattr(event, "key", "") or "").lower()
    normalized_parts = {part.strip() for part in key_value.replace("+", ",").split(",") if part.strip()}
    return "control" in normalized_parts or "ctrl" in normalized_parts


def zoom_axes_around_cursor(axes: Any, x_cursor: float, y_cursor: float, zoom_factor: float) -> None:
    """Scale both axes around the cursor position."""
    current_xlim = axes.get_xlim()
    current_ylim = axes.get_ylim()

    left_span = (x_cursor - current_xlim[0]) * zoom_factor
    right_span = (current_xlim[1] - x_cursor) * zoom_factor
    lower_span = (y_cursor - current_ylim[0]) * zoom_factor
    upper_span = (current_ylim[1] - y_cursor) * zoom_factor

    axes.set_xlim(x_cursor - left_span, x_cursor + right_span)
    axes.set_ylim(y_cursor - lower_span, y_cursor + upper_span)


def pan_axes_from_drag(
    axes: Any,
    start_x: float,
    start_y: float,
    current_x: float,
    current_y: float,
    start_xlim: tuple[float, float],
    start_ylim: tuple[float, float],
) -> bool:
    """Pan axes according to a pixel-space mouse drag and return whether a pan happened."""
    bbox = axes.bbox
    if bbox.width == 0 or bbox.height == 0:
        return False

    x_span = start_xlim[1] - start_xlim[0]
    y_span = start_ylim[1] - start_ylim[0]
    dx = (current_x - start_x) * x_span / bbox.width
    dy = (current_y - start_y) * y_span / bbox.height

    axes.set_xlim(start_xlim[0] - dx, start_xlim[1] - dx)
    axes.set_ylim(start_ylim[0] - dy, start_ylim[1] - dy)
    return True


def find_nearest_point(
    axes: Any,
    click_x: float,
    click_y: float,
    x_values: list[XValue],
    x_plot_values: np.ndarray,
    series_arrays: dict[str, np.ndarray],
    plot_columns: list[str],
    visible_index_range: tuple[int, int] | np.ndarray | None,
) -> tuple[str, int, XValue, float] | None:
    """Return the plotted point closest to the click position in screen space.

    The search is limited to the currently visible X range and uses vectorized
    coordinate transforms so large plots stay responsive.
    """
    if visible_index_range is None or x_plot_values.size == 0:
        return None

    nearest_point: tuple[str, int, XValue, float] | None = None
    min_distance_sq: float | None = None

    if isinstance(visible_index_range, tuple):
        start_index, end_index = visible_index_range
        if end_index <= start_index:
            return None
        candidate_indices = np.arange(start_index, end_index)
    else:
        candidate_indices = np.flatnonzero(visible_index_range)
        if candidate_indices.size == 0:
            return None

    visible_x_values = x_plot_values[candidate_indices]

    for column in plot_columns:
        y_values = series_arrays.get(column)
        if y_values is None or y_values.size == 0:
            continue
        visible_y_values = y_values[candidate_indices]
        if visible_y_values.size == 0:
            continue

        point_coordinates = np.column_stack((visible_x_values, visible_y_values))
        screen_coordinates = axes.transData.transform(point_coordinates)
        distance_sq_values = (
            (screen_coordinates[:, 0] - click_x) ** 2
            + (screen_coordinates[:, 1] - click_y) ** 2
        )
        nearest_visible_offset = int(np.argmin(distance_sq_values))
        distance_sq = float(distance_sq_values[nearest_visible_offset])
        if min_distance_sq is None or distance_sq < min_distance_sq:
            point_index = int(candidate_indices[nearest_visible_offset])
            min_distance_sq = distance_sq
            nearest_point = (column, point_index, x_values[point_index], float(visible_y_values[nearest_visible_offset]))
    return nearest_point
