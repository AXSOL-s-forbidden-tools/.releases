"""Einstiegspunkt fuer das Modbus-Terminal."""

from __future__ import annotations

import argparse

from modbus_terminal.cli import main as run_cli
from modbus_terminal.gui import main as run_gui
from modbus_terminal.version import __version__


def build_parser() -> argparse.ArgumentParser:
    """Ermoeglicht die Wahl zwischen GUI und CLI."""
    parser = argparse.ArgumentParser(
        description=f"Modbus-Terminal v{__version__} mit GUI und CLI."
    )
    parser.add_argument(
        "--cli",
        action="store_true",
        help="Startet die bisherige Terminal-Variante statt der grafischen Oberflaeche.",
    )
    return parser


if __name__ == "__main__":
    arguments = build_parser().parse_args()
    if arguments.cli:
        run_cli()
    else:
        run_gui()
