# Architektur

## Version

- Aktuelle Version: `1.8.3`

## Uebersicht

Das Projekt besteht aus einer grafischen Oberflaeche, einer optionalen CLI und einer kleinen Modbus-TCP-Kommunikationsschicht ohne externe Laufzeitabhaengigkeiten.

```mermaid
flowchart TD
  A[main.py] --> B[GUI oder CLI]
  B --> C[Parameterpruefung]
  C --> D[Modbus TCP Client]
  D --> E[Dateninterpretation]
  E --> G[CSV Export]
  E --> H[GUI Tab-Ansichten]
  B --> I[GUI Schreibfunktion]
  B --> J[Polling Statusanzeige ohne Button-Textwechsel]
  B --> F[Fehlerlogging in ./logs]
```

## Komponenten

- `main.py`: Einstiegspunkt und Umschaltung zwischen GUI und CLI.
- `modbus_terminal/gui.py`: grafische Oberflaeche fuer Bedienung und Ergebnisanzeige.
- `modbus_terminal/cli.py`: bestehende Terminal-Variante.
- `modbus_terminal/functions/modbus_client.py`: Modbus-TCP-Anfrage und Antwortauswertung.
- `modbus_terminal/functions/modbus_client.py`: unterstuetzt jetzt Bit- und Register-Leseantworten fuer Function Code `01` bis `04`.
- `modbus_terminal/functions/write_values.py`: leitet schreibbare Register aus Typbreite und Eingabewert ab.
- `modbus_terminal/functions/tooltip.py`: liefert kurze Hilfetexte fuer die GUI.
- `modbus_terminal/functions/audit_logging.py`: protokolliert erfolgreiche Lese- und Schreibvorgaenge.
- `modbus_terminal/functions/display.py`: gemeinsame Datentyp-Interpretation sowie CSV-Vorschau-Daten fuer GUI und CLI.
- `modbus_terminal/functions/csv_export.py`: gemeinsamer CSV-Export fuer GUI und CLI.
- `modbus_terminal/functions/gui_worker.py`: Hintergrundabfrage fuer wiederholtes Lesen ohne Blockierung der GUI.
- `modbus_terminal/functions/logging_setup.py`: Logdatei-Erstellung mit Zeitstempel.
- `start_gui.bat`: Windows-Starter mit Python-Pruefung, `.env`-Einrichtung und Log-Bereinigung.

## Datenfluss

1. Die GUI oder CLI nimmt Verbindungs- und Leseparameter entgegen.
2. Die Parameter werden geprueft und an den Modbus-Client uebergeben.
3. Der Modbus-Client liest Register vom Zielsystem.
4. Die Rohdaten werden in mehrere moegliche Typen uebersetzt.
5. Die GUI zeigt sowohl die Typansicht als auch die CSV-Vorschau auf derselben registerweisen Datenbasis.
6. Optional werden Holding-Register aus der GUI geschrieben.
7. Auf Wunsch werden die gelesenen Register als CSV exportiert.
8. Das Ergebnis wird angezeigt.
9. Fehler sowie erfolgreiche Lese- und Schreibzugriffe werden in einer Zeitstempel-Datei unter `./logs` protokolliert.
