# ADR 001: GUI, Logging und Windows-Starter

## Status

Akzeptiert

## Kontext

Das Projekt soll per Doppelklick unter Windows startbar sein, Fehler protokollieren und ohne zusaetzliche Bibliotheken lauffaehig bleiben.

## Entscheidung

- Die GUI wird mit `tkinter` umgesetzt, weil diese Bibliothek bereits Teil von Python ist.
- Fehler werden mit dem Python-Standardmodul `logging` in `./logs` geschrieben.
- Die Batch-Datei startet die GUI mit `pythonw.exe`, damit das Konsolenfenster nach erfolgreichem Start nicht offen bleibt.

## Konsequenzen

- Keine externe GUI-Abhaengigkeit noetig.
- Fehler koennen nachtraeglich ueber Logdateien nachvollzogen werden.
- Die GUI startet fuer Windows-Benutzer direkter und sauberer.
