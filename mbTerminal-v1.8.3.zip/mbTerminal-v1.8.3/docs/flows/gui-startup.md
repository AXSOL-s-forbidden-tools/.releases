# GUI-Startablauf

```mermaid
flowchart TD
  A[start_gui.bat] --> B[Logordner pruefen und bei Bedarf bereinigen]
  B --> C[Python suchen oder installieren]
  C --> D[.env bereitstellen]
  D --> E[requirements.txt installieren]
  E --> F[GUI ueber pythonw starten]
  F --> G[Tab Typen und CSV Vorschau bereit]
  G --> H[CSV Export aus letzter erfolgreicher Abfrage moeglich]
  H --> I[Sichtbare Polling-Anzeige bei Wiederholungsmodus]
  I --> J[Buttontext bleibt stabil, Status nur ueber Lampe und Label]
```
