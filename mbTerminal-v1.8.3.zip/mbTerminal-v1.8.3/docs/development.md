# Entwicklung

## Version

- Aktuelle Version: `1.8.3`

## Lokale Entwicklung

GUI starten:

```bash
python main.py
```

CLI starten:

```bash
python main.py --cli
```

Windows-Starter verwenden:

```bat
start_gui.bat
```

Syntax pruefen:

```bash
python -m py_compile main.py modbus_terminal\gui.py modbus_terminal\cli.py modbus_terminal\functions\audit_logging.py modbus_terminal\functions\csv_export.py modbus_terminal\functions\display.py modbus_terminal\functions\gui_worker.py modbus_terminal\functions\keyboard.py modbus_terminal\functions\logging_setup.py modbus_terminal\functions\modbus_client.py modbus_terminal\functions\prompts.py modbus_terminal\functions\tooltip.py modbus_terminal\functions\write_values.py modbus_terminal\version.py
```

## Logging

- Fehlerprotokolle werden unter `./logs` abgelegt.
- Jede Datei enthaelt einen Zeitstempel im Dateinamen.
- Der Batch-Starter verkleinert den Logordner vor dem Start automatisch, falls er groesser als `100 MB` ist.
- Zielgroesse nach Bereinigung ist kleiner als `50 MB`.
- Erfolgreiche Lese- und Schreibzugriffe werden ebenfalls mitprotokolliert.

## GUI Statusanzeige

- Der Wiederholungsmodus besitzt eine sichtbare Live-Anzeige in der GUI.
- Solange Polling aktiv ist, blinkt die Status-Lampe bei unveraenderter Buttongroesse.
- Der Text des Buttons `Wiederholt lesen` bleibt bewusst fest stehen.

## CSV-Export

- Exportdateien werden standardmaessig unter `./exports` abgelegt.
- Jede Datei enthaelt die gelesenen Registernummern und die dazugehoerigen Typwerte pro Register.
- Die GUI zeigt dieselben Exportdaten parallel in einer eigenen Tab-Ansicht.

## Unterstuetzte Function Codes

- `01 Read Coils`
- `02 Read Discrete Inputs`
- `03 Read Holding Registers`
- `04 Read Input Registers`
- `06 Write Single Register` fuer GUI-Schreibzugriffe mit genau einem Register
- `16 Write Multiple Registers` fuer GUI-Schreibzugriffe mit mehreren Registern
