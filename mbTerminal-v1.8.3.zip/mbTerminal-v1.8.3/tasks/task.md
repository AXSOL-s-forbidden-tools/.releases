Halte dich stets an alle dir Verfügbaren `AGENTS.md` Dateien!

# Modbus Terminal
Baue mir eine Terminal Anwendung (python, batch, egal...), mit der ich über ModbusTCP Telegrame empfangen kann.

Ich möchte folgende Dinge über deine Terminal-Abfrage angeben können:
- Ziel Server (Modbus Server)
- Ziel Port (Standar: 502)
- Function Code für Lesen, Schreiben soll vorerst NICHT unterstüzt werden
- Start Adresse ab der gelesen werden soll
- Länge über wie viele Adressen gelesen werden soll
- Länge des zu erwarteten Typs (DINT = 2, INT = 1, FLOAT = 2, ...)

Ausgabe sollen alle Möglichen Typen anhand mit entsprechender Länge sein. Z.b: bei Länge 2: DINT, FLOAT, UDINT, ...
Zusätzlich soll immer Char/String mit ausgebeben werden.


Ich möchte die Modbus Abfrage auch wiederholen können, z.B. "lese alle 5 Sekunden", was ich mit einer Abbruch-Tasten-Kombination dann beenden kann.

ich möchte eine zusätzliche Abbruch Kombination, mit der ich eine neue Start-Adresse, Länge, Typlänge, Function angeben kann. Port und IP-Adresse sollen gleich bleiben bzw. nicht erneut eingegeben werden.

baue mir hierfür eine GUI mit entsprechenden buttons und textfeldern zum parametrieren.
Baue zusätzlich dazu eine Batch-Datei mit der ich die GUI via Doppelklick starten kann.
Fehlende Python-Installationen sollen während der Batch-Ausführung mit Rückfrage nachinstalliert werden können.
Fehlende Python Bibliothekn sollen in einer .env Umgebung installiert werden.

Beim Start der Batch-Datei, soll nach erfolgreichem Öffnen der GUI das Terminal mit der ausführenden Batch nicht mehr offen bleiben.
Die GUI soll logs in einen Ordner ablegen, falls Fehler auftregen.
Die Logs sollen in den Ordner `./logs` und mit Zeitstempeln versehen werden.
Wenn der Ordner beim Ausführen der Batch-Datei größer als 100 MB ist, sollen die älteste Logs entsprechend gelöscht werden, dass der Ordner kleiner als 50 MB ist.

Ergänze auch eine Version-Nummer im gesamten Projekt.
Achte bitte auch auf die neuen Anweisungen in AGENTS.md , was das `./docs` Verzeichnis betrifft.

Füge die Funktion hinzu (terminal + gui), die aktuell gelesenen Register als CSV Datei zu exportieren. Die CSV Datei soll dabei auch die Registernummern die gelesen wurden enthalten.


Baue in der Ausgabe auf der GUI eine Tab-View. Die erste Tab so wie bisher, die zweite bitte genau die DArstellung der exportierbaren CSV.
Es sollen alle möglichen Typen für alle Register angezeigt werden (UINT, INT, UDINT, DINT, FLOAT, STRING, Char), auch in der CSV!

In der Textuellen Ausgabe schreibe bitte für das erste Register nicht "Register 0: ..." sondern starte immer mit der jeweiligen Adresse.
Also wenn STartadresse 101, dann "Register 101: ROH=...."


erweitere die möglichen Function Codes um ALLE möglichen Lese-FunctionCodes. Prüfe hierzu die modbus TCP dokumentationen im Internet.

Ergänze sinnvolle Tooltips für die GUI.

Ergänze die Möglichkeit ModbusRegsiter zu schreiben. Hierür soll auf der GUI ein "zu schreibender Wert" eingeführt werden. Bei Float-Zahlen soll es egal sein, ob Punkt `.` oder Komma `,` als Nachkommastellen Zeichen verwendet wird.
Es soll automatisch der entsprechende Typ anhand der zu schreibendenen Typ-Länge und des Werts in "zu schreibender Wert" ermittelt werden.

Lesen und Schreiben soll entsprechend in den logs files hinterlegt werden, damit nachvollzogen werden kann, wann welche Werte in welche Register gelesen/geschrieben wurden.
tooltips auch für eingabefelder

bei wiederholten lesen soll an der gui etwas angezeigt werden, das wiedoerholtes lesen gerade aktiv ist (button blinkt, lampe geht an, .... irgend was cooles).
Der Text des buttons soll sich bei aktivem wiederholten lesen nicht verändern, weil sich sonst auch die größe des buttons ständig ändert.

# Ergänzungen

Bei Modbus registern die länger als ein `WORD` kann es relevant sein, wie die Bytes aufgebaut sind (big endian, little endian). Ich möchte ein dropdown menü zum auswählen, ob die Werte als big / little endian eingelesen werden.
Die entsprechende Auswertung, soll natürlich auch für die Anzeige als DINT/FLOAT dann dienen.