# Modbus Terminal

Small Modbus TCP application with a Windows GUI and an optional CLI.

## Version

`1.8.3`

## Project Description

The application lets you configure target host, port, function code, start address, register count, expected word length, and byte order. It then reads Modbus TCP values and shows multiple possible interpretations of the returned data.

Supported read function codes:

- `1` (`Read Coils`)
- `2` (`Read Discrete Inputs`)
- `3` (`Read Holding Registers`)
- `4` (`Read Input Registers`)

Write access for holding registers is available in the GUI.

## Setup

Requirements:

- Windows for the batch launcher
- Python 3.10 or newer

There are currently no extra Python dependencies. The batch file still prepares a local virtual environment in `.env` so future dependencies stay isolated.

## Important Commands

Start the GUI by double-clicking:

```bat
start_gui.bat
```

Start the GUI from a terminal:

```bash
python main.py
```

Start the CLI instead of the GUI:

```bash
python main.py --cli
```

Show help:

```bash
python main.py --help
```

## Usage

1. Start `start_gui.bat` or run `python main.py`.
2. Enter the Modbus server hostname or IP address.
3. Confirm or change the port. The default is `502`.
4. Select function code `1`, `2`, `3`, or `4`.
5. Set start address, register count, and expected word length.
6. Select `big` or `little` byte order for values larger than one register.
7. Optionally enter a polling interval.
8. Use `Einmal lesen` for a single request or `Wiederholt lesen` for cyclic polling.
9. Use `Stoppen` to end an active polling cycle.
10. Use `Nur Leseparameter neu setzen` to reset function code, start address, register count, word length, byte order, and interval while keeping host and port.
11. Use `Schreiben` to write holding registers directly from the GUI.
12. Use `CSV exportieren` to save the latest successful register snapshot.
13. The GUI output is split into `Typen` and `CSV Vorschau`.
14. The GUI shows an active polling state with a blinking status indicator.

The batch file checks on startup:

- whether Python is available
- whether Python should be installed through `winget` after confirmation
- whether the local `.env` environment must be created
- whether `pip` is available in that environment
- whether `requirements.txt` should be installed inside that environment

An optional `pip` update may still fail on Windows because of file locks. In that case the application continues to start.

## Logging

- Error logs are stored in `./logs`.
- Each log file includes a timestamp in its filename.
- Before the GUI starts, `start_gui.bat` cleans the log folder automatically if it grows beyond `100 MB`.
- Cleanup removes the oldest files until the folder drops below `50 MB`.
- Successful read and write operations are logged with target, function code, start address, and values.

## CSV Export

- GUI: export through `CSV exportieren`
- CLI single read: prompt shown after the read completes
- CLI polling mode: export the latest values with `Ctrl+E`
- The CSV contains `Registernummer`, `Registerwert`, `UINT`, `INT`, `UDINT`, `DINT`, `FLOAT`, `STRING`, and `Char`
- `UDINT`, `DINT`, and `FLOAT` follow the currently selected byte order
- The second GUI tab shows the exact exportable CSV structure

## Value Output

- The application shows all supported standard interpretations for the available register data
- This includes at least `UINT`, `INT`, `UDINT`, `DINT`, `FLOAT`, `STRING`, and `Char`
- Text output always starts with the real configured address, for example `Register 101`
- Multi-register values such as `DINT` and `FLOAT` are decoded with the selected `big` or `little` byte order
- For function code `1` and `2`, bit values are displayed through the same output flow

## Function Codes

- Implemented read codes are `01`, `02`, `03`, and `04`
- GUI write actions for holding registers automatically use `06` or `16`
- Serial-only special cases such as `07`, `11`, or `12` are not part of the current Modbus TCP scope
- Special read variants such as `20`, `24`, or `43/14` need additional request parameters that the current input model does not expose

## Writing

- The `Zu schreibender Wert` field is used for GUI write operations
- The write type is detected automatically from word length and input value
- Supported automatic target types include `UINT`, `INT`, `UDINT`, `DINT`, `FLOAT`, `DOUBLE`, `STRING`, `LINT`, and `ULINT`
- Floating-point values accept both `.` and `,` as decimal separators
- One register uses function code `06`, multiple registers use function code `16`

## Tooltips

- The GUI contains tooltips for buttons, text inputs, and the byte-order dropdown

## Repeated Reading

- The GUI shows an active repeated-read state through a visible status lamp
- The text of the `Wiederholt lesen` button stays unchanged so the button width remains stable
- Active state is signaled through the lamp and the `Aktiv` or `Inaktiv` status label

## Documentation

- Architecture: `docs/architecture.md`
- Development: `docs/development.md`
- GUI startup flow: `docs/flows/gui-startup.md`
- GUI and logging decision: `docs/decisions/001-gui-und-logging.md`
