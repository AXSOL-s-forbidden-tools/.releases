"""Zentrale Versionsnummer fuer das gesamte Projekt."""

__version__ = "1.8.3"
