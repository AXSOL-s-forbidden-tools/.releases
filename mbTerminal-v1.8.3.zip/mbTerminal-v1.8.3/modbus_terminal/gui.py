"""Grafische Oberflaeche fuer das Modbus-Terminal."""

from __future__ import annotations

import logging
import tkinter as tk
from queue import Empty, Queue
from tkinter import filedialog, messagebox, ttk

from modbus_terminal.functions.audit_logging import log_write
from modbus_terminal.functions.csv_export import build_default_csv_path, export_registers_to_csv
from modbus_terminal.functions.display import build_csv_rows
from modbus_terminal.functions.gui_worker import PollRequest, PollResult, PollingController
from modbus_terminal.functions.logging_setup import setup_logging
from modbus_terminal.functions.modbus_client import ModbusReadError, write_registers
from modbus_terminal.functions.tooltip import ToolTip
from modbus_terminal.functions.write_values import prepare_write_registers
from modbus_terminal.version import __version__

LOGGER = logging.getLogger(__name__)


class ModbusTerminalApp:
    """Kapselt die GUI und verbindet Eingabefelder mit der Modbus-Abfrage."""

    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title(f"Modbus Terminal v{__version__}")
        self.root.geometry("860x620")

        self.result_queue: Queue[PollResult] = Queue()
        self.polling_controller = PollingController()

        self.host_var = tk.StringVar()
        self.port_var = tk.StringVar(value="502")
        self.function_code_var = tk.StringVar(value="3")
        self.start_address_var = tk.StringVar(value="0")
        self.register_count_var = tk.StringVar(value="2")
        self.expected_word_length_var = tk.StringVar(value="2")
        self.byte_order_var = tk.StringVar(value="big")
        self.timeout_var = tk.StringVar(value="5.0")
        self.poll_interval_var = tk.StringVar()
        self.write_value_var = tk.StringVar()
        self.status_var = tk.StringVar(value="Bereit.")
        self.last_registers: list[int] = []
        self.last_start_address = 0
        self.last_byte_order = "big"
        self.polling_indicator_on = False

        self._build_layout()
        self._install_tooltips()
        self._schedule_queue_processing()
        self._schedule_polling_indicator()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_layout(self) -> None:
        """Erzeugt Eingabefelder, Buttons und Ausgabebereich."""
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(1, weight=1)

        form_frame = ttk.LabelFrame(self.root, text="Verbindung und Leseparameter", padding=12)
        form_frame.grid(row=0, column=0, sticky="nsew", padx=12, pady=(12, 6))
        form_frame.columnconfigure(1, weight=1)
        form_frame.columnconfigure(3, weight=1)

        self.host_entry = self._add_entry(form_frame, "Zielserver / IP", self.host_var, 0, 0)
        self.port_entry = self._add_entry(form_frame, "Zielport", self.port_var, 0, 2)
        self.function_code_entry = self._add_entry(form_frame, "Function Code", self.function_code_var, 1, 0)
        self.start_address_entry = self._add_entry(form_frame, "Startadresse", self.start_address_var, 1, 2)
        self.register_count_entry = self._add_entry(form_frame, "Anzahl Register", self.register_count_var, 2, 0)
        self.expected_word_length_entry = self._add_entry(form_frame, "Typlaenge in Registern", self.expected_word_length_var, 2, 2)
        self.byte_order_combobox = self._add_combobox(
            form_frame,
            "Byte-Reihenfolge",
            self.byte_order_var,
            ("big", "little"),
            3,
            0,
        )
        self.timeout_entry = self._add_entry(form_frame, "Timeout in Sekunden", self.timeout_var, 3, 2)
        self.poll_interval_entry = self._add_entry(form_frame, "Intervall in Sekunden", self.poll_interval_var, 4, 0)
        self.write_value_entry = self._add_entry(form_frame, "Zu schreibender Wert", self.write_value_var, 4, 2)

        button_frame = ttk.Frame(form_frame)
        button_frame.grid(row=5, column=0, columnspan=4, sticky="w", pady=(12, 0))

        self.read_once_button = ttk.Button(button_frame, text="Einmal lesen", command=self._read_once)
        self.read_once_button.grid(row=0, column=0, padx=(0, 8))
        self.poll_button = ttk.Button(button_frame, text="Wiederholt lesen", command=self._start_polling)
        self.poll_button.grid(row=0, column=1, padx=(0, 8))
        self.reset_button = ttk.Button(button_frame, text="Nur Leseparameter neu setzen", command=self._reset_read_parameters)
        self.reset_button.grid(row=0, column=2, padx=(0, 8))
        self.write_button = ttk.Button(button_frame, text="Schreiben", command=self._write_value)
        self.write_button.grid(row=0, column=3, padx=(0, 8))
        self.export_button = ttk.Button(button_frame, text="CSV exportieren", command=self._export_csv)
        self.export_button.grid(row=0, column=4, padx=(0, 8))
        self.stop_button = ttk.Button(button_frame, text="Stoppen", command=self._stop_polling)
        self.stop_button.grid(row=0, column=5)

        indicator_frame = ttk.Frame(form_frame)
        indicator_frame.grid(row=6, column=0, columnspan=4, sticky="w", pady=(10, 0))

        ttk.Label(indicator_frame, text="Wiederholtes Lesen:").grid(row=0, column=0, sticky="w")
        self.polling_indicator = tk.Canvas(indicator_frame, width=18, height=18, highlightthickness=0)
        self.polling_indicator.grid(row=0, column=1, padx=(8, 0))
        self.polling_indicator_oval = self.polling_indicator.create_oval(2, 2, 16, 16, fill="#6b7280", outline="")
        self.polling_indicator_label = ttk.Label(indicator_frame, text="Inaktiv")
        self.polling_indicator_label.grid(row=0, column=2, padx=(8, 0), sticky="w")

        output_frame = ttk.LabelFrame(self.root, text="Ausgabe", padding=12)
        output_frame.grid(row=1, column=0, sticky="nsew", padx=12, pady=6)
        output_frame.columnconfigure(0, weight=1)
        output_frame.rowconfigure(0, weight=1)

        self.output_tabs = ttk.Notebook(output_frame)
        self.output_tabs.grid(row=0, column=0, sticky="nsew")

        values_tab = ttk.Frame(self.output_tabs)
        values_tab.columnconfigure(0, weight=1)
        values_tab.rowconfigure(0, weight=1)
        self.output_tabs.add(values_tab, text="Typen")

        csv_tab = ttk.Frame(self.output_tabs)
        csv_tab.columnconfigure(0, weight=1)
        csv_tab.rowconfigure(0, weight=1)
        self.output_tabs.add(csv_tab, text="CSV Vorschau")

        self.output_text = tk.Text(values_tab, wrap="word", height=20)
        self.output_text.grid(row=0, column=0, sticky="nsew")
        self.output_text.configure(state="disabled")

        text_scrollbar = ttk.Scrollbar(values_tab, orient="vertical", command=self.output_text.yview)
        text_scrollbar.grid(row=0, column=1, sticky="ns")
        self.output_text.configure(yscrollcommand=text_scrollbar.set)

        self.csv_tree = ttk.Treeview(
            csv_tab,
            columns=(
                "register_number",
                "register_value",
                "uint_value",
                "int_value",
                "udint_value",
                "dint_value",
                "float_value",
                "string_value",
                "char_value",
            ),
            show="headings",
        )
        self.csv_tree.heading("register_number", text="Registernummer")
        self.csv_tree.heading("register_value", text="Registerwert")
        self.csv_tree.heading("uint_value", text="UINT")
        self.csv_tree.heading("int_value", text="INT")
        self.csv_tree.heading("udint_value", text="UDINT")
        self.csv_tree.heading("dint_value", text="DINT")
        self.csv_tree.heading("float_value", text="FLOAT")
        self.csv_tree.heading("string_value", text="STRING")
        self.csv_tree.heading("char_value", text="Char")
        self.csv_tree.column("register_number", anchor="w", width=110)
        self.csv_tree.column("register_value", anchor="w", width=110)
        self.csv_tree.column("uint_value", anchor="w", width=100)
        self.csv_tree.column("int_value", anchor="w", width=100)
        self.csv_tree.column("udint_value", anchor="w", width=120)
        self.csv_tree.column("dint_value", anchor="w", width=120)
        self.csv_tree.column("float_value", anchor="w", width=120)
        self.csv_tree.column("string_value", anchor="w", width=100)
        self.csv_tree.column("char_value", anchor="w", width=80)
        self.csv_tree.grid(row=0, column=0, sticky="nsew")

        csv_scrollbar = ttk.Scrollbar(csv_tab, orient="vertical", command=self.csv_tree.yview)
        csv_scrollbar.grid(row=0, column=1, sticky="ns")
        self.csv_tree.configure(yscrollcommand=csv_scrollbar.set)

        status_label = ttk.Label(self.root, textvariable=self.status_var, anchor="w")
        status_label.grid(row=2, column=0, sticky="ew", padx=12, pady=(0, 12))

    def _add_entry(
        self,
        parent: ttk.LabelFrame,
        label_text: str,
        text_variable: tk.StringVar,
        row: int,
        column: int,
    ) -> ttk.Entry:
        """Platziert ein Label samt Eingabefeld im Formular."""
        ttk.Label(parent, text=label_text).grid(row=row, column=column, sticky="w", padx=(0, 8), pady=4)
        entry = ttk.Entry(parent, textvariable=text_variable)
        entry.grid(
            row=row,
            column=column + 1,
            sticky="ew",
            padx=(0, 12),
            pady=4,
        )
        return entry

    def _add_combobox(
        self,
        parent: ttk.LabelFrame,
        label_text: str,
        text_variable: tk.StringVar,
        values: tuple[str, ...],
        row: int,
        column: int,
    ) -> ttk.Combobox:
        """Places a fixed dropdown in the same grid layout as the text inputs."""
        ttk.Label(parent, text=label_text).grid(row=row, column=column, sticky="w", padx=(0, 8), pady=4)
        combobox = ttk.Combobox(parent, textvariable=text_variable, values=values, state="readonly")
        combobox.grid(
            row=row,
            column=column + 1,
            sticky="ew",
            padx=(0, 12),
            pady=4,
        )
        return combobox

    def _install_tooltips(self) -> None:
        """Ergaenzt kurze Hilfetexte fuer die wichtigsten GUI-Elemente."""
        tooltip_map = [
            (self.host_entry, "Hostname oder IP-Adresse des Modbus-Servers."),
            (self.port_entry, "TCP-Port des Modbus-Servers. Standard ist 502."),
            (self.function_code_entry, "Lesefunktion 1, 2, 3 oder 4 fuer die aktuelle Abfrage."),
            (self.start_address_entry, "Erste Modbus-Adresse, ab der gelesen oder geschrieben wird."),
            (self.register_count_entry, "Anzahl der zu lesenden Adressen oder Register."),
            (self.expected_word_length_entry, "Typbreite fuer Auswertung oder automatische Schreib-Typwahl."),
            (
                self.byte_order_combobox,
                "Legt fest, ob mehrwortige Werte wie DINT oder FLOAT als big oder little endian ausgewertet werden.",
            ),
            (self.timeout_entry, "Maximale Wartezeit fuer Verbindungsaufbau und Antwort."),
            (self.poll_interval_entry, "Sekunden zwischen zwei Leseabfragen im Wiederholungsmodus."),
            (self.write_value_entry, "Wert fuer Holding-Register. Punkt oder Komma sind bei Float erlaubt."),
            (self.read_once_button, "Fuehrt genau eine Modbus-Abfrage mit den aktuellen Leseparametern aus."),
            (self.poll_button, "Startet zyklische Leseabfragen mit dem eingetragenen Intervall."),
            (self.reset_button, "Setzt Function Code, Startadresse, Registeranzahl, Typlaenge und Intervall zurueck."),
            (self.write_button, "Schreibt Holding-Register. Bei einem Register wird FC06, sonst FC16 verwendet."),
            (self.export_button, "Exportiert die zuletzt gelesenen Werte als CSV-Datei."),
            (self.stop_button, "Beendet eine laufende Wiederholungsabfrage."),
            (self.polling_indicator, "Zeigt sichtbar an, ob das wiederholte Lesen gerade aktiv ist."),
        ]
        for widget, text in tooltip_map:
            ToolTip(widget, text)

    def _build_request(self, poll_interval_override: float | None) -> PollRequest:
        """Liest und prueft alle GUI-Werte, bevor eine Abfrage gestartet wird."""
        try:
            port = int(self.port_var.get())
            function_code = int(self.function_code_var.get())
            start_address = int(self.start_address_var.get())
            register_count = int(self.register_count_var.get())
            expected_word_length = int(self.expected_word_length_var.get())
            timeout_seconds = float(self.timeout_var.get().replace(",", "."))
        except ValueError as error:
            raise ValueError("Bitte alle numerischen Felder gueltig ausfuellen.") from error

        byte_order = self.byte_order_var.get().strip().lower()

        if function_code not in {1, 2, 3, 4}:
            raise ValueError("Aktuell werden nur die Function Codes 1, 2, 3 und 4 unterstuetzt.")
        if byte_order not in {"big", "little"}:
            raise ValueError("Bitte fuer die Byte-Reihenfolge 'big' oder 'little' auswaehlen.")
        if not self.host_var.get().strip():
            raise ValueError("Bitte einen Zielserver oder eine IP-Adresse eingeben.")
        if min(port, start_address, register_count, expected_word_length) < 0:
            raise ValueError("Negative Werte sind fuer Port und Registerparameter nicht erlaubt.")
        if port < 1 or register_count < 1 or expected_word_length < 1 or timeout_seconds <= 0:
            raise ValueError("Port, Registeranzahl, Typlaenge und Timeout muessen groesser als 0 sein.")

        return PollRequest(
            host=self.host_var.get().strip(),
            port=port,
            function_code=function_code,
            start_address=start_address,
            register_count=register_count,
            expected_word_length=expected_word_length,
            byte_order=byte_order,
            timeout_seconds=timeout_seconds,
            poll_interval_seconds=poll_interval_override,
        )

    def _read_once(self) -> None:
        """Startet eine einzelne Leseabfrage."""
        self._start_request(None)

    def _start_polling(self) -> None:
        """Startet die wiederholte Abfrage mit dem gesetzten Intervall."""
        raw_interval = self.poll_interval_var.get().strip()
        if not raw_interval:
            messagebox.showerror("Fehlendes Intervall", "Bitte ein Intervall fuer die Wiederholung angeben.")
            return

        try:
            interval_seconds = float(raw_interval.replace(",", "."))
        except ValueError:
            messagebox.showerror("Ungueltiges Intervall", "Bitte ein gueltiges Intervall eingeben.")
            return

        if interval_seconds <= 0:
            messagebox.showerror("Ungueltiges Intervall", "Das Intervall muss groesser als 0 sein.")
            return

        self._start_request(interval_seconds)

    def _start_request(self, poll_interval_override: float | None) -> None:
        """Validiert die Eingaben und uebergibt die Arbeit an den Hintergrundthread."""
        try:
            request = self._build_request(poll_interval_override)
        except ValueError as error:
            messagebox.showerror("Ungueltige Eingabe", str(error))
            return

        self.status_var.set("Abfrage laeuft...")
        self.polling_controller.start(request, self.result_queue)

    def _stop_polling(self) -> None:
        """Beendet eine laufende wiederholte Abfrage."""
        self.polling_controller.stop()
        self.status_var.set("Abfrage gestoppt.")

    def _reset_read_parameters(self) -> None:
        """Setzt nur die variablen Leseparameter zurueck und laesst Host sowie Port unberuehrt."""
        self.polling_controller.stop()
        self.function_code_var.set("3")
        self.start_address_var.set("0")
        self.register_count_var.set("2")
        self.expected_word_length_var.set("2")
        self.byte_order_var.set("big")
        self.poll_interval_var.set("")
        self.write_value_var.set("")
        self.status_var.set("Leseparameter zurueckgesetzt. Host und Port bleiben erhalten.")

    def _write_value(self) -> None:
        """Schreibt den eingegebenen Wert als Holding-Register zum Zielgeraet."""
        try:
            port = int(self.port_var.get())
            start_address = int(self.start_address_var.get())
            expected_word_length = int(self.expected_word_length_var.get())
            timeout_seconds = float(self.timeout_var.get().replace(",", "."))
        except ValueError:
            messagebox.showerror("Ungueltige Eingabe", "Bitte Port, Startadresse, Typlaenge und Timeout gueltig ausfuellen.")
            return

        if not self.host_var.get().strip():
            messagebox.showerror("Ungueltige Eingabe", "Bitte einen Zielserver oder eine IP-Adresse eingeben.")
            return

        try:
            write_preparation = prepare_write_registers(self.write_value_var.get(), expected_word_length)
            used_function_code = write_registers(
                host=self.host_var.get().strip(),
                port=port,
                start_address=start_address,
                registers=write_preparation.registers,
                timeout_seconds=timeout_seconds,
            )
        except (ValueError, ModbusReadError) as error:
            messagebox.showerror("Schreiben fehlgeschlagen", str(error))
            return

        log_write(
            host=self.host_var.get().strip(),
            port=port,
            function_code=used_function_code,
            start_address=start_address,
            registers=write_preparation.registers,
            detected_type=write_preparation.type_name,
        )

        self.status_var.set(
            f"Schreiben erfolgreich. Verwendeter Typ: {write_preparation.type_name}, Function Code: {used_function_code}."
        )

    def _schedule_queue_processing(self) -> None:
        """Fragt die Ergebnisqueue regelmaessig ab, ohne die GUI zu blockieren."""
        self.root.after(150, self._process_queue)

    def _schedule_polling_indicator(self) -> None:
        """Aktualisiert periodisch die sichtbare Statusanzeige fuer Polling."""
        self.root.after(350, self._update_polling_indicator)

    def _update_polling_indicator(self) -> None:
        """Laesst Lampe und Button sichtbar auf aktives Polling reagieren."""
        if self.polling_controller.is_running():
            self.polling_indicator_on = not self.polling_indicator_on
            indicator_color = "#22c55e" if self.polling_indicator_on else "#86efac"
            self.polling_indicator.itemconfig(self.polling_indicator_oval, fill=indicator_color)
            self.polling_indicator_label.config(text="Aktiv")
        else:
            self.polling_indicator_on = False
            self.polling_indicator.itemconfig(self.polling_indicator_oval, fill="#6b7280")
            self.polling_indicator_label.config(text="Inaktiv")

        self._schedule_polling_indicator()

    def _process_queue(self) -> None:
        """Uebernimmt neue Hintergrund-Ergebnisse in die GUI."""
        try:
            while True:
                result = self.result_queue.get_nowait()
                self._apply_result(result)
        except Empty:
            pass
        finally:
            self._schedule_queue_processing()

    def _apply_result(self, result: PollResult) -> None:
        """Schreibt das Ergebnis lesbar in den Ausgabebereich."""
        self.status_var.set(result.message)
        if result.success:
            self.last_start_address = result.start_address
            self.last_registers = list(result.registers)
            self.last_byte_order = result.byte_order
            lines = [f"{item.label}: {item.value}" for item in result.decoded_values]
            self._set_output_text("\n".join(lines))
            self._set_csv_preview(self.last_start_address, self.last_registers, self.last_byte_order)
        else:
            self._append_output_text(result.message)

    def _export_csv(self) -> None:
        """Exportiert die zuletzt gelesenen Register in eine CSV-Datei."""
        if not self.last_registers:
            messagebox.showinfo("Kein Export moeglich", "Es wurden noch keine Register erfolgreich gelesen.")
            return

        default_path = build_default_csv_path()
        target_path = filedialog.asksaveasfilename(
            title="CSV-Datei speichern",
            defaultextension=".csv",
            initialdir=str(default_path.parent),
            initialfile=default_path.name,
            filetypes=[("CSV-Dateien", "*.csv"), ("Alle Dateien", "*.*")],
        )
        if not target_path:
            return

        csv_path = export_registers_to_csv(
            start_address=self.last_start_address,
            registers=self.last_registers,
            byte_order=self.last_byte_order,
            target_path=target_path,
        )
        self.status_var.set(f"CSV erfolgreich exportiert: {csv_path}")

    def _set_output_text(self, text: str) -> None:
        """Ersetzt den bisherigen Ausgabetext komplett."""
        self.output_text.configure(state="normal")
        self.output_text.delete("1.0", tk.END)
        self.output_text.insert(tk.END, text)
        self.output_text.configure(state="disabled")

    def _set_csv_preview(self, start_address: int, registers: list[int], byte_order: str) -> None:
        """Aktualisiert die zweite Registerkarte mit der exportierbaren CSV-Sicht."""
        self.csv_tree.delete(*self.csv_tree.get_children())
        for csv_row in build_csv_rows(start_address, registers, byte_order):
            self.csv_tree.insert(
                "",
                tk.END,
                values=(
                    csv_row.register_number,
                    csv_row.register_value,
                    csv_row.uint_value,
                    csv_row.int_value,
                    csv_row.udint_value,
                    csv_row.dint_value,
                    csv_row.float_value,
                    csv_row.string_value,
                    csv_row.char_value,
                ),
            )

    def _append_output_text(self, text: str) -> None:
        """Haengt eine neue Meldung an die bestehende Ausgabe an."""
        self.output_text.configure(state="normal")
        if self.output_text.index("end-1c") != "1.0":
            self.output_text.insert(tk.END, "\n\n")
        self.output_text.insert(tk.END, text)
        self.output_text.see(tk.END)
        self.output_text.configure(state="disabled")

    def _on_close(self) -> None:
        """Beendet Hintergrundabfragen sauber vor dem Schliessen des Fensters."""
        self.polling_controller.stop()
        self.root.destroy()


def main() -> None:
    """Startet die grafische Modbus-Oberflaeche."""
    log_file_path = setup_logging()
    root = tk.Tk()
    style = ttk.Style(root)
    if "vista" in style.theme_names():
        style.theme_use("vista")
    app = ModbusTerminalApp(root)
    app.status_var.set(f"Bereit. Fehlerprotokolle werden in {log_file_path} gespeichert.")
    try:
        root.mainloop()
    except Exception:
        LOGGER.exception("Unerwarteter Fehler in der GUI-Hauptschleife.")
        raise
