"""Interaktive Kommandozeilenoberflaeche fuer Modbus TCP."""

from __future__ import annotations

import argparse

from modbus_terminal.functions.csv_export import export_registers_to_csv
from modbus_terminal.functions.display import print_register_values
from modbus_terminal.functions.keyboard import wait_for_next_action
from modbus_terminal.functions.modbus_client import ModbusReadError, read_registers
from modbus_terminal.functions.prompts import ask_read_parameters, ask_runtime_config


def build_parser() -> argparse.ArgumentParser:
    """Erzeugt den Parser fuer optionale Startparameter."""
    parser = argparse.ArgumentParser(
        description="Interaktives Terminal zum Lesen von Modbus-TCP-Registern."
    )
    return parser


def run_polling() -> None:
    """Fuehrt genau eine oder mehrere Leseabfragen aus."""
    config = ask_runtime_config()
    last_registers: list[int] = []

    try:
        while True:
            registers = read_registers(
                host=config.host,
                port=config.port,
                function_code=config.function_code,
                start_address=config.start_address,
                register_count=config.register_count,
                timeout_seconds=config.timeout_seconds,
            )
            print_register_values(
                registers=registers,
                expected_word_length=config.expected_word_length,
                start_address=config.start_address,
                byte_order=config.byte_order,
            )
            last_registers = list(registers)

            if config.poll_interval_seconds is None:
                _ask_for_csv_export(config.start_address, last_registers, config.byte_order)
                break

            print(
                f"\nNaechste Abfrage in {config.poll_interval_seconds:g} Sekunden. "
                "Abbruch mit Ctrl+C, neue Leseparameter mit Ctrl+R, CSV-Export mit Ctrl+E."
            )
            next_action = wait_for_next_action(config.poll_interval_seconds)
            if next_action == "reconfigure":
                print("\nNeue Leseparameter eingeben. Host und Port bleiben erhalten.\n")
                read_parameters = ask_read_parameters()
                config.function_code = read_parameters.function_code
                config.start_address = read_parameters.start_address
                config.register_count = read_parameters.register_count
                config.expected_word_length = read_parameters.expected_word_length
                config.byte_order = read_parameters.byte_order
                config.poll_interval_seconds = read_parameters.poll_interval_seconds
            if next_action == "export":
                csv_path = export_registers_to_csv(config.start_address, last_registers, config.byte_order)
                print(f"\nCSV exportiert nach: {csv_path}")
    except KeyboardInterrupt:
        print("\nAbfrage durch Benutzer beendet.")
    except ModbusReadError as error:
        print(f"\nModbus-Fehler: {error}")


def _ask_for_csv_export(start_address: int, registers: list[int], byte_order: str) -> None:
    """Bietet nach einer Einzelabfrage den CSV-Export der aktuellen Register an."""
    export_choice = input("\nAktuelle Register als CSV exportieren? [j/N]: ").strip().lower()
    if export_choice not in {"j", "ja", "y", "yes"}:
        return

    csv_path = export_registers_to_csv(start_address, registers, byte_order)
    print(f"CSV exportiert nach: {csv_path}")


def main() -> None:
    """Startet die Anwendung."""
    parser = build_parser()
    parser.parse_args()
    run_polling()
