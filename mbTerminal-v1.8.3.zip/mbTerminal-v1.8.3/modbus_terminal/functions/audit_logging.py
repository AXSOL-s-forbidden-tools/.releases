"""Hilfsfunktionen fuer nachvollziehbare Lese- und Schreibprotokolle."""

from __future__ import annotations

import logging


LOGGER = logging.getLogger("modbus_terminal.audit")


def log_read(
    host: str,
    port: int,
    function_code: int,
    start_address: int,
    register_count: int,
    registers: list[int],
) -> None:
    """Schreibt einen erfolgreichen Lesezugriff in die Logdatei."""
    LOGGER.info(
        "READ host=%s port=%s fc=%s start=%s count=%s values=%s",
        host,
        port,
        function_code,
        start_address,
        register_count,
        registers,
    )


def log_write(
    host: str,
    port: int,
    function_code: int,
    start_address: int,
    registers: list[int],
    detected_type: str,
) -> None:
    """Schreibt einen erfolgreichen Schreibzugriff in die Logdatei."""
    LOGGER.info(
        "WRITE host=%s port=%s fc=%s start=%s type=%s values=%s",
        host,
        port,
        function_code,
        start_address,
        detected_type,
        registers,
    )
