"""Kleiner Modbus-TCP-Client auf Basis von Python-Standardbibliothek."""

from __future__ import annotations

import socket
import struct


class ModbusReadError(Exception):
    """Fehler beim Lesen ueber Modbus TCP."""


def _read_bit_values(payload: bytes, item_count: int) -> list[int]:
    """Entpackt bitweise Rueckgabedaten fuer Coils oder Discrete Inputs."""
    values: list[int] = []
    for byte_value in payload:
        for bit_index in range(8):
            values.append((byte_value >> bit_index) & 0x01)
            if len(values) == item_count:
                return values
    return values


def _parse_bit_response(response: bytes, expected_function_code: int, item_count: int) -> list[int]:
    """Prueft Bit-Antworten fuer Function Code 1 und 2."""
    byte_count = response[8]
    payload = response[9:]
    if len(payload) != byte_count:
        raise ModbusReadError("Antwortdaten sind unvollstaendig.")

    values = _read_bit_values(payload, item_count)
    if len(values) != item_count:
        raise ModbusReadError("Antwort enthaelt weniger Bitwerte als angefordert.")
    return values


def _parse_register_response(response: bytes, register_count: int) -> list[int]:
    """Prueft Register-Antworten fuer Function Code 3 und 4."""
    expected_byte_count = register_count * 2
    byte_count = response[8]
    if byte_count != expected_byte_count:
        raise ModbusReadError(
            f"Unerwartete Nutzdatenlaenge: erwartet {expected_byte_count} Bytes, erhalten {byte_count}."
        )

    payload = response[9:]
    if len(payload) != expected_byte_count:
        raise ModbusReadError("Antwortdaten sind unvollstaendig.")

    registers: list[int] = []
    for index in range(0, len(payload), 2):
        registers.append(struct.unpack(">H", payload[index:index + 2])[0])
    return registers


def _build_request(transaction_id: int, function_code: int, start_address: int, register_count: int) -> bytes:
    """Erzeugt ein Modbus-TCP-Telegramm fuer einen Lesezugriff."""
    protocol_id = 0
    unit_id = 1
    pdu = struct.pack(">BHH", function_code, start_address, register_count)
    mbap_header = struct.pack(">HHHB", transaction_id, protocol_id, len(pdu) + 1, unit_id)
    return mbap_header + pdu


def _build_write_single_register_request(transaction_id: int, start_address: int, register_value: int) -> bytes:
    """Erzeugt ein Telegramm fuer Function Code 6."""
    protocol_id = 0
    unit_id = 1
    pdu = struct.pack(">BHH", 6, start_address, register_value)
    mbap_header = struct.pack(">HHHB", transaction_id, protocol_id, len(pdu) + 1, unit_id)
    return mbap_header + pdu


def _build_write_multiple_registers_request(transaction_id: int, start_address: int, registers: list[int]) -> bytes:
    """Erzeugt ein Telegramm fuer Function Code 16."""
    protocol_id = 0
    unit_id = 1
    register_payload = b"".join(register.to_bytes(2, byteorder="big", signed=False) for register in registers)
    pdu = struct.pack(">BHHB", 16, start_address, len(registers), len(register_payload)) + register_payload
    mbap_header = struct.pack(">HHHB", transaction_id, protocol_id, len(pdu) + 1, unit_id)
    return mbap_header + pdu


def _recv_exact(sock: socket.socket, byte_count: int) -> bytes:
    """Liest exakt die benoetigte Byteanzahl aus dem Socket."""
    received = bytearray()
    while len(received) < byte_count:
        chunk = sock.recv(byte_count - len(received))
        if not chunk:
            raise ModbusReadError("Verbindung wurde waehrend der Antwort geschlossen.")
        received.extend(chunk)
    return bytes(received)


def _parse_response(response: bytes, expected_transaction_id: int, expected_function_code: int, register_count: int) -> list[int]:
    """Prueft Antwortheader und extrahiert die Registerwerte."""
    if len(response) < 9:
        raise ModbusReadError("Antwort ist zu kurz und unvollstaendig.")

    transaction_id, protocol_id, length, unit_id = struct.unpack(">HHHB", response[:7])
    function_code = response[7]

    if transaction_id != expected_transaction_id:
        raise ModbusReadError("Antwort gehoert nicht zur gesendeten Anfrage.")
    if protocol_id != 0:
        raise ModbusReadError("Ungueltige Modbus-Protokollkennung in der Antwort.")
    if unit_id != 1:
        raise ModbusReadError("Unerwartete Unit-ID in der Antwort.")
    if length != len(response[6:]):
        raise ModbusReadError("Laengenfeld der Antwort passt nicht zum Paketinhalt.")

    if function_code == expected_function_code + 0x80:
        exception_code = response[8] if len(response) > 8 else None
        raise ModbusReadError(f"Modbus-Exception empfangen, Code: {exception_code}")
    if function_code != expected_function_code:
        raise ModbusReadError("Antwort enthaelt einen anderen Function Code als angefragt.")

    if expected_function_code in {1, 2}:
        return _parse_bit_response(response, expected_function_code, register_count)
    if expected_function_code in {3, 4}:
        return _parse_register_response(response, register_count)

    raise ModbusReadError(f"Function Code {expected_function_code} wird aktuell nicht unterstuetzt.")


def _parse_write_response(
    response: bytes,
    expected_transaction_id: int,
    expected_function_code: int,
    start_address: int,
    register_count: int,
) -> None:
    """Prueft Schreibantworten fuer Function Code 6 und 16."""
    if len(response) < 12:
        raise ModbusReadError("Schreibantwort ist zu kurz und unvollstaendig.")

    transaction_id, protocol_id, length, unit_id = struct.unpack(">HHHB", response[:7])
    function_code = response[7]

    if transaction_id != expected_transaction_id:
        raise ModbusReadError("Antwort gehoert nicht zur gesendeten Schreibanfrage.")
    if protocol_id != 0:
        raise ModbusReadError("Ungueltige Modbus-Protokollkennung in der Schreibantwort.")
    if unit_id != 1:
        raise ModbusReadError("Unerwartete Unit-ID in der Schreibantwort.")
    if length != len(response[6:]):
        raise ModbusReadError("Laengenfeld der Schreibantwort passt nicht zum Paketinhalt.")
    if function_code == expected_function_code + 0x80:
        exception_code = response[8] if len(response) > 8 else None
        raise ModbusReadError(f"Modbus-Exception beim Schreiben, Code: {exception_code}")
    if function_code != expected_function_code:
        raise ModbusReadError("Antwort enthaelt einen anderen Function Code als die Schreibanfrage.")

    returned_address, returned_count_or_value = struct.unpack(">HH", response[8:12])
    if returned_address != start_address:
        raise ModbusReadError("Die Schreibantwort bestaetigt eine andere Startadresse als angefragt.")
    if expected_function_code == 16 and returned_count_or_value != register_count:
        raise ModbusReadError("Die Schreibantwort bestaetigt eine andere Registeranzahl als angefragt.")


def read_registers(
    host: str,
    port: int,
    function_code: int,
    start_address: int,
    register_count: int,
    timeout_seconds: float,
) -> list[int]:
    """Stellt eine TCP-Verbindung her und liest Registerwerte."""
    transaction_id = 1
    request = _build_request(
        transaction_id=transaction_id,
        function_code=function_code,
        start_address=start_address,
        register_count=register_count,
    )

    try:
        with socket.create_connection((host, port), timeout=timeout_seconds) as sock:
            sock.sendall(request)
            header = _recv_exact(sock, 7)
            # Das Laengenfeld enthaelt Unit-ID plus PDU. Die Unit-ID steckt
            # bereits im Header und wird deshalb hier wieder abgezogen.
            remaining_length = struct.unpack(">H", header[4:6])[0] - 1
            body = _recv_exact(sock, remaining_length)
    except TimeoutError as error:
        raise ModbusReadError("Zeitueberschreitung beim Verbindungsaufbau oder Lesen.") from error
    except OSError as error:
        raise ModbusReadError(f"Netzwerkfehler: {error}") from error

    return _parse_response(
        response=header + body,
        expected_transaction_id=transaction_id,
        expected_function_code=function_code,
        register_count=register_count,
    )


def write_registers(
    host: str,
    port: int,
    start_address: int,
    registers: list[int],
    timeout_seconds: float,
) -> int:
    """Schreibt ein oder mehrere Holding-Register ueber Modbus TCP."""
    if not registers:
        raise ModbusReadError("Es wurden keine Register zum Schreiben uebergeben.")

    transaction_id = 2
    function_code = 6 if len(registers) == 1 else 16
    if function_code == 6:
        request = _build_write_single_register_request(transaction_id, start_address, registers[0])
    else:
        request = _build_write_multiple_registers_request(transaction_id, start_address, registers)

    try:
        with socket.create_connection((host, port), timeout=timeout_seconds) as sock:
            sock.sendall(request)
            header = _recv_exact(sock, 7)
            remaining_length = struct.unpack(">H", header[4:6])[0] - 1
            body = _recv_exact(sock, remaining_length)
    except TimeoutError as error:
        raise ModbusReadError("Zeitueberschreitung beim Schreibzugriff.") from error
    except OSError as error:
        raise ModbusReadError(f"Netzwerkfehler beim Schreiben: {error}") from error

    _parse_write_response(header + body, transaction_id, function_code, start_address, len(registers))
    return function_code
