"""CSV-Export fuer gelesene Modbus-Register."""

from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

from modbus_terminal.functions.display import ByteOrder, build_csv_rows


def build_default_csv_path() -> Path:
    """Erzeugt einen gut auffindbaren Standardpfad fuer Exporte."""
    export_directory = Path("exports")
    export_directory.mkdir(exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return export_directory / f"modbus_register_{timestamp}.csv"


def export_registers_to_csv(
    start_address: int,
    registers: list[int],
    byte_order: ByteOrder = "big",
    target_path: str | Path | None = None,
) -> Path:
    """Schreibt Registernummer und Typwerte pro Register in eine CSV-Datei."""
    csv_path = Path(target_path) if target_path is not None else build_default_csv_path()
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    csv_rows = build_csv_rows(start_address=start_address, registers=registers, byte_order=byte_order)

    with csv_path.open("w", encoding="utf-8", newline="") as csv_file:
        writer = csv.writer(csv_file, delimiter=";")
        writer.writerow(
            [
                "Registernummer",
                "Registerwert",
                "UINT",
                "INT",
                "UDINT",
                "DINT",
                "FLOAT",
                "STRING",
                "Char",
            ]
        )
        for csv_row in csv_rows:
            writer.writerow(
                [
                    csv_row.register_number,
                    csv_row.register_value,
                    csv_row.uint_value,
                    csv_row.int_value,
                    csv_row.udint_value,
                    csv_row.dint_value,
                    csv_row.float_value,
                    csv_row.string_value,
                    csv_row.char_value,
                ]
            )

    return csv_path
