"""Hilfsfunktionen zum Ermitteln schreibbarer Registerwerte."""

from __future__ import annotations

import struct
from dataclasses import dataclass


@dataclass(slots=True)
class WritePreparation:
    """Beschreibt die automatisch ermittelte Schreibart."""

    type_name: str
    registers: list[int]


def _bytes_to_registers(payload: bytes) -> list[int]:
    """Teilt ein Bytefeld in 16-Bit-Register auf."""
    registers: list[int] = []
    for index in range(0, len(payload), 2):
        registers.append(int.from_bytes(payload[index:index + 2], byteorder="big", signed=False))
    return registers


def _is_float_value(raw_value: str) -> bool:
    """Erkennt Flieszahlen ueber Punkt oder Komma."""
    return "." in raw_value or "," in raw_value


def _prepare_string_registers(raw_value: str, expected_word_length: int) -> WritePreparation:
    """Kodiert Text als ASCII mit Null-Padding auf die gewuenschte Registerzahl."""
    encoded_value = raw_value.encode("ascii")
    max_length = expected_word_length * 2
    if len(encoded_value) > max_length:
        raise ValueError(f"Der Text ist zu lang. Erlaubt sind maximal {max_length} ASCII-Zeichen.")

    padded_value = encoded_value.ljust(max_length, b"\x00")
    return WritePreparation("STRING", _bytes_to_registers(padded_value))


def _prepare_single_register(raw_value: str) -> WritePreparation:
    """Ermittelt INT oder UINT fuer ein einzelnes Register."""
    numeric_value = int(raw_value)
    if 0 <= numeric_value <= 0xFFFF:
        return WritePreparation("UINT", [numeric_value])
    if -0x8000 <= numeric_value <= 0x7FFF:
        register_value = int.from_bytes(struct.pack(">h", numeric_value), byteorder="big", signed=False)
        return WritePreparation("INT", [register_value])
    raise ValueError("Der Wert passt nicht in ein einzelnes 16-Bit-Register.")


def _prepare_two_registers(raw_value: str) -> WritePreparation:
    """Ermittelt FLOAT, DINT, UDINT oder STRING fuer zwei Register."""
    if _is_float_value(raw_value):
        numeric_value = float(raw_value.replace(",", "."))
        return WritePreparation("FLOAT", _bytes_to_registers(struct.pack(">f", numeric_value)))

    try:
        numeric_value = int(raw_value)
    except ValueError:
        return _prepare_string_registers(raw_value, 2)

    if 0 <= numeric_value <= 0xFFFFFFFF:
        return WritePreparation("UDINT", _bytes_to_registers(struct.pack(">I", numeric_value)))
    if -0x80000000 <= numeric_value <= 0x7FFFFFFF:
        return WritePreparation("DINT", _bytes_to_registers(struct.pack(">i", numeric_value)))
    raise ValueError("Der Wert passt nicht in zwei Register.")


def _prepare_four_registers(raw_value: str) -> WritePreparation:
    """Ermittelt DOUBLE, LINT, ULINT oder STRING fuer vier Register."""
    if _is_float_value(raw_value):
        numeric_value = float(raw_value.replace(",", "."))
        return WritePreparation("DOUBLE", _bytes_to_registers(struct.pack(">d", numeric_value)))

    try:
        numeric_value = int(raw_value)
    except ValueError:
        return _prepare_string_registers(raw_value, 4)

    if 0 <= numeric_value <= 0xFFFFFFFFFFFFFFFF:
        return WritePreparation("ULINT", _bytes_to_registers(struct.pack(">Q", numeric_value)))
    if -0x8000000000000000 <= numeric_value <= 0x7FFFFFFFFFFFFFFF:
        return WritePreparation("LINT", _bytes_to_registers(struct.pack(">q", numeric_value)))
    raise ValueError("Der Wert passt nicht in vier Register.")


def prepare_write_registers(raw_value: str, expected_word_length: int) -> WritePreparation:
    """Leitet aus Eingabewert und Typbreite die zu schreibenden Register ab."""
    stripped_value = raw_value.strip()
    if not stripped_value:
        raise ValueError("Bitte einen Wert zum Schreiben eingeben.")

    if expected_word_length == 1:
        try:
            return _prepare_single_register(stripped_value)
        except ValueError:
            return _prepare_string_registers(stripped_value, 1)
    if expected_word_length == 2:
        return _prepare_two_registers(stripped_value)
    if expected_word_length == 4:
        return _prepare_four_registers(stripped_value)

    return _prepare_string_registers(stripped_value, expected_word_length)
