"""Hilfsfunktionen fuer das Modbus-Terminal."""
