"""Ausgabe und Interpretation gelesener Register."""

from __future__ import annotations

import struct
from dataclasses import dataclass
from typing import Literal
from typing import Callable

ByteOrder = Literal["big", "little"]


@dataclass(slots=True)
class DecodedValue:
    """Beschreibt einen einzelnen lesbaren Ausgabewert fuer GUI und CLI."""

    label: str
    value: str


@dataclass(slots=True)
class CsvRow:
    """Beschreibt eine einzelne Zeile der exportierbaren CSV-Ansicht."""

    register_number: int
    register_value: int
    uint_value: str
    int_value: str
    udint_value: str
    dint_value: str
    float_value: str
    string_value: str
    char_value: str


def _registers_to_bytes(registers: list[int]) -> bytes:
    """Wandelt 16-Bit-Register in ein zusammenhaengendes Bytefeld um."""
    payload = bytearray()
    for register in registers:
        payload.extend(register.to_bytes(2, byteorder="big", signed=False))
    return bytes(payload)


def _register_payload(register_value: int) -> bytes:
    """Erzeugt das Bytefeld eines einzelnen Registers."""
    return register_value.to_bytes(2, byteorder="big", signed=False)


def _apply_byte_order(payload: bytes, byte_order: ByteOrder) -> bytes:
    """Adjusts multi-register values so they match the selected byte order."""
    if len(payload) <= 2 or byte_order == "big":
        return payload
    return bytes(reversed(payload))


def _safe_decode(decoder: Callable[[bytes], object], payload: bytes) -> str:
    """Faengt ungueltige Bytefolgen ab und liefert eine lesbare Ausgabe."""
    try:
        return str(decoder(payload))
    except (ValueError, UnicodeDecodeError, struct.error):
        return "-"


def _string_value(payload: bytes) -> str:
    """Liest die Bytes zusaetzlich als Text, damit auch Rohdaten sichtbar bleiben."""
    text = payload.decode("ascii", errors="replace").replace("\x00", "")
    return text if text else "-"


def _char_value(payload: bytes) -> str:
    """Zeigt jedes Byte einzeln als druckbares Zeichen oder Platzhalter an."""
    characters = [chr(byte) if 32 <= byte <= 126 else "." for byte in payload]
    return "".join(characters) if characters else "-"


def _type_decoders(word_length: int) -> dict[str, Callable[[bytes], object]]:
    """Liefert passende Typauswertungen fuer die gewuenschte Registerbreite."""
    decoder_map: dict[int, dict[str, Callable[[bytes], object]]] = {
        1: {
            "INT": lambda payload: struct.unpack(">h", payload)[0],
            "UINT": lambda payload: struct.unpack(">H", payload)[0],
        },
        2: {
            "DINT": lambda payload: struct.unpack(">i", payload)[0],
            "UDINT": lambda payload: struct.unpack(">I", payload)[0],
            "FLOAT": lambda payload: struct.unpack(">f", payload)[0],
        },
        4: {
            "LINT": lambda payload: struct.unpack(">q", payload)[0],
            "ULINT": lambda payload: struct.unpack(">Q", payload)[0],
            "DOUBLE": lambda payload: struct.unpack(">d", payload)[0],
        },
    }
    return decoder_map.get(word_length, {})


def decode_register_values(
    registers: list[int],
    expected_word_length: int,
    start_address: int = 0,
    byte_order: ByteOrder = "big",
) -> list[DecodedValue]:
    """Bereitet alle Ausgabewerte in einer wiederverwendbaren Struktur auf."""
    payload = _registers_to_bytes(registers)
    decoded_values = [
        DecodedValue("Register", ", ".join(str(register) for register in registers)),
        DecodedValue("Hex", " ".join(f"{byte:02X}" for byte in payload)),
        DecodedValue("Byte-Reihenfolge", "Big Endian" if byte_order == "big" else "Little Endian"),
    ]

    for csv_row in build_csv_rows(start_address=start_address, registers=registers, byte_order=byte_order):
        decoded_values.append(
            DecodedValue(
                f"Register {csv_row.register_number}",
                (
                    f"Roh={csv_row.register_value}, "
                    f"UINT={csv_row.uint_value}, "
                    f"INT={csv_row.int_value}, "
                    f"UDINT={csv_row.udint_value}, "
                    f"DINT={csv_row.dint_value}, "
                    f"FLOAT={csv_row.float_value}, "
                    f"STRING={csv_row.string_value}, "
                    f"Char={csv_row.char_value}"
                ),
            )
        )

    if len(registers) < expected_word_length:
        decoded_values.append(
            DecodedValue(
                "Hinweis",
                "Zu wenige Register fuer die gewuenschte Typbreite. Deshalb werden nur die mit den vorhandenen Daten moeglichen Typen angezeigt.",
            )
        )

    decoded_values.append(DecodedValue("STRING gesamt", _string_value(payload)))
    decoded_values.append(DecodedValue("Char gesamt", _char_value(payload)))
    return decoded_values


def build_csv_rows(
    start_address: int,
    registers: list[int],
    byte_order: ByteOrder = "big",
) -> list[CsvRow]:
    """Bereitet die gelesenen Register fuer CSV-Export und Vorschau auf."""
    csv_rows: list[CsvRow] = []

    for offset, register_value in enumerate(registers):
        register_payload = _register_payload(register_value)
        pair_payload = b""
        if offset + 1 < len(registers):
            pair_payload = _apply_byte_order(register_payload + _register_payload(registers[offset + 1]), byte_order)

        csv_rows.append(
            CsvRow(
                register_number=start_address + offset,
                register_value=register_value,
                uint_value=_safe_decode(_type_decoders(1)["UINT"], register_payload),
                int_value=_safe_decode(_type_decoders(1)["INT"], register_payload),
                udint_value=_safe_decode(_type_decoders(2)["UDINT"], pair_payload) if len(pair_payload) == 4 else "-",
                dint_value=_safe_decode(_type_decoders(2)["DINT"], pair_payload) if len(pair_payload) == 4 else "-",
                float_value=_safe_decode(_type_decoders(2)["FLOAT"], pair_payload) if len(pair_payload) == 4 else "-",
                string_value=_string_value(register_payload),
                char_value=_char_value(register_payload),
            )
        )

    return csv_rows


def format_register_values(
    registers: list[int],
    expected_word_length: int,
    start_address: int = 0,
    byte_order: ByteOrder = "big",
) -> str:
    """Formatiert die Auswertung als Textblock fuer die CLI."""
    lines: list[str] = []
    for decoded_value in decode_register_values(registers, expected_word_length, start_address, byte_order):
        lines.append(f"{decoded_value.label}:")
        lines.append(f"  {decoded_value.value}")
    return "\n".join(lines)


def print_register_values(
    registers: list[int],
    expected_word_length: int,
    start_address: int = 0,
    byte_order: ByteOrder = "big",
) -> None:
    """Zeigt Register roh und in mehreren moeglichen Typen an."""
    print("\nGelesene Werte:")
    print(format_register_values(registers, expected_word_length, start_address, byte_order))
