"""Kleine Tooltip-Hilfe fuer Tkinter-Widgets."""

from __future__ import annotations

import tkinter as tk


class ToolTip:
    """Zeigt bei Mausberuehrung einen kurzen Hilfetext an."""

    def __init__(self, widget: tk.Widget, text: str) -> None:
        self.widget = widget
        self.text = text
        self.tooltip_window: tk.Toplevel | None = None
        widget.bind("<Enter>", self._show_tooltip)
        widget.bind("<Leave>", self._hide_tooltip)

    def _show_tooltip(self, _event: tk.Event[tk.Misc]) -> None:
        """Blendet das Tooltip in Fensternnaehe ein."""
        if self.tooltip_window is not None:
            return

        x_position = self.widget.winfo_rootx() + 20
        y_position = self.widget.winfo_rooty() + self.widget.winfo_height() + 4

        self.tooltip_window = tk.Toplevel(self.widget)
        self.tooltip_window.wm_overrideredirect(True)
        self.tooltip_window.wm_geometry(f"+{x_position}+{y_position}")

        label = tk.Label(
            self.tooltip_window,
            text=self.text,
            background="#fff8dc",
            relief="solid",
            borderwidth=1,
            justify="left",
            padx=6,
            pady=4,
        )
        label.pack()

    def _hide_tooltip(self, _event: tk.Event[tk.Misc]) -> None:
        """Entfernt das Tooltip wieder."""
        if self.tooltip_window is not None:
            self.tooltip_window.destroy()
            self.tooltip_window = None
