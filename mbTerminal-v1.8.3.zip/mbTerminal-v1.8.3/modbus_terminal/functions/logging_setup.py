"""Einrichtung der Fehlerprotokollierung fuer die GUI."""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path


def setup_logging() -> Path:
    """Legt bei jedem Start eine neue Logdatei mit Zeitstempel an."""
    log_directory = Path("logs")
    log_directory.mkdir(exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file_path = log_directory / f"modbus_terminal_{timestamp}.log"

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[logging.FileHandler(log_file_path, encoding="utf-8")],
        force=True,
    )
    return log_file_path
