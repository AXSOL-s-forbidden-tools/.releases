"""Interaktive Eingaben fuer die Laufzeitkonfiguration."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class RuntimeConfig:
    """Sammelt alle Eingaben, die fuer eine Modbus-Abfrage noetig sind."""

    host: str
    port: int
    function_code: int
    start_address: int
    register_count: int
    expected_word_length: int
    byte_order: str
    poll_interval_seconds: float | None
    timeout_seconds: float


@dataclass(slots=True)
class ReadParameters:
    """Enthaelt nur die Werte, die waehrend der Sitzung neu gesetzt werden duerfen."""

    function_code: int
    start_address: int
    register_count: int
    expected_word_length: int
    byte_order: str
    poll_interval_seconds: float | None


def _ask_byte_order() -> str:
    """Lets the user choose how multi-register values should be interpreted."""
    while True:
        raw_value = _ask_text("Byte-Reihenfolge fuer Werte groesser als ein Register (big/little)", default="big")
        normalized_value = raw_value.strip().lower()
        if normalized_value in {"big", "little"}:
            return normalized_value
        print("Bitte nur 'big' oder 'little' eingeben.")


def _ask_text(prompt: str, default: str | None = None) -> str:
    """Fragt einen Textwert ab und setzt bei leerer Eingabe den Standardwert."""
    suffix = f" [{default}]" if default is not None else ""
    while True:
        value = input(f"{prompt}{suffix}: ").strip()
        if value:
            return value
        if default is not None:
            return default
        print("Bitte einen Wert eingeben.")


def _ask_int(prompt: str, default: int | None = None, minimum: int | None = None) -> int:
    """Fragt eine Ganzzahl ab und prueft optionale Mindestwerte."""
    while True:
        raw_value = _ask_text(prompt, str(default) if default is not None else None)
        try:
            value = int(raw_value)
        except ValueError:
            print("Bitte eine gueltige Ganzzahl eingeben.")
            continue

        if minimum is not None and value < minimum:
            print(f"Bitte einen Wert groesser oder gleich {minimum} eingeben.")
            continue
        return value


def _ask_float(prompt: str, default: float | None = None, minimum: float | None = None) -> float:
    """Fragt eine Kommazahl ab und prueft optionale Mindestwerte."""
    while True:
        raw_default = str(default) if default is not None else None
        raw_value = _ask_text(prompt, raw_default)
        try:
            value = float(raw_value.replace(",", "."))
        except ValueError:
            print("Bitte eine gueltige Zahl eingeben.")
            continue

        if minimum is not None and value < minimum:
            print(f"Bitte einen Wert groesser oder gleich {minimum} eingeben.")
            continue
        return value


def _ask_function_code() -> int:
    """Beschraenkt die Auswahl bewusst auf lesende Function Codes."""
    while True:
        function_code = _ask_int(
            "Function Code (1=Coils, 2=Discrete Inputs, 3=Holding Registers, 4=Input Registers)",
            default=3,
        )
        if function_code in {1, 2, 3, 4}:
            return function_code
        print("Aktuell werden nur die lesenden Function Codes 1, 2, 3 und 4 unterstuetzt.")


def _ask_poll_interval() -> float | None:
    """Erlaubt eine einmalige oder wiederholte Abfrage."""
    raw_value = _ask_text(
        "Wiederholungsintervall in Sekunden, leer fuer einmalige Abfrage",
        default="",
    )
    if raw_value == "":
        return None

    try:
        poll_interval = float(raw_value.replace(",", "."))
    except ValueError:
        print("Ungueltiger Wert. Es wird nur eine einmalige Abfrage ausgefuehrt.")
        return None

    if poll_interval <= 0:
        print("Intervall muss groesser als 0 sein. Es wird nur eine einmalige Abfrage ausgefuehrt.")
        return None
    return poll_interval


def ask_runtime_config() -> RuntimeConfig:
    """Sammelt die komplette Konfiguration ueber Terminal-Eingaben."""
    print("Modbus-TCP-Abfrage konfigurieren\n")
    read_parameters = ask_read_parameters()
    return RuntimeConfig(
        host=_ask_text("Zielserver / IP"),
        port=_ask_int("Zielport", default=502, minimum=1),
        function_code=read_parameters.function_code,
        start_address=read_parameters.start_address,
        register_count=read_parameters.register_count,
        expected_word_length=read_parameters.expected_word_length,
        byte_order=read_parameters.byte_order,
        poll_interval_seconds=read_parameters.poll_interval_seconds,
        timeout_seconds=_ask_float("Timeout in Sekunden", default=5.0, minimum=0.1),
    )


def ask_read_parameters() -> ReadParameters:
    """Fragt nur die eigentlichen Leseparameter ab."""
    return ReadParameters(
        function_code=_ask_function_code(),
        start_address=_ask_int("Startadresse", minimum=0),
        register_count=_ask_int("Anzahl Register", minimum=1),
        expected_word_length=_ask_int("Typlaenge in Registern", default=2, minimum=1),
        byte_order=_ask_byte_order(),
        poll_interval_seconds=_ask_poll_interval(),
    )
