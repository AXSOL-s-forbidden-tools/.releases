"""Tastaturabfrage fuer den Wiederholungsmodus."""

from __future__ import annotations

import time

try:
    import msvcrt
except ImportError:  # pragma: no cover - Windows ist hier das Hauptziel.
    msvcrt = None


def wait_for_next_action(interval_seconds: float) -> str:
    """Wartet bis zur naechsten Abfrage oder erkennt Sondertasten.

    Rueckgabewerte:
    - ``continue``: normale Wiederholung
    - ``reconfigure``: neue Leseparameter abfragen
    - ``export``: aktuelle Register als CSV exportieren
    """
    if msvcrt is None:
        time.sleep(interval_seconds)
        return "continue"

    deadline = time.monotonic() + interval_seconds
    while time.monotonic() < deadline:
        if msvcrt.kbhit():
            pressed_key = msvcrt.getch()

            # Ctrl+C soll weiterhin den normalen Abbruch der Anwendung ausloesen.
            if pressed_key == b"\x03":
                raise KeyboardInterrupt

            # Ctrl+R startet nur die Leseparameter neu, Host und Port bleiben erhalten.
            if pressed_key == b"\x12":
                return "reconfigure"

            # Ctrl+E exportiert die zuletzt gelesenen Register in eine CSV-Datei.
            if pressed_key == b"\x05":
                return "export"

        time.sleep(0.05)

    return "continue"
