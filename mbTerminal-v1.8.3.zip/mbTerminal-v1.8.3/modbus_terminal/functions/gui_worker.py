"""Hintergrundlogik fuer wiederholte GUI-Abfragen."""

from __future__ import annotations

import threading
import logging
from dataclasses import dataclass
from queue import Queue

from modbus_terminal.functions.audit_logging import log_read
from modbus_terminal.functions.display import ByteOrder, DecodedValue, decode_register_values
from modbus_terminal.functions.modbus_client import ModbusReadError, read_registers

LOGGER = logging.getLogger(__name__)


@dataclass(slots=True)
class PollRequest:
    """Enthaelt alle Werte fuer eine einzelne oder wiederholte Leseabfrage."""

    host: str
    port: int
    function_code: int
    start_address: int
    register_count: int
    expected_word_length: int
    byte_order: ByteOrder
    timeout_seconds: float
    poll_interval_seconds: float | None


@dataclass(slots=True)
class PollResult:
    """Transportiert Erfolg oder Fehler aus dem Hintergrundthread zur GUI."""

    success: bool
    message: str
    decoded_values: list[DecodedValue]
    start_address: int
    registers: list[int]
    byte_order: ByteOrder


class PollingController:
    """Steuert den Lebenszyklus der wiederholten Leseabfrage fuer die GUI."""

    def __init__(self) -> None:
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self, request: PollRequest, result_queue: Queue[PollResult]) -> None:
        """Startet eine neue Abfrage und beendet eine eventuell laufende alte vorher."""
        self.stop()
        self._stop_event = threading.Event()
        self._thread = threading.Thread(
            target=self._run_polling,
            args=(request, result_queue, self._stop_event),
            daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        """Signalisiert einer laufenden Abfrage, dass sie beendet werden soll."""
        self._stop_event.set()
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=0.2)
        self._thread = None

    def is_running(self) -> bool:
        """Meldet, ob aktuell eine Hintergrundabfrage laeuft."""
        return self._thread is not None and self._thread.is_alive()

    def _run_polling(
        self,
        request: PollRequest,
        result_queue: Queue[PollResult],
        stop_event: threading.Event,
    ) -> None:
        """Fuehrt die Leseabfrage im Hintergrund aus und meldet Ergebnisse an die GUI."""
        while not stop_event.is_set():
            try:
                registers = read_registers(
                    host=request.host,
                    port=request.port,
                    function_code=request.function_code,
                    start_address=request.start_address,
                    register_count=request.register_count,
                    timeout_seconds=request.timeout_seconds,
                )
            except ModbusReadError as error:
                LOGGER.exception("Modbus-Abfrage fehlgeschlagen.")
                result_queue.put(PollResult(False, f"Modbus-Fehler: {error}", [], request.start_address, [], request.byte_order))
                return
            except Exception as error:  # pragma: no cover - Sicherheitsnetz fuer unerwartete Fehler.
                LOGGER.exception("Unerwarteter Fehler in der Hintergrundabfrage.")
                result_queue.put(
                    PollResult(False, f"Unerwarteter Fehler: {error}", [], request.start_address, [], request.byte_order)
                )
                return

            decoded_values = decode_register_values(
                registers,
                request.expected_word_length,
                request.start_address,
                request.byte_order,
            )
            log_read(
                host=request.host,
                port=request.port,
                function_code=request.function_code,
                start_address=request.start_address,
                register_count=request.register_count,
                registers=registers,
            )
            result_queue.put(
                PollResult(True, "Abfrage erfolgreich.", decoded_values, request.start_address, registers, request.byte_order)
            )

            if request.poll_interval_seconds is None:
                return

            if stop_event.wait(request.poll_interval_seconds):
                return
