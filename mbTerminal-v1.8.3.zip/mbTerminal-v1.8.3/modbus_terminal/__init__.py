"""Modbus-Terminal Paket."""

from modbus_terminal.version import __version__

__all__ = ["__version__"]
