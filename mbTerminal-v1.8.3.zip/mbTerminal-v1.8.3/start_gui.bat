@echo off
setlocal

set "PROJECT_ROOT=%~dp0"
cd /d "%PROJECT_ROOT%"

if not exist "logs" mkdir "logs"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$logPath = Join-Path '%PROJECT_ROOT%' 'logs';" ^
  "if (Test-Path $logPath) {" ^
  "  $currentSize = (Get-ChildItem -LiteralPath $logPath -File -Recurse -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum;" ^
  "  if ($currentSize -gt 100MB) {" ^
  "    $files = Get-ChildItem -LiteralPath $logPath -File -Recurse | Sort-Object LastWriteTime;" ^
  "    foreach ($file in $files) {" ^
  "      Remove-Item -LiteralPath $file.FullName -Force -ErrorAction SilentlyContinue;" ^
  "      $currentSize = (Get-ChildItem -LiteralPath $logPath -File -Recurse -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum;" ^
  "      if ($currentSize -lt 50MB) { break }" ^
  "    }" ^
  "  }" ^
  "}"

where py >nul 2>&1
if %errorlevel%==0 (
    set "PYTHON_CMD=py -3"
) else (
    where python >nul 2>&1
    if %errorlevel%==0 (
        set "PYTHON_CMD=python"
    ) else (
        echo Python wurde nicht gefunden.
        choice /M "Soll Python jetzt ueber winget installiert werden"
        if errorlevel 2 goto :cancelled
        winget install Python.Python.3.13
        if errorlevel 1 goto :install_failed
        where py >nul 2>&1
        if %errorlevel%==0 (
            set "PYTHON_CMD=py -3"
        ) else (
            set "PYTHON_CMD=python"
        )
    )
)

if not exist ".env\Scripts\python.exe" (
    echo Erstelle virtuelle Umgebung .env ...
    call %PYTHON_CMD% -m venv .env
    if errorlevel 1 goto :venv_failed
)

echo Pruefe pip in .env ...
call ".env\Scripts\python.exe" -m ensurepip --upgrade
if errorlevel 1 goto :pip_missing

echo Pruefe optionales pip-Update in .env ...
call ".env\Scripts\python.exe" -m pip install --upgrade pip >nul 2>&1
if errorlevel 1 (
    echo Hinweis: pip konnte nicht aktualisiert werden. Die Anwendung wird trotzdem gestartet.
)

if exist "requirements.txt" (
    echo Installiere benoetigte Python-Bibliotheken in .env ...
    call ".env\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 goto :requirements_failed
)

echo Starte Modbus-GUI ...
start "" ".env\Scripts\pythonw.exe" main.py
goto :success

:cancelled
echo Installation wurde durch den Benutzer abgebrochen.
goto :end

:install_failed
echo Python konnte nicht installiert werden.
goto :end

:venv_failed
echo Die virtuelle Umgebung konnte nicht erstellt werden.
goto :end

:pip_missing
echo pip konnte in der virtuellen Umgebung nicht bereitgestellt werden.
goto :end

:requirements_failed
echo Die benoetigten Python-Bibliotheken konnten nicht installiert werden.
goto :end

:success
endlocal
exit /b 0

:end
pause
endlocal
