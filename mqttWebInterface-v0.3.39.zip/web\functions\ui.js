import {
  buildHistoryAxisLabels,
  buildHistoryPolyline,
  clampHistoryLimit,
  formatHistoryRange
} from "./history.js";

export function setConnectionBadge(element, state, text) {
  setStatusBadge(element, state, text);
}

export function setStatusBadge(element, state, text) {
  element.textContent = text;
  element.classList.remove("connected", "error", "running");

  if (state === "connected") {
    element.classList.add("connected");
  }

  if (state === "running") {
    element.classList.add("running");
  }

  if (state === "error") {
    element.classList.add("error");
  }
}

export function appendLogEntry(container, message, autoScroll = true) {
  // New entries are inserted at the top so the latest action stays visible immediately.
  const entry = document.createElement("p");
  entry.className = "log-entry";
  entry.textContent = `[${formatTimestamp(Date.now())}] ${message}`;
  container.prepend(entry);

  if (autoScroll) {
    container.scrollTop = 0;
  }
}

export function toggleEmptyState(element, shouldShow) {
  element.hidden = !shouldShow;
}

export function setCollapseToggleState(button, collapsed, labels) {
  button.dataset.collapsed = collapsed ? "true" : "false";
  button.setAttribute("aria-label", collapsed ? labels.expand : labels.collapse);
  button.title = collapsed ? labels.expand : labels.collapse;
}

export function buildStatusCard(template, item, handlers) {
  const fragment = template.content.cloneNode(true);
  const card = fragment.querySelector(".config-card");
  const labelInput = card.querySelector('[data-field="label"]');
  const groupInput = card.querySelector('[data-field="group"]');
  const topicInput = card.querySelector('[data-field="topic"]');
  const keyInput = card.querySelector('[data-field="key"]');
  const showHistoryInput = card.querySelector('[data-field="showHistory"]');
  const logEnabledInput = card.querySelector('[data-field="logEnabled"]');
  const historyLimitInput = card.querySelector('[data-field="historyLimit"]');
  const historyRefreshWhileCollapsedInput = card.querySelector(
    '[data-field="historyRefreshWhileCollapsed"]'
  );
  const historyRefreshWhileCollapsedThrottledInput = card.querySelector(
    '[data-field="historyRefreshWhileCollapsedThrottled"]'
  );
  const historyManualScaleInput = card.querySelector('[data-field="historyManualScale"]');
  const historyMinInput = card.querySelector('[data-field="historyMin"]');
  const historyMaxInput = card.querySelector('[data-field="historyMax"]');
  const titleElement = card.querySelector('[data-role="title"]');
  const toggleButton = card.querySelector('[data-action="toggle-config"]');
  const dragHandle = card.querySelector('[data-action="drag-handle"]');
  const primaryTabButton = card.querySelector('[data-action="tab-primary"]');
  const settingsTabButton = card.querySelector('[data-action="tab-settings"]');
  card.dataset.itemId = item.id;
  card.dataset.group = item.group || "";
  card.dataset.collapsed = item.collapsed === true ? "true" : "false";

  labelInput.value = item.label;
  groupInput.value = item.group || "";
  topicInput.value = item.topic;
  keyInput.value = item.key;
  showHistoryInput.checked = item.showHistory === true;
  logEnabledInput.checked = item.logEnabled === true;
  historyLimitInput.value = String(clampHistoryLimit(item.historyLimit));
  historyRefreshWhileCollapsedInput.checked = item.historyRefreshWhileCollapsed === true;
  historyRefreshWhileCollapsedThrottledInput.checked =
    item.historyRefreshWhileCollapsedThrottled === true;
  historyManualScaleInput.checked = item.historyManualScale === true;
  historyMinInput.value = item.historyMin ?? "";
  historyMaxInput.value = item.historyMax ?? "";
  showHistoryInput.dataset.field = "showHistory";
  logEnabledInput.dataset.field = "logEnabled";
  historyLimitInput.dataset.field = "historyLimit";
  historyRefreshWhileCollapsedInput.dataset.field = "historyRefreshWhileCollapsed";
  historyRefreshWhileCollapsedThrottledInput.dataset.field =
    "historyRefreshWhileCollapsedThrottled";
  historyManualScaleInput.dataset.field = "historyManualScale";
  historyMinInput.dataset.field = "historyMin";
  historyMaxInput.dataset.field = "historyMax";
  titleElement.textContent = item.label?.trim() || item.key?.trim() || "Neuer Statuswert";
  card.classList.toggle("config-collapsed", item.collapsed === true);
  updateStatusCardDisplay(card, item);
  applyCardTabState(card, item);
  setCollapseToggleState(toggleButton, item.collapsed === true, {
    expand: "Statuswert-Konfiguration einblenden",
    collapse: "Statuswert-Konfiguration ausblenden"
  });

  bindInput(labelInput, "label", {
    ...handlers,
    onChange(field, value) {
      handlers.onChange(field, value);
      titleElement.textContent = value.trim() || keyInput.value.trim() || "Neuer Statuswert";
    }
  });
  bindInput(groupInput, "group", handlers);
  bindInput(topicInput, "topic", handlers);
  bindInput(keyInput, "key", handlers);
  showHistoryInput.addEventListener("change", (event) => {
    handlers.onChange("showHistory", event.target.checked);
  });
  logEnabledInput.addEventListener("change", (event) => {
    handlers.onChange("logEnabled", event.target.checked);
  });
  historyLimitInput.addEventListener("keydown", (event) => {
    if (event.key !== "Enter") {
      return;
    }

    event.preventDefault();
    handlers.onChange("historyLimit", event.target.value);
  });
  historyLimitInput.addEventListener("blur", () => {
    historyLimitInput.value = String(clampHistoryLimit(item.historyLimit));
  });
  historyRefreshWhileCollapsedInput.addEventListener("change", (event) => {
    handlers.onChange("historyRefreshWhileCollapsed", event.target.checked);
  });
  historyRefreshWhileCollapsedThrottledInput.addEventListener("change", (event) => {
    handlers.onChange("historyRefreshWhileCollapsedThrottled", event.target.checked);
  });
  historyManualScaleInput.addEventListener("change", (event) => {
    handlers.onChange("historyManualScale", event.target.checked);
  });
  historyMinInput.addEventListener("keydown", (event) => {
    if (event.key !== "Enter") {
      return;
    }

    event.preventDefault();
    handlers.onChange("historyMin", event.target.value);
  });
  historyMinInput.addEventListener("blur", () => {
    historyMinInput.value = item.historyMin ?? "";
  });
  historyMaxInput.addEventListener("keydown", (event) => {
    if (event.key !== "Enter") {
      return;
    }

    event.preventDefault();
    handlers.onChange("historyMax", event.target.value);
  });
  historyMaxInput.addEventListener("blur", () => {
    historyMaxInput.value = item.historyMax ?? "";
  });
  keyInput.addEventListener("input", (event) => {
    if (!labelInput.value.trim()) {
      titleElement.textContent = event.target.value.trim() || "Neuer Statuswert";
    }
  });
  primaryTabButton.addEventListener("click", () => {
    handlers.onChange("activeTab", "primary");
  });
  settingsTabButton.addEventListener("click", () => {
    handlers.onChange("activeTab", "settings");
  });
  if (dragHandle instanceof HTMLButtonElement) {
    dragHandle.draggable = true;
  }
  toggleButton.addEventListener("click", handlers.onToggleCollapse);
  card.querySelector('[data-action="remove"]').addEventListener("click", handlers.onRemove);

  return card;
}

export function buildCommandCard(template, item, handlers) {
  const fragment = template.content.cloneNode(true);
  const card = fragment.querySelector(".config-card");
  const labelInput = card.querySelector('[data-field="label"]');
  const groupInput = card.querySelector('[data-field="group"]');
  const topicInput = card.querySelector('[data-field="topic"]');
  const keyInput = card.querySelector('[data-field="key"]');
  const valueInput = card.querySelector('[data-field="value"]');
  const logEnabledInput = card.querySelector('[data-field="logEnabled"]');
  const sendButton = card.querySelector('[data-action="send"]');
  const titleElement = card.querySelector('[data-role="title"]');
  const toggleButton = card.querySelector('[data-action="toggle-config"]');
  const dragHandle = card.querySelector('[data-action="drag-handle"]');
  const primaryTabButton = card.querySelector('[data-action="tab-primary"]');
  const settingsTabButton = card.querySelector('[data-action="tab-settings"]');
  card.dataset.itemId = item.id;
  card.dataset.group = item.group || "";
  card.dataset.collapsed = item.collapsed === true ? "true" : "false";

  labelInput.value = item.label;
  groupInput.value = item.group || "";
  topicInput.value = item.topic;
  keyInput.value = item.key;
  valueInput.value = item.value;
  logEnabledInput.checked = item.logEnabled === true;
  sendButton.textContent = item.label?.trim() || "Senden";
  titleElement.textContent = item.label?.trim() || item.key?.trim() || "Neuer Befehl";
  card.classList.toggle("config-collapsed", item.collapsed === true);
  applyCardTabState(card, item);
  setCollapseToggleState(toggleButton, item.collapsed === true, {
    expand: "Befehls-Konfiguration einblenden",
    collapse: "Befehls-Konfiguration ausblenden"
  });

  bindInput(labelInput, "label", {
    ...handlers,
    onChange(field, value) {
      handlers.onChange(field, value);
      sendButton.textContent = value.trim() || "Senden";
      titleElement.textContent = value.trim() || item.key?.trim() || "Neuer Befehl";
    }
  });
  bindInput(groupInput, "group", handlers);
  bindInput(topicInput, "topic", handlers);
  bindInput(keyInput, "key", handlers);
  bindInput(valueInput, "value", handlers);
  logEnabledInput.addEventListener("change", (event) => {
    handlers.onChange("logEnabled", event.target.checked);
  });
  keyInput.addEventListener("input", (event) => {
    if (!labelInput.value.trim()) {
      titleElement.textContent = event.target.value.trim() || "Neuer Befehl";
    }
  });
  primaryTabButton.addEventListener("click", () => {
    handlers.onChange("activeTab", "primary");
  });
  settingsTabButton.addEventListener("click", () => {
    handlers.onChange("activeTab", "settings");
  });
  if (dragHandle instanceof HTMLButtonElement) {
    dragHandle.draggable = true;
  }
  toggleButton.addEventListener("click", handlers.onToggleCollapse);
  sendButton.addEventListener("click", handlers.onSend);
  card.querySelector('[data-action="remove"]').addEventListener("click", handlers.onRemove);

  return card;
}

export function formatTimestamp(timestamp) {
  return new Date(timestamp).toLocaleString("de-DE");
}

export function updateStatusCardDisplay(card, item) {
  const valueElement = card.querySelector('[data-role="value"]');
  const timestampElement = card.querySelector('[data-role="timestamp"]');
  const historyBox = card.querySelector('[data-role="history-box"]');
  const historyLine = card.querySelector('[data-role="history-line"]');
  const historySummary = card.querySelector('[data-role="history-summary"]');
  const historyAxisMax = card.querySelector('[data-role="history-axis-max"]');
  const historyAxisMid = card.querySelector('[data-role="history-axis-mid"]');
  const historyAxisMin = card.querySelector('[data-role="history-axis-min"]');
  const historyLimitField = card.querySelector('[data-role="history-limit-field"]');
  const historyCollapsedLiveField = card.querySelector('[data-role="history-collapsed-live-field"]');
  const historyCollapsedThrottleField = card.querySelector(
    '[data-role="history-collapsed-throttle-field"]'
  );
  const historyManualScaleField = card.querySelector('[data-role="history-manual-scale-field"]');
  const historyMinField = card.querySelector('[data-role="history-min-field"]');
  const historyMaxField = card.querySelector('[data-role="history-max-field"]');

  valueElement.textContent = formatStatusValue(item.lastValue, item.unit);
  timestampElement.textContent = item.lastUpdated
    ? `Zuletzt aktualisiert: ${formatTimestamp(item.lastUpdated)}`
    : "Noch kein Wert empfangen";

  historyLimitField.hidden = item.showHistory !== true;
  historyCollapsedLiveField.hidden = item.showHistory !== true;
  historyCollapsedThrottleField.hidden = item.showHistory !== true;
  historyManualScaleField.hidden = item.showHistory !== true;
  historyMinField.hidden = item.showHistory !== true || item.historyManualScale !== true;
  historyMaxField.hidden = item.showHistory !== true || item.historyManualScale !== true;
  historyBox.hidden = item.showHistory !== true;

  // Hidden live panels still receive value updates so switching tabs stays instant.
  if (shouldRenderHistoryPreview(card, item)) {
    updateHistoryPreview(
      historyLine,
      historySummary,
      historyAxisMax,
      historyAxisMid,
      historyAxisMin,
      item.historyValues || [],
      item
    );
    return;
  }

  if (item.showHistory === true) {
    historySummary.textContent = formatHistoryRange(item.historyValues || [], item);
  }
}

function shouldRenderHistoryPreview(card, item) {
  if (item.showHistory !== true) {
    return false;
  }

  if (card.dataset.collapsed !== "true") {
    if (item.activeTab !== "primary") {
      return false;
    }

    return true;
  }

  return (
    item.historyRefreshWhileCollapsed === true
    || item.historyRefreshWhileCollapsedThrottled === true
  );
}

function bindInput(input, field, handlers) {
  input.dataset.field = field;
  input.addEventListener("input", (event) => {
    handlers.onChange(field, event.target.value);
  });
}

function applyCardTabState(card, item) {
  const tabs = card.querySelector('[data-role="card-tabs"]');
  const primaryPanel = card.querySelector('[data-role="primary-panel"]');
  const settingsPanel = card.querySelector('[data-role="config-fields"]');
  const primaryTabButton = card.querySelector('[data-action="tab-primary"]');
  const settingsTabButton = card.querySelector('[data-action="tab-settings"]');
  const isCollapsed = item.collapsed === true;
  const activeTab = item.activeTab === "settings" ? "settings" : "primary";

  card.dataset.activeTab = activeTab;
  tabs.hidden = isCollapsed;
  primaryPanel.hidden = isCollapsed ? false : activeTab !== "primary";
  settingsPanel.hidden = isCollapsed ? true : activeTab !== "settings";
  primaryTabButton.dataset.active = activeTab === "primary" ? "true" : "false";
  settingsTabButton.dataset.active = activeTab === "settings" ? "true" : "false";
  primaryTabButton.setAttribute("aria-pressed", activeTab === "primary" ? "true" : "false");
  settingsTabButton.setAttribute("aria-pressed", activeTab === "settings" ? "true" : "false");
}

function updateHistoryPreview(
  lineElement,
  summaryElement,
  axisMaxElement,
  axisMidElement,
  axisMinElement,
  historyValues,
  item
) {
  const polylinePoints = buildHistoryPolyline(historyValues, 220, 90, 8, item);
  const axisLabels = buildHistoryAxisLabels(historyValues, item);
  lineElement.setAttribute("points", polylinePoints);
  summaryElement.textContent = formatHistoryRange(historyValues, item);
  axisMaxElement.textContent = axisLabels.maxLabel;
  axisMidElement.textContent = axisLabels.midLabel;
  axisMinElement.textContent = axisLabels.minLabel;
}

function formatStatusValue(value, unit) {
  if (value === null) {
    return "-";
  }

  const normalizedUnit = String(unit || "").trim();
  return normalizedUnit ? `${String(value)} ${normalizedUnit}` : String(value);
}
