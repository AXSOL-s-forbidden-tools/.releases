import argparse
import ctypes
import json
import mimetypes
import signal
import threading
import time
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

try:
    from tkinter import Tk, filedialog
except ImportError:  # pragma: no cover - depends on local Python installation
    Tk = None
    filedialog = None

from functions.mqtt_backend import MqttBackend, MqttConnectionConfig
from functions.system_monitor import collect_system_metrics


REPO_ROOT = Path(__file__).resolve().parent.parent
WEB_ROOT = (REPO_ROOT / "web").resolve()
MQTT_BACKENDS = {}
ACTIVE_SERVER = None
SERVER_STOP_REQUESTED = threading.Event()
WINDOWS_CTRL_CLOSE_EVENT = 2
WINDOWS_CTRL_LOGOFF_EVENT = 5
WINDOWS_CTRL_SHUTDOWN_EVENT = 6
SERVER_START_TIMESTAMP = 0.0


class WebInterfaceHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed_url = urlparse(self.path)

        if parsed_url.path == "/api/events":
            self._handle_get_events(parsed_url.query)
            return

        if parsed_url.path == "/api/system":
            self._handle_get_system_status()
            return

        if parsed_url.path == "/api/logging/status":
            self._handle_get_logging_status(parsed_url.query)
            return

        self._handle_static_file(parsed_url.path)

    def do_OPTIONS(self):
        self.send_response(HTTPStatus.NO_CONTENT)
        self.end_headers()

    def do_POST(self):
        parsed_url = urlparse(self.path)

        try:
            body = self._read_json_body()
        except ValueError as error:
            self._send_json({"error": str(error)}, status=HTTPStatus.BAD_REQUEST)
            return

        if parsed_url.path == "/api/connect":
            self._handle_connect(body)
            return

        if parsed_url.path == "/api/disconnect":
            backend = self._get_backend(body)
            backend.disconnect()
            self._send_json({"ok": True})
            return

        if parsed_url.path == "/api/publish":
            self._handle_publish(body)
            return

        if parsed_url.path == "/api/subscriptions":
            topics = body.get("topics", [])
            backend = self._get_backend(body)
            backend.sync_subscriptions(topics)
            self._send_json({"ok": True})
            return

        if parsed_url.path == "/api/logging/start":
            self._handle_start_logging(body)
            return

        if parsed_url.path == "/api/logging/stop":
            self._handle_stop_logging(body)
            return

        if parsed_url.path == "/api/dialog/select-directory":
            self._handle_select_directory(body)
            return

        self._send_json({"error": "Unbekannter API-Endpunkt."}, status=HTTPStatus.NOT_FOUND)

    def log_message(self, format, *args):
        return

    def _handle_connect(self, body):
        host = str(body.get("host", "")).strip()
        port = int(body.get("port", 0))

        if not host or not port:
            self._send_json({"error": "Host und Port sind erforderlich."}, status=HTTPStatus.BAD_REQUEST)
            return

        config = MqttConnectionConfig(
            host=host,
            port=port,
            username=str(body.get("username", "")).strip(),
            password=str(body.get("password", "")),
        )
        backend = self._get_backend(body)

        try:
            result = backend.connect(config)
        except OSError as error:
            self._send_json({"error": f"Broker nicht erreichbar: {error}"}, status=HTTPStatus.BAD_GATEWAY)
            return

        self._send_json(result)

    def _handle_publish(self, body):
        topic = str(body.get("topic", "")).strip()
        payload = str(body.get("payload", ""))

        if not topic:
            self._send_json({"error": "Topic ist erforderlich."}, status=HTTPStatus.BAD_REQUEST)
            return

        try:
            backend = self._get_backend(body)
            backend.publish(topic, payload)
        except RuntimeError as error:
            self._send_json({"error": str(error)}, status=HTTPStatus.CONFLICT)
            return

        self._send_json({"ok": True})

    def _handle_get_events(self, query):
        query_params = parse_qs(query)
        after_event_id = int(query_params.get("after", ["0"])[0])
        instance_id = str(query_params.get("instanceId", ["default"])[0]).strip() or "default"
        self._send_json(self._get_backend_by_id(instance_id).get_events(after_event_id))

    def _handle_get_system_status(self):
        active_instances = sum(
            1 for backend in MQTT_BACKENDS.values() if backend.is_alive()
        )
        self._send_json(
            collect_system_metrics(
                active_instances=active_instances,
                start_time=SERVER_START_TIMESTAMP,
            )
        )

    def _handle_get_logging_status(self, query):
        query_params = parse_qs(query)
        instance_id = str(query_params.get("instanceId", ["default"])[0]).strip() or "default"
        self._send_json(self._get_backend_by_id(instance_id).get_logging_status())

    def _handle_start_logging(self, body):
        output_dir = str(body.get("outputDir", "")).strip()
        status_items = body.get("statusItems", [])
        backend = self._get_backend(body)

        try:
            result = backend.start_logging(output_dir, status_items)
        except (RuntimeError, ValueError) as error:
            self._send_json({"error": str(error)}, status=HTTPStatus.BAD_REQUEST)
            return
        except OSError as error:
            self._send_json({"error": f"CSV-Dateien konnten nicht vorbereitet werden: {error}"}, status=HTTPStatus.BAD_GATEWAY)
            return

        self._send_json(result)

    def _handle_stop_logging(self, body):
        backend = self._get_backend(body)
        self._send_json(backend.stop_logging())

    def _handle_select_directory(self, body):
        initial_dir = str(body.get("initialDir", "")).strip()

        try:
            selected_directory = open_directory_dialog(initial_dir)
        except RuntimeError as error:
            self._send_json({"error": str(error)}, status=HTTPStatus.BAD_GATEWAY)
            return

        self._send_json({"path": selected_directory})

    def _handle_static_file(self, request_path):
        normalized_path = request_path or "/"
        relative_path = normalized_path.lstrip("/") or "index.html"
        requested_file = (WEB_ROOT / relative_path).resolve()

        # Diese Pruefung verhindert, dass ueber manipulierte Pfade Dateien ausserhalb des Web-Ordners gelesen werden.
        try:
            requested_file.relative_to(WEB_ROOT)
        except ValueError:
            self._send_plain_text("Datei nicht gefunden.", HTTPStatus.NOT_FOUND)
            return

        if requested_file.is_dir():
            requested_file = requested_file / "index.html"

        if not requested_file.exists() or not requested_file.is_file():
            self._send_plain_text("Datei nicht gefunden.", HTTPStatus.NOT_FOUND)
            return

        content = requested_file.read_bytes()
        content_type, _ = mimetypes.guess_type(str(requested_file))
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", f"{content_type or 'application/octet-stream'}")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def _read_json_body(self):
        content_length = int(self.headers.get("Content-Length", "0"))

        if content_length == 0:
            return {}

        raw_body = self.rfile.read(content_length)

        try:
            return json.loads(raw_body.decode("utf-8"))
        except json.JSONDecodeError as error:
            raise ValueError(f"JSON ungueltig: {error.msg}") from error

    def _get_backend(self, body):
        instance_id = str(body.get("instanceId", "default")).strip() or "default"
        return self._get_backend_by_id(instance_id)

    def _get_backend_by_id(self, instance_id):
        if instance_id not in MQTT_BACKENDS:
            MQTT_BACKENDS[instance_id] = MqttBackend()

        return MQTT_BACKENDS[instance_id]

    def _send_json(self, payload, status=HTTPStatus.OK):
        encoded = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def _send_plain_text(self, message, status):
        encoded = message.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def end_headers(self):
        if self.path.startswith("/api/"):
            self._send_cors_headers()
        super().end_headers()

    def _send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")


def main():
    global ACTIVE_SERVER, SERVER_START_TIMESTAMP
    args = parse_arguments()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), WebInterfaceHandler)
    ACTIVE_SERVER = server
    SERVER_START_TIMESTAMP = time.time()
    register_shutdown_handlers()
    print(f"Webinterface laeuft unter http://127.0.0.1:{args.port}")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        # Strg+C ist hier ein normales Beenden durch den Nutzer
        # und soll deshalb keinen technischen Fehler ausgeben.
        print("\nWebinterface wird sauber beendet.")
    finally:
        shutdown_backends()
        server.server_close()
        ACTIVE_SERVER = None
        SERVER_STOP_REQUESTED.clear()


def parse_arguments():
    parser = argparse.ArgumentParser(
        description="Startet den lokalen Webserver fuer das MQTT-Webinterface."
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8080,
        help="Port fuer die lokale Weboberflaeche."
    )
    args = parser.parse_args()

    if args.port < 1 or args.port > 65535:
        parser.error("Der Port muss zwischen 1 und 65535 liegen.")

    return args


def shutdown_backends():
    for backend in MQTT_BACKENDS.values():
        backend.disconnect()


def register_shutdown_handlers():
    signal.signal(signal.SIGINT, handle_shutdown_signal)

    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, handle_shutdown_signal)

    if hasattr(signal, "SIGBREAK"):
        signal.signal(signal.SIGBREAK, handle_shutdown_signal)

    register_windows_console_close_handler()


def handle_shutdown_signal(signum, frame):
    request_server_shutdown(f"Signal fuer Beenden empfangen: {signum}")


def request_server_shutdown(reason):
    if SERVER_STOP_REQUESTED.is_set():
        return

    SERVER_STOP_REQUESTED.set()
    print(f"\n{reason}")

    # Das Herunterfahren des HTTP-Servers laeuft in einem separaten Thread,
    # damit Signal- und Konsolen-Handler schnell zurueckkehren koennen.
    shutdown_thread = threading.Thread(target=shutdown_server, daemon=True)
    shutdown_thread.start()


def shutdown_server():
    shutdown_backends()

    if ACTIVE_SERVER is not None:
        ACTIVE_SERVER.shutdown()


def register_windows_console_close_handler():
    if ctypes is None or not hasattr(ctypes, "windll"):
        return

    handler_type = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_uint)

    def console_close_handler(ctrl_type):
        if ctrl_type in {
            WINDOWS_CTRL_CLOSE_EVENT,
            WINDOWS_CTRL_LOGOFF_EVENT,
            WINDOWS_CTRL_SHUTDOWN_EVENT,
        }:
            request_server_shutdown("Terminalfenster wird geschlossen. Webinterface wird beendet.")
            return True

        return False

    console_handler = handler_type(console_close_handler)
    ctypes.windll.kernel32.SetConsoleCtrlHandler(console_handler, True)

    # Der Handler wird als Attribut gehalten, damit er nicht durch den
    # Python-Garbage-Collector waehrend der Laufzeit freigegeben wird.
    register_windows_console_close_handler.console_handler = console_handler


def open_directory_dialog(initial_dir: str) -> str:
    if Tk is None or filedialog is None:
        raise RuntimeError("Tkinter is not available in this Python installation.")

    selected_path = {"value": ""}
    dialog_error = {"value": ""}
    dialog_completed = threading.Event()

    def run_dialog():
        root = None

        try:
            root = Tk()
            root.withdraw()
            root.attributes("-topmost", True)
            selected_path["value"] = filedialog.askdirectory(
                initialdir=initial_dir or str(Path.home()),
                mustexist=False,
                parent=root,
                title="Select logging output directory",
            )
        except Exception as error:
            dialog_error["value"] = str(error)
        finally:
            if root is not None:
                root.destroy()
            dialog_completed.set()

    dialog_thread = threading.Thread(target=run_dialog)
    dialog_thread.start()
    dialog_completed.wait()

    if dialog_error["value"]:
        raise RuntimeError(f"Directory dialog could not be opened: {dialog_error['value']}")

    return selected_path["value"]


if __name__ == "__main__":
    main()
