import {
  appendHistoryValue,
  clampHistoryLimit,
  normalizeAxisValue,
  resolveHistoryAxisBounds
} from "./functions/history.js";
import { createMqttClient } from "./functions/mqtt-client.js";
import {
  fetchLoggingStatus,
  selectLoggingDirectory,
  startLogging,
  stopLogging
} from "./functions/logging.js";
import {
  createDefaultSectionVisibility,
  createDefaultAppSettings,
  createDefaultCommand,
  createDefaultStatusItem,
  deleteNamedConfiguration,
  exportState,
  importState,
  loadNamedConfiguration,
  listSavedConfigurationNames,
  loadState,
  saveNamedConfiguration,
  saveState
} from "./functions/storage.js";
import {
  buildDiscoveryTopics,
  buildStatusTopic,
  buildTemplateCatalog,
  createEmptyTemplateCatalog,
  createStatusItemFromTemplate,
  findDiscoveryMatches,
  getCatalogComponent,
  getTemplatesForScope,
  normalizeTemplateCatalog
} from "./functions/template-catalog.js";
import {
  appendLogEntry,
  buildCommandCard,
  buildStatusCard,
  formatTimestamp,
  setCollapseToggleState,
  setConnectionBadge,
  setStatusBadge,
  toggleEmptyState,
  updateStatusCardDisplay
} from "./functions/ui.js";

// Der zentrale Zustand haelt Verbindungsdaten sowie die frei angelegten
// Status- und Befehlsdefinitionen zusammen.
const state = loadState();

const SECTION_VISIBILITY_CONFIG = [
  {
    key: "templateImport",
    elementKey: "templatePanel",
    checkboxKey: "toggleTemplatePanelCheckbox"
  },
  {
    key: "broker",
    elementKey: "brokerPanel",
    checkboxKey: "toggleBrokerSectionCheckbox"
  },
  {
    key: "logging",
    elementKey: "loggingPanel",
    checkboxKey: "toggleLoggingSectionCheckbox"
  },
  {
    key: "status",
    elementKey: "statusPanel",
    checkboxKey: "toggleStatusSectionCheckbox"
  },
  {
    key: "commands",
    elementKey: "commandsPanel",
    checkboxKey: "toggleCommandsSectionCheckbox"
  },
  {
    key: "events",
    elementKey: "eventsPanel",
    checkboxKey: "toggleEventsSectionCheckbox"
  },
  {
    key: "hardwareMonitor",
    elementKey: "monitorPanel",
    checkboxKey: "toggleMonitorSectionCheckbox"
  }
];

const elements = {
  brokerPanel: document.querySelector("#broker-panel"),
  connectionForm: document.querySelector("#connection-form"),
  connectButton: document.querySelector("#connect-button"),
  disconnectButton: document.querySelector("#disconnect-button"),
  toggleBrokerConfigButton: document.querySelector("#toggle-broker-config-button"),
  activeConfigName: document.querySelector("#active-config-name"),
  statusBadge: document.querySelector("#connection-status"),
  loggingStatusBadge: document.querySelector("#logging-status"),
  themeMenuButton: document.querySelector("#theme-menu-button"),
  themeMenu: document.querySelector("#theme-menu"),
  themeLightButton: document.querySelector("#theme-light-button"),
  themeDarkButton: document.querySelector("#theme-dark-button"),
  toggleTemplatePanelCheckbox: document.querySelector("#toggle-template-panel-checkbox"),
  templatePanel: document.querySelector("#template-panel"),
  toggleBrokerSectionCheckbox: document.querySelector("#toggle-broker-section-checkbox"),
  toggleLoggingSectionCheckbox: document.querySelector("#toggle-logging-section-checkbox"),
  toggleStatusSectionCheckbox: document.querySelector("#toggle-status-section-checkbox"),
  toggleCommandsSectionCheckbox: document.querySelector("#toggle-commands-section-checkbox"),
  toggleEventsSectionCheckbox: document.querySelector("#toggle-events-section-checkbox"),
  toggleMonitorSectionCheckbox: document.querySelector("#toggle-monitor-section-checkbox"),
  loggingPanel: document.querySelector("#logging-panel"),
  toggleLoggingButton: document.querySelector("#toggle-logging-button"),
  loggingOutputDirInput: document.querySelector("#logging-output-dir"),
  selectLoggingOutputDirButton: document.querySelector("#select-logging-output-dir-button"),
  startLoggingButton: document.querySelector("#start-logging-button"),
  stopLoggingButton: document.querySelector("#stop-logging-button"),
  loggingSummary: document.querySelector("#logging-summary"),
  statusList: document.querySelector("#status-list"),
  statusEmptyState: document.querySelector("#status-empty-state"),
  importStatusTemplatesButton: document.querySelector("#import-status-templates-button"),
  clearStatusTemplatesButton: document.querySelector("#clear-status-templates-button"),
  importStatusTemplatesInput: document.querySelector("#import-status-templates-input"),
  statusTemplatePanel: document.querySelector("#status-template-panel"),
  statusTemplateSummary: document.querySelector("#status-template-summary"),
  templateComponentSelect: document.querySelector("#template-component-select"),
  templateScopeSelect: document.querySelector("#template-scope-select"),
  templateInstanceSelect: document.querySelector("#template-instance-select"),
  templateValueSelect: document.querySelector("#template-value-select"),
  templateGroupInput: document.querySelector("#template-group-input"),
  statusTemplatePreview: document.querySelector("#status-template-preview"),
  addStatusTemplateButton: document.querySelector("#add-status-template-button"),
  templateTools: document.querySelector('[data-role="template-tools"]'),
  statusPanel: document.querySelector("#status-panel"),
  commandList: document.querySelector("#command-list"),
  commandEmptyState: document.querySelector("#command-empty-state"),
  commandsPanel: document.querySelector("#commands-panel"),
  addStatusButton: document.querySelector("#add-status-button"),
  addCommandButton: document.querySelector("#add-command-button"),
  deleteConfigButton: document.querySelector("#delete-config-button"),
  saveConfigButton: document.querySelector("#save-config-button"),
  loadConfigButton: document.querySelector("#load-config-button"),
  exportConfigButton: document.querySelector("#export-config-button"),
  importConfigButton: document.querySelector("#import-config-button"),
  importConfigInput: document.querySelector("#import-config-input"),
  savedConfigSelect: document.querySelector("#saved-config-select"),
  eventsPanel: document.querySelector("#events-panel"),
  toggleEventsButton: document.querySelector("#toggle-events-button"),
  clearLogButton: document.querySelector("#clear-log-button"),
  logOutput: document.querySelector("#log-output"),
  monitorPanel: document.querySelector("#hardware-monitor-panel"),
  toggleMonitorButton: document.querySelector("#toggle-monitor-button"),
  monitorGrid: document.querySelector("#monitor-grid"),
  statusTemplate: document.querySelector("#status-card-template"),
  commandTemplate: document.querySelector("#command-card-template"),
  monitorRowTemplate: document.querySelector("#monitor-row-template")
};

let mqttClient = createMqttClient({
  onConnected() {
    setConnectionBadge(elements.statusBadge, "connected", "Verbunden");
    updateLoggingButtons();
    appendLogEntry(elements.logOutput, "Verbindung zum Broker hergestellt.");
    refreshLoggingStatus();
    syncTopicSubscriptions();
  },
  onConnectionLost(errorMessage) {
    setConnectionBadge(elements.statusBadge, "error", "Verbindung getrennt");
    updateLoggingButtons();
    appendLogEntry(
      elements.logOutput,
      `Verbindung verloren: ${errorMessage || "Unbekannter Fehler"}`
    );
    refreshLoggingStatus();
  },
  onMessageArrived(topic, payloadText) {
    handleIncomingMessage(topic, payloadText);
  },
  onError(errorMessage) {
    setConnectionBadge(elements.statusBadge, "error", "Fehler");
    updateLoggingButtons();
    appendLogEntry(elements.logOutput, errorMessage);
    refreshLoggingStatus();
  },
  onDebug(message) {
    if (!shouldDisplayDebugMessage(message)) {
      return;
    }

    appendLogEntry(elements.logOutput, message, state.appSettings.autoScrollLog);
  }
});

let activeDragOperation = null;
let hardwareMonitorTimer = null;
let templateDiscoveryState = {};
let statusCardRegistry = new Map();
let pendingStatusRefreshIds = new Set();
let throttledStatusRefreshIds = new Set();
let statusRefreshTimer = null;
let throttledStatusRefreshTimer = null;
let loggingStatusTimer = null;
let loggingConfigSyncTimer = null;
let loggingRuntimeState = {
  active: false,
  status: "IDLE",
  outputDir: "",
  fileCount: 0,
  itemCount: 0,
  totalSizeBytes: 0,
  lastWriteAt: null,
  lastError: "",
  connected: false
};

const STATUS_UI_FLUSH_INTERVAL_MS = 120;
const STATUS_UI_THROTTLED_FLUSH_INTERVAL_MS = 1500;
const LOGGING_STATUS_REFRESH_INTERVAL_MS = 2000;
const LOGGING_CONFIG_SYNC_DELAY_MS = 400;

initialize();

function initialize() {
  state.templateCatalog = normalizeTemplateCatalog(state.templateCatalog);
  // Beim Start werden gespeicherte Daten in die Oberfläche geladen,
  // damit der Nutzer nicht jedes Mal alles neu anlegen muss.
  populateConnectionForm();
  renderStatusItems();
  renderCommandItems();
  renderTemplateCatalogPanel();
  applyTheme();
  applyPanelStates();
  applySectionVisibility();
  applyTemplateToolVisibility();
  refreshActiveConfigurationName();
  refreshSavedConfigurationOptions();
  bindEvents();
  startHardwareMonitor();
  startLoggingStatusPolling();
  setConnectionBadge(elements.statusBadge, "idle", "Getrennt");
  setStatusBadge(elements.loggingStatusBadge, "idle", "Logging: IDLE");
  renderLoggingSummary();
  updateLoggingSummaryVisibility();
  refreshLoggingStatus();
  appendLogEntry(
    elements.logOutput,
    window.location.protocol === "file:"
      ? "Anwendung von Datei gestartet. Der lokale Python-Server unter http://127.0.0.1:8080 muss laufen."
      : "Anwendung gestartet. Der lokale Python-Server uebernimmt die MQTT-Verbindung.",
    state.appSettings.autoScrollLog
  );
}

function bindEvents() {
  elements.connectionForm.addEventListener("submit", handleConnect);
  elements.disconnectButton.addEventListener("click", handleDisconnect);
  elements.toggleBrokerConfigButton.addEventListener("click", handleToggleBrokerConfig);
  elements.toggleLoggingButton.addEventListener("click", handleToggleLoggingPanel);
  elements.loggingOutputDirInput.addEventListener("input", handleLoggingOutputDirInput);
  elements.selectLoggingOutputDirButton.addEventListener("click", handleSelectLoggingOutputDir);
  elements.startLoggingButton.addEventListener("click", handleStartLogging);
  elements.stopLoggingButton.addEventListener("click", handleStopLogging);
  elements.importStatusTemplatesButton.addEventListener("click", () => {
    elements.importStatusTemplatesInput.click();
  });
  elements.clearStatusTemplatesButton.addEventListener("click", handleClearStatusTemplates);
  elements.importStatusTemplatesInput.addEventListener("change", handleImportStatusTemplates);
  elements.templateComponentSelect.addEventListener("change", handleTemplateSelectionChange);
  elements.templateScopeSelect.addEventListener("change", handleTemplateSelectionChange);
  elements.templateInstanceSelect.addEventListener("change", handleTemplateSelectionChange);
  elements.templateValueSelect.addEventListener("change", handleTemplateSelectionChange);
  elements.templateGroupInput.addEventListener("input", handleTemplateSelectionChange);
  elements.addStatusTemplateButton.addEventListener("click", handleAddStatusFromTemplate);
  elements.addStatusButton.addEventListener("click", () => {
    state.statusItems.push(createDefaultStatusItem());
    saveAll();
    renderStatusItems();
    scheduleLoggingConfigurationSync();
  });
  elements.addCommandButton.addEventListener("click", () => {
    state.commandItems.push(createDefaultCommand());
    saveAll();
    renderCommandItems();
  });
  elements.saveConfigButton.addEventListener("click", handleSaveConfiguration);
  elements.loadConfigButton.addEventListener("click", handleLoadConfiguration);
  elements.deleteConfigButton.addEventListener("click", handleDeleteConfiguration);
  elements.exportConfigButton.addEventListener("click", handleExportConfiguration);
  elements.importConfigButton.addEventListener("click", () => {
    elements.importConfigInput.click();
  });
  elements.importConfigInput.addEventListener("change", handleImportConfiguration);
  elements.toggleEventsButton.addEventListener("click", handleToggleEvents);
  elements.toggleMonitorButton.addEventListener("click", handleToggleHardwareMonitor);
  elements.clearLogButton.addEventListener("click", () => {
    elements.logOutput.textContent = "";
  });
  elements.connectionForm.autoScrollLog.addEventListener("change", (event) => {
    state.appSettings.autoScrollLog = event.target.checked;
    saveAll();
  });
  elements.themeMenuButton.addEventListener("click", handleToggleThemeMenu);
  elements.themeLightButton.addEventListener("click", () => {
    state.appSettings.theme = "light";
    saveAll();
    applyTheme();
    closeThemeMenu();
  });
  elements.themeDarkButton.addEventListener("click", () => {
    state.appSettings.theme = "dark";
    saveAll();
    applyTheme();
    closeThemeMenu();
  });
  SECTION_VISIBILITY_CONFIG.forEach(({ key, checkboxKey }) => {
    const checkbox = elements[checkboxKey];
    if (!(checkbox instanceof HTMLInputElement)) {
      return;
    }

    checkbox.addEventListener("change", (event) => {
      handleSectionVisibilityChange(key, event.target.checked);
    });
  });
  document.addEventListener("click", handleDocumentClick);
  document.addEventListener("keydown", handleDocumentKeydown);
}

function populateConnectionForm() {
  const { connection } = state;
  elements.connectionForm.host.value = connection.host;
  elements.connectionForm.port.value = connection.port;
  elements.connectionForm.username.value = connection.username;
  elements.connectionForm.password.value = connection.password;
  elements.connectionForm.autoScrollLog.checked =
    state.appSettings?.autoScrollLog ?? createDefaultAppSettings().autoScrollLog;
  elements.loggingOutputDirInput.value = state.appSettings.loggingOutputDir || "";
}

function applyPanelStates() {
  const isBrokerConfigCollapsed = state.appSettings.brokerConfigCollapsed === true;
  const isLoggingCollapsed = state.appSettings.loggingPanelCollapsed === true;
  const areEventsCollapsed = state.appSettings.eventsCollapsed === true;
  const isHardwareMonitorCollapsed = state.appSettings.hardwareMonitorCollapsed === true;

  elements.brokerPanel.classList.toggle("config-collapsed", isBrokerConfigCollapsed);
  elements.loggingPanel.classList.toggle("config-collapsed", isLoggingCollapsed);
  elements.eventsPanel.classList.toggle("config-collapsed", areEventsCollapsed);
  elements.monitorPanel.classList.toggle("config-collapsed", isHardwareMonitorCollapsed);
  elements.monitorGrid.hidden = isHardwareMonitorCollapsed;

  setCollapseToggleState(elements.toggleBrokerConfigButton, isBrokerConfigCollapsed, {
    expand: "Broker-Konfiguration einblenden",
    collapse: "Broker-Konfiguration ausblenden"
  });
  setCollapseToggleState(elements.toggleEventsButton, areEventsCollapsed, {
    expand: "Ereignisse einblenden",
    collapse: "Ereignisse ausblenden"
  });
  setCollapseToggleState(elements.toggleLoggingButton, isLoggingCollapsed, {
    expand: "CSV Logging einblenden",
    collapse: "CSV Logging ausblenden"
  });
  setCollapseToggleState(elements.toggleMonitorButton, isHardwareMonitorCollapsed, {
    expand: "Hardware Monitor einblenden",
    collapse: "Hardware Monitor ausblenden"
  });
  updateLoggingSummaryVisibility();
}

function applySectionVisibility() {
  const sectionVisibility = resolveSectionVisibilityState();

  SECTION_VISIBILITY_CONFIG.forEach(({ key, elementKey, checkboxKey }) => {
    const panel = elements[elementKey];
    const checkbox = elements[checkboxKey];
    const shouldShow = sectionVisibility[key] !== false;

    if (panel instanceof HTMLElement) {
      panel.hidden = !shouldShow;
    }

    if (checkbox instanceof HTMLInputElement) {
      checkbox.checked = shouldShow;
    }
  });
}

function handleSectionVisibilityChange(sectionKey, checked) {
  state.appSettings.sectionVisibility = {
    ...resolveSectionVisibilityState(),
    [sectionKey]: checked === true
  };
  saveAll();
  applySectionVisibility();
}

function resolveSectionVisibilityState() {
  const legacyTemplateVisibility = state.appSettings.showTemplateTools;

  return {
    ...createDefaultSectionVisibility(),
    templateImport: legacyTemplateVisibility !== false,
    ...(state.appSettings.sectionVisibility || {})
  };
}

function handleConnect(event) {
  event.preventDefault();
  const formData = new FormData(elements.connectionForm);
  state.connection = {
    host: String(formData.get("host") || "").trim(),
    port: Number(formData.get("port") || 0),
    username: String(formData.get("username") || "").trim(),
    password: String(formData.get("password") || "")
  };
  state.appSettings.autoScrollLog = formData.get("autoScrollLog") === "on";

  if (!state.connection.host || !state.connection.port) {
    appendLogEntry(
      elements.logOutput,
      "Verbindung nicht gestartet: Host und Port sind erforderlich.",
      state.appSettings.autoScrollLog
    );
    return;
  }

  saveAll();
  setConnectionBadge(elements.statusBadge, "idle", "Verbindung läuft");
  updateLoggingButtons();
  appendLogEntry(
    elements.logOutput,
    `Verbindungsversuch zu ${state.connection.host}:${state.connection.port}`,
    state.appSettings.autoScrollLog
  );

  mqttClient.connect(state.connection);
}

function handleDisconnect() {
  mqttClient.disconnect();
  setConnectionBadge(elements.statusBadge, "idle", "Getrennt");
  updateLoggingButtons();
  appendLogEntry(
    elements.logOutput,
    "Verbindung manuell getrennt.",
    state.appSettings.autoScrollLog
  );
}

function handleToggleBrokerConfig() {
  state.appSettings.brokerConfigCollapsed = !state.appSettings.brokerConfigCollapsed;
  saveAll();
  applyPanelStates();
}

function handleToggleEvents() {
  state.appSettings.eventsCollapsed = !state.appSettings.eventsCollapsed;
  saveAll();
  applyPanelStates();
}

function handleToggleLoggingPanel() {
  state.appSettings.loggingPanelCollapsed = !state.appSettings.loggingPanelCollapsed;
  saveAll();
  applyPanelStates();
}

function handleToggleHardwareMonitor() {
  state.appSettings.hardwareMonitorCollapsed = !state.appSettings.hardwareMonitorCollapsed;
  saveAll();
  applyPanelStates();
}

function handleLoggingOutputDirInput(event) {
  state.appSettings.loggingOutputDir = String(event.target.value || "");
  saveAll();
}

async function handleSelectLoggingOutputDir() {
  elements.selectLoggingOutputDirButton.disabled = true;

  try {
    const selectedDirectory = await selectLoggingDirectory(
      elements.loggingOutputDirInput.value.trim() || state.appSettings.loggingOutputDir
    );

    if (!selectedDirectory) {
      return;
    }

    elements.loggingOutputDirInput.value = selectedDirectory;
    state.appSettings.loggingOutputDir = selectedDirectory;
    saveAll();
  } catch (error) {
    appendLogEntry(
      elements.logOutput,
      `Ordnerauswahl konnte nicht geoeffnet werden: ${error.message}`,
      state.appSettings.autoScrollLog
    );
  } finally {
    elements.selectLoggingOutputDirButton.disabled = false;
  }
}

async function handleStartLogging() {
  const outputDir = elements.loggingOutputDirInput.value.trim();
  const statusItems = buildLoggingStatusItems();

  if (!outputDir) {
    appendLogEntry(
      elements.logOutput,
      "Logging wurde nicht gestartet: Bitte zuerst einen Zielordner angeben.",
      state.appSettings.autoScrollLog
    );
    return;
  }

  if (statusItems.length === 0) {
    appendLogEntry(
      elements.logOutput,
      "Logging wurde nicht gestartet: Es ist mindestens ein Statuswert mit Topic und Key erforderlich.",
      state.appSettings.autoScrollLog
    );
    return;
  }

  try {
    const loggingStatus = await startLogging(outputDir, statusItems);
    state.appSettings.loggingOutputDir = outputDir;
    saveAll();
    applyLoggingStatus(loggingStatus);
    appendLogEntry(
      elements.logOutput,
      `CSV Logging vorbereitet: ${loggingStatus.fileCount} Datei(en) im Ordner ${outputDir}.`,
      state.appSettings.autoScrollLog
    );
  } catch (error) {
    appendLogEntry(
      elements.logOutput,
      `Logging konnte nicht gestartet werden: ${error.message}`,
      state.appSettings.autoScrollLog
    );
    refreshLoggingStatus();
  }
}

async function handleStopLogging() {
  try {
    const loggingStatus = await stopLogging();
    applyLoggingStatus(loggingStatus);
    appendLogEntry(
      elements.logOutput,
      "CSV Logging wurde gestoppt.",
      state.appSettings.autoScrollLog
    );
  } catch (error) {
    appendLogEntry(
      elements.logOutput,
      `Logging konnte nicht gestoppt werden: ${error.message}`,
      state.appSettings.autoScrollLog
    );
    refreshLoggingStatus();
  }
}

function handleSaveConfiguration() {
  const suggestedName = state.appSettings.configName?.trim() || "mqtt-konfiguration";
  const requestedName = window.prompt("Name fuer die Konfiguration", suggestedName);

  if (requestedName === null) {
    return;
  }

  const trimmedName = requestedName.trim() || "mqtt-konfiguration";
  state.appSettings.configName = trimmedName;
  saveNamedConfiguration(trimmedName, state);
  saveAll();
  refreshActiveConfigurationName();
  refreshSavedConfigurationOptions(trimmedName);

  appendLogEntry(
    elements.logOutput,
    `Konfiguration "${trimmedName}" gespeichert.`,
    state.appSettings.autoScrollLog
  );
}

function handleLoadConfiguration() {
  const selectedConfigurationName = elements.savedConfigSelect.value.trim();

  if (!selectedConfigurationName) {
    appendLogEntry(
      elements.logOutput,
      "Konfiguration konnte nicht geladen werden: Bitte zuerst eine gespeicherte Konfiguration auswaehlen.",
      state.appSettings.autoScrollLog
    );
    return;
  }

  try {
    const importedConfiguration = loadNamedConfiguration(selectedConfigurationName);
    applyImportedConfiguration(importedConfiguration);
    refreshSavedConfigurationOptions(selectedConfigurationName);

    appendLogEntry(elements.logOutput, `Konfiguration "${selectedConfigurationName}" geladen.`, state.appSettings.autoScrollLog);
  } catch (error) {
    appendLogEntry(
      elements.logOutput,
      `Konfiguration konnte nicht geladen werden: ${error.message}`,
      state.appSettings.autoScrollLog
    );
  }
}

function handleDeleteConfiguration() {
  const selectedConfigurationName = elements.savedConfigSelect.value.trim();

  if (!selectedConfigurationName) {
    appendLogEntry(
      elements.logOutput,
      "Loeschen nicht moeglich: Bitte zuerst eine gespeicherte Konfiguration auswaehlen.",
      state.appSettings.autoScrollLog
    );
    return;
  }

  const shouldDelete = window.confirm(
    `Soll die Konfiguration "${selectedConfigurationName}" wirklich geloescht werden?`
  );

  if (!shouldDelete) {
    return;
  }

  try {
    deleteNamedConfiguration(selectedConfigurationName);

    if (state.appSettings.configName === selectedConfigurationName) {
      state.appSettings.configName = "";
      saveAll();
      refreshActiveConfigurationName();
    }

    refreshSavedConfigurationOptions();
    appendLogEntry(
      elements.logOutput,
      `Konfiguration "${selectedConfigurationName}" geloescht.`,
      state.appSettings.autoScrollLog
    );
  } catch (error) {
    appendLogEntry(
      elements.logOutput,
      `Konfiguration konnte nicht geloescht werden: ${error.message}`,
      state.appSettings.autoScrollLog
    );
  }
}

function handleExportConfiguration() {
  const exportedState = exportState(state);
  const suggestedName = (state.appSettings.configName || "mqtt-konfiguration")
    .trim()
    .replace(/[^\w.-]+/g, "-");
  const fileName = `${suggestedName || "mqtt-konfiguration"}.json`;
  const fileContent = JSON.stringify(exportedState, null, 2);
  const blob = new Blob([fileContent], { type: "application/json" });
  const downloadUrl = URL.createObjectURL(blob);
  const downloadLink = document.createElement("a");
  downloadLink.href = downloadUrl;
  downloadLink.download = fileName;
  downloadLink.click();
  URL.revokeObjectURL(downloadUrl);
  appendLogEntry(
    elements.logOutput,
    `Konfiguration als Datei exportiert: ${fileName}`,
    state.appSettings.autoScrollLog
  );
}

async function handleImportConfiguration(event) {
  const selectedFile = event.target.files?.[0];

  if (!selectedFile) {
    return;
  }

  try {
    const fileContent = await selectedFile.text();
    const importedConfiguration = importState(JSON.parse(fileContent));
    applyImportedConfiguration(importedConfiguration);
    appendLogEntry(
      elements.logOutput,
      `Konfigurationsdatei importiert: ${selectedFile.name}`,
      state.appSettings.autoScrollLog
    );
  } catch (error) {
    appendLogEntry(
      elements.logOutput,
      `Import fehlgeschlagen: ${error.message}`,
      state.appSettings.autoScrollLog
    );
  } finally {
    elements.importConfigInput.value = "";
  }
}

async function handleImportStatusTemplates(event) {
  const selectedFiles = [...(event.target.files || [])];

  if (selectedFiles.length === 0) {
    return;
  }

  try {
    const fileEntries = await Promise.all(
      selectedFiles
        .filter((file) => file.name.toLowerCase().endsWith(".json"))
        .map(async (file) => ({
          path: file.webkitRelativePath || file.name,
          content: await file.text()
        }))
    );
    const nextTemplateCatalog = buildTemplateCatalog(fileEntries);

    if (nextTemplateCatalog.components.length === 0) {
      throw new Error(
        "Es wurde keine gueltige Komponentenstruktur mit mqttWebImport.json und Werten gefunden."
      );
    }

    state.templateCatalog = nextTemplateCatalog;
    templateDiscoveryState = {};
    saveAll();
    renderTemplateCatalogPanel();
    syncTopicSubscriptions();
    appendLogEntry(
      elements.logOutput,
      `${nextTemplateCatalog.components.length} Komponenten-Vorlagen importiert.`,
      state.appSettings.autoScrollLog
    );
  } catch (error) {
    appendLogEntry(
      elements.logOutput,
      `Vorlagenimport fehlgeschlagen: ${error.message}`,
      state.appSettings.autoScrollLog
    );
  } finally {
    elements.importStatusTemplatesInput.value = "";
  }
}

function handleClearStatusTemplates() {
  state.templateCatalog = createEmptyTemplateCatalog();
  templateDiscoveryState = {};
  saveAll();
  renderTemplateCatalogPanel();
  syncTopicSubscriptions();
  appendLogEntry(
    elements.logOutput,
    "Importierte Status-Vorlagen wurden entfernt.",
    state.appSettings.autoScrollLog
  );
}

function handleTemplateSelectionChange() {
  renderTemplateCatalogPanel();
}

function handleAddStatusFromTemplate() {
  const selectedComponent = getSelectedTemplateComponent();
  const selectedScope = getSelectedTemplateScope();
  const selectedTemplate = getSelectedTemplate();
  const selectedInstanceId = elements.templateInstanceSelect.value.trim();
  const resolvedGroupName = elements.templateGroupInput.value.trim()
    || selectedComponent?.folderName
    || "";

  if (!selectedComponent || !selectedTemplate) {
    appendLogEntry(
      elements.logOutput,
      "Statuswert aus Vorlage konnte nicht angelegt werden: Bitte Komponente und Wert auswaehlen.",
      state.appSettings.autoScrollLog
    );
    return;
  }

  if (!selectedInstanceId) {
    appendLogEntry(
      elements.logOutput,
      "Statuswert aus Vorlage konnte nicht angelegt werden: Es wurde noch kein passender Bereichseintrag erkannt.",
      state.appSettings.autoScrollLog
    );
    return;
  }

  const nextStatusItem = createStatusItemFromTemplate(
    selectedComponent,
    selectedScope,
    selectedInstanceId,
    selectedTemplate,
    resolvedGroupName,
    createDefaultStatusItem
  );
  const discoveredTopic = resolveDiscoveredTopicForTemplate(
    selectedComponent?.id,
    selectedScope,
    selectedInstanceId,
    selectedTemplate?.key
  );

  if (discoveredTopic) {
    nextStatusItem.topic = discoveredTopic;
  }

  if (!nextStatusItem.topic || !nextStatusItem.key) {
    appendLogEntry(
      elements.logOutput,
      "Statuswert aus Vorlage konnte nicht angelegt werden: Topic oder Key sind unvollstaendig.",
      state.appSettings.autoScrollLog
    );
    return;
  }

  state.statusItems.push(nextStatusItem);
  saveAll();
  renderStatusItems();
  syncTopicSubscriptions();
  scheduleLoggingConfigurationSync();
  appendLogEntry(
    elements.logOutput,
    `Statuswert aus Vorlage hinzugefuegt: ${nextStatusItem.label} auf ${nextStatusItem.topic}.`,
    state.appSettings.autoScrollLog
  );
}

function renderTemplateCatalogPanel() {
  const templateCatalog = normalizeTemplateCatalog(state.templateCatalog);
  const components = templateCatalog.components;
  const hasTemplates = components.length > 0;

  elements.statusTemplatePanel.hidden = false;
  elements.clearStatusTemplatesButton.disabled = !hasTemplates;
  elements.templateComponentSelect.disabled = !hasTemplates;
  elements.templateScopeSelect.disabled = !hasTemplates;
  elements.templateInstanceSelect.disabled = !hasTemplates;
  elements.templateValueSelect.disabled = !hasTemplates;
  elements.templateGroupInput.disabled = !hasTemplates;

  populateTemplateComponentOptions(components);
  populateTemplateScopeOptions(getSelectedTemplateComponent());
  populateTemplateInstanceOptions();
  populateTemplateValueOptions();
  updateTemplateGroupPlaceholder();
  updateTemplateSummary(hasTemplates, components);
  updateTemplatePreview();
  applyTemplateToolVisibility();
}

function applyTemplateToolVisibility() {
  const shouldShowTemplateTools = resolveSectionVisibilityState().templateImport !== false;
  elements.templateTools.hidden = !shouldShowTemplateTools;
  elements.importStatusTemplatesButton.hidden = !shouldShowTemplateTools;
  elements.clearStatusTemplatesButton.hidden = !shouldShowTemplateTools;
}

function renderStatusItems() {
  const activeInputState = captureActiveInputState(elements.statusList);
  elements.statusList.textContent = "";
  renderGroupedItems(elements.statusList, buildGroupedStatusSections());
  rebuildStatusCardRegistry();

  toggleEmptyState(elements.statusEmptyState, state.statusItems.length === 0);
  restoreActiveInputState(elements.statusList, activeInputState);
}

function renderCommandItems() {
  const activeInputState = captureActiveInputState(elements.commandList);
  elements.commandList.textContent = "";
  renderGroupedItems(elements.commandList, buildGroupedCommandSections());

  toggleEmptyState(elements.commandEmptyState, state.commandItems.length === 0);
  restoreActiveInputState(elements.commandList, activeInputState);
}

function rebuildStatusCardRegistry() {
  statusCardRegistry = new Map();

  elements.statusList.querySelectorAll(".config-card[data-item-id]").forEach((card) => {
    const itemId = String(card.dataset.itemId || "").trim();

    if (!itemId) {
      return;
    }

    statusCardRegistry.set(itemId, card);
  });
}

function populateTemplateComponentOptions(components) {
  const previousComponentId = elements.templateComponentSelect.value;
  elements.templateComponentSelect.textContent = "";

  if (components.length === 0) {
    const emptyOption = document.createElement("option");
    emptyOption.value = "";
    emptyOption.textContent = "Keine Komponente verfuegbar";
    elements.templateComponentSelect.append(emptyOption);
    return;
  }

  components.forEach((component) => {
    const option = document.createElement("option");
    option.value = component.id;
    option.textContent = component.displayName;
    elements.templateComponentSelect.append(option);
  });

  const matchingComponent = components.find((component) => component.id === previousComponentId);
  elements.templateComponentSelect.value = matchingComponent ? previousComponentId : components[0].id;
}

function populateTemplateScopeOptions(selectedComponent) {
  const availableScopes = [
    {
      value: "parent",
      label: selectedComponent?.parentDescription || "Parent",
      enabled: Array.isArray(selectedComponent?.parentTemplates)
        && selectedComponent.parentTemplates.length > 0
    },
    {
      value: "child",
      label: selectedComponent?.childDescription || "Child",
      enabled: Array.isArray(selectedComponent?.childTemplates)
        && selectedComponent.childTemplates.length > 0
        && String(selectedComponent?.childSubtopic || "").trim() !== ""
    }
  ].filter((scopeOption) => scopeOption.enabled);

  const previousScope = elements.templateScopeSelect.value;
  elements.templateScopeSelect.textContent = "";

  if (availableScopes.length === 0) {
    const emptyOption = document.createElement("option");
    emptyOption.value = "";
    emptyOption.textContent = "Kein Bereich verfuegbar";
    elements.templateScopeSelect.append(emptyOption);
    return;
  }

  availableScopes.forEach((scopeOption) => {
    const option = document.createElement("option");
    option.value = scopeOption.value;
    option.textContent = scopeOption.label;
    elements.templateScopeSelect.append(option);
  });

  const matchingScope = availableScopes.find((scopeOption) => scopeOption.value === previousScope);
  elements.templateScopeSelect.value = matchingScope
    ? previousScope
    : availableScopes[0].value;
}

function populateTemplateInstanceOptions() {
  const selectedComponent = getSelectedTemplateComponent();
  const selectedScope = getSelectedTemplateScope();
  const previouslySelectedInstanceId = elements.templateInstanceSelect.value;
  const discoveredInstances = getDiscoveredInstances(selectedComponent?.id, selectedScope);
  elements.templateInstanceSelect.textContent = "";

  if (discoveredInstances.length === 0) {
    const emptyOption = document.createElement("option");
    emptyOption.value = "";
    emptyOption.textContent = "Noch nichts erkannt";
    elements.templateInstanceSelect.append(emptyOption);
    return;
  }

  discoveredInstances.forEach((instanceInfo) => {
    const option = document.createElement("option");
    option.value = instanceInfo.instanceId;
    option.textContent = buildDiscoveredInstanceLabel(
      selectedComponent,
      selectedScope,
      instanceInfo.instanceId
    );
    elements.templateInstanceSelect.append(option);
  });

  const matchingInstance = discoveredInstances.find(
    (instanceInfo) => instanceInfo.instanceId === previouslySelectedInstanceId
  );
  elements.templateInstanceSelect.value = matchingInstance
    ? previouslySelectedInstanceId
    : discoveredInstances[0].instanceId;
}

function populateTemplateValueOptions() {
  const selectedTemplate = getSelectedTemplate();
  const templates = getTemplatesForScope(
    getSelectedTemplateComponent(),
    getSelectedTemplateScope()
  );
  elements.templateValueSelect.textContent = "";

  if (templates.length === 0) {
    const emptyOption = document.createElement("option");
    emptyOption.value = "";
    emptyOption.textContent = "Kein Wert verfuegbar";
    elements.templateValueSelect.append(emptyOption);
    return;
  }

  templates.forEach((template) => {
    const option = document.createElement("option");
    option.value = template.id;
    option.textContent = template.unit
      ? `${template.label} (${template.key}) [${template.unit}]`
      : `${template.label} (${template.key})`;
    elements.templateValueSelect.append(option);
  });

  elements.templateValueSelect.value = templates.some((template) => template.id === selectedTemplate?.id)
    ? selectedTemplate.id
    : templates[0].id;
}

function updateTemplateGroupPlaceholder() {
  const selectedComponent = getSelectedTemplateComponent();

  if (!elements.templateGroupInput.value.trim()) {
    elements.templateGroupInput.placeholder = selectedComponent?.folderName
      ? `z. B. ${selectedComponent.folderName}`
      : "z. B. Inverter";
  }
}

function updateTemplateSummary(hasTemplates, components) {
  if (!hasTemplates) {
    elements.statusTemplateSummary.textContent =
      "Noch kein Vorlagenordner importiert. Die manuelle Eingabe bleibt weiter moeglich.";
    return;
  }

  const componentCount = components.length;
  const templateCount = components.reduce(
    (sum, component) => sum + component.parentTemplates.length + component.childTemplates.length,
    0
  );
  elements.statusTemplateSummary.textContent =
    `${componentCount} Komponenten und ${templateCount} Status-Vorlagen importiert. `
    + "Leere mqttName-Eintraege wurden automatisch ignoriert.";
}

function updateTemplatePreview() {
  const selectedComponent = getSelectedTemplateComponent();
  const selectedScope = getSelectedTemplateScope();
  const selectedTemplate = getSelectedTemplate();
  const selectedInstanceId = elements.templateInstanceSelect.value.trim();

  if (!selectedComponent || !selectedTemplate) {
    elements.statusTemplatePreview.textContent =
      "Waehle Komponente, Bereich, Eintrag und Wert aus.";
    elements.addStatusTemplateButton.disabled = true;
    return;
  }

  const previewTopic = resolveDiscoveredTopicForTemplate(
    selectedComponent?.id,
    selectedScope,
    selectedInstanceId,
    selectedTemplate?.key
  ) || buildStatusTopic(selectedComponent, selectedScope, selectedInstanceId);
  const previewUnit = selectedTemplate.unit ? `, Einheit: ${selectedTemplate.unit}` : "";
  elements.statusTemplatePreview.textContent = previewTopic
    ? `Topic: ${previewTopic}, Key: ${selectedTemplate.key}${previewUnit}`
    : "Es wurde noch kein passender Bereichseintrag erkannt.";
  elements.addStatusTemplateButton.disabled = previewTopic === "";
}

function getSelectedTemplateComponent() {
  return getCatalogComponent(state.templateCatalog, elements.templateComponentSelect.value);
}

function getSelectedTemplateScope() {
  return elements.templateScopeSelect.value === "child" ? "child" : "parent";
}

function getSelectedTemplate() {
  return getTemplatesForScope(
    getSelectedTemplateComponent(),
    getSelectedTemplateScope()
  ).find((template) => template.id === elements.templateValueSelect.value) || null;
}

function getDiscoveredInstances(componentId, scope) {
  const scopeState = templateDiscoveryState[buildDiscoveryStateKey(componentId, scope)];

  if (!scopeState) {
    return [];
  }

  return Object.entries(scopeState)
    .map(([instanceId, instanceInfo]) => ({
      instanceId,
      matchCount: Number(instanceInfo.matchCount || 0),
      keyTopics: instanceInfo.keyTopics || {}
    }))
    .filter((instanceInfo) => instanceInfo.instanceId !== "")
    .sort((leftInstance, rightInstance) => compareInstanceIds(leftInstance.instanceId, rightInstance.instanceId));
}

function updateTemplateDiscoveryState(topic, payload) {
  const discoveryMatches = findDiscoveryMatches(state.templateCatalog, topic, payload);
  let discoveryStateChanged = false;

  discoveryMatches.forEach((match) => {
    const discoveryStateKey = buildDiscoveryStateKey(match.componentId, match.scope);
    const currentScopeState = {
      ...(templateDiscoveryState[discoveryStateKey] || {})
    };
    const currentInstanceState = {
      ...(currentScopeState[match.instanceId] || {})
    };
    const previousMatchCount = Number(currentInstanceState.matchCount || 0);
    const previousKeyTopics = {
      ...(currentInstanceState.keyTopics || {})
    };
    const nextKeyTopics = {
      ...previousKeyTopics
    };

    match.matchingTemplates.forEach((template) => {
      if (template?.key) {
        nextKeyTopics[template.key] = topic;
      }
    });

    currentInstanceState.matchCount = Math.max(previousMatchCount, match.matchingTemplates.length);
    currentInstanceState.keyTopics = nextKeyTopics;
    currentScopeState[match.instanceId] = currentInstanceState;
    templateDiscoveryState[discoveryStateKey] = currentScopeState;
    discoveryStateChanged = discoveryStateChanged
      || previousMatchCount !== currentInstanceState.matchCount
      || JSON.stringify(previousKeyTopics) !== JSON.stringify(nextKeyTopics);
  });

  if (discoveryStateChanged) {
    renderTemplateCatalogPanel();
  }
}

function buildDiscoveryStateKey(componentId, scope) {
  return `${String(componentId || "")}:${String(scope || "")}`;
}

function resolveDiscoveredTopicForTemplate(componentId, scope, instanceId, templateKey) {
  const discoveryStateKey = buildDiscoveryStateKey(componentId, scope);
  const scopeState = templateDiscoveryState[discoveryStateKey] || {};
  const instanceState = scopeState[String(instanceId || "")] || {};
  const keyTopics = instanceState.keyTopics || {};
  return String(keyTopics[String(templateKey || "")] || "").trim();
}

function resolveScopeLabel(component, scope) {
  if (scope === "child") {
    return component?.childDescription || "Child";
  }

  return component?.parentDescription || "Parent";
}

function buildDiscoveredInstanceLabel(component, scope, instanceId) {
  if (scope !== "child") {
    return `${resolveScopeLabel(component, scope)} ${instanceId}`;
  }

  const [parentInstanceId, childInstanceId] = String(instanceId || "").split("/");

  if (!parentInstanceId || !childInstanceId) {
    return `${resolveScopeLabel(component, scope)} ${instanceId}`;
  }

  return `${component?.parentDescription || "Parent"} ${parentInstanceId} / ${component?.childDescription || "Child"} ${childInstanceId}`;
}

function compareInstanceIds(leftInstanceId, rightInstanceId) {
  const leftParts = String(leftInstanceId || "").split("/").map((part) => Number.parseInt(part, 10));
  const rightParts = String(rightInstanceId || "").split("/").map((part) => Number.parseInt(part, 10));
  const maxLength = Math.max(leftParts.length, rightParts.length);

  for (let index = 0; index < maxLength; index += 1) {
    const leftValue = Number.isNaN(leftParts[index]) ? -1 : leftParts[index];
    const rightValue = Number.isNaN(rightParts[index]) ? -1 : rightParts[index];

    if (leftValue !== rightValue) {
      return leftValue - rightValue;
    }
  }

  return 0;
}

function sendCommand(item) {
  if (!mqttClient.isConnected()) {
    appendLogEntry(
      elements.logOutput,
      "Befehl nicht gesendet: keine aktive Verbindung.",
      state.appSettings.autoScrollLog
    );
    return;
  }

  if (!item.topic || !item.key) {
    appendLogEntry(
      elements.logOutput,
      "Befehl nicht gesendet: Topic und Key sind erforderlich.",
      state.appSettings.autoScrollLog
    );
    return;
  }

  const payload = {
    // Der eingegebene Wert wird vor dem Senden moeglichst passend
    // in Zahl oder Text umgewandelt.
    [item.key]: parseCommandValue(item.value)
  };

  mqttClient.publish(item.topic, JSON.stringify(payload));

  if (item.logEnabled === true) {
    appendLogEntry(
      elements.logOutput,
      `Befehl gesendet an ${item.topic}: ${JSON.stringify(payload)}`,
      state.appSettings.autoScrollLog
    );
  }
}

function syncTopicSubscriptions() {
  if (!mqttClient.isConnected()) {
    return;
  }

  const configuredStatusTopics = state.statusItems.map((item) => item.topic.trim()).filter(Boolean);
  const discoveryTopics = buildDiscoveryTopics(state.templateCatalog);
  const topics = [...new Set([...configuredStatusTopics, ...discoveryTopics])];
  mqttClient.syncSubscriptions(topics);

  if (state.statusItems.some((item) => item.logEnabled === true && item.topic.trim())) {
    appendLogEntry(
      elements.logOutput,
      `Abonnierte Topics aktualisiert: ${topics.join(", ") || "-"}`,
      state.appSettings.autoScrollLog
    );
  }
}

function handleIncomingMessage(topic, payloadText) {
  let payload;

  try {
    payload = JSON.parse(payloadText);
  } catch (error) {
    appendLogEntry(
      elements.logOutput,
      `Nachricht auf ${topic} ignoriert: Payload ist kein gueltiges JSON. Empfangene Payload: ${payloadText}`,
      state.appSettings.autoScrollLog
    );
    return;
  }

  const matchingLogEnabledItems = state.statusItems.filter((item) =>
    mqttTopicMatchesFilter(item.topic.trim(), topic) && item.logEnabled === true
  );

  if (matchingLogEnabledItems.length > 0) {
    appendLogEntry(
      elements.logOutput,
      `Nachricht empfangen auf ${topic}: ${payloadText}`,
      state.appSettings.autoScrollLog
    );
  }

  updateTemplateDiscoveryState(topic, payload);
  let statusValueChanged = false;

  state.statusItems.forEach((item) => {
    if (!mqttTopicMatchesFilter(item.topic.trim(), topic) || !item.key.trim()) {
      return;
    }

    if (!Object.prototype.hasOwnProperty.call(payload, item.key)) {
      return;
    }

    // Es wird nur genau der JSON-Wert uebernommen, den der Nutzer
    // fuer dieses Statusfeld konfiguriert hat.
    item.lastValue = payload[item.key];
    item.lastUpdated = Date.now();
    appendHistoryValue(item, Number(payload[item.key]));
    statusValueChanged = true;
    queueStatusCardRefresh(item.id, item);
  });

  if (statusValueChanged) {
    startStatusRefreshTimer();
    startThrottledStatusRefreshTimer();
  }
}

function parseCommandValue(valueText) {
  const trimmedValue = valueText.trim();

  if (trimmedValue === "") {
    return "";
  }

  if (/^-?\d+$/.test(trimmedValue)) {
    return Number.parseInt(trimmedValue, 10);
  }

  if (/^-?\d+\.\d+$/.test(trimmedValue)) {
    return Number.parseFloat(trimmedValue);
  }

  return trimmedValue;
}

function formatStatusValue(item) {
  const normalizedUnit = String(item?.unit || "").trim();
  const normalizedValue = item?.lastValue;

  if (normalizedValue === null) {
    return "-";
  }

  return normalizedUnit ? `${String(normalizedValue)} ${normalizedUnit}` : String(normalizedValue);
}

function mqttTopicMatchesFilter(topicFilter, topic) {
  const normalizedFilter = String(topicFilter || "").trim();
  const normalizedTopic = String(topic || "").trim();

  if (!normalizedFilter || !normalizedTopic) {
    return false;
  }

  if (!normalizedFilter.includes("+") && !normalizedFilter.includes("#")) {
    return normalizedFilter === normalizedTopic;
  }

  const filterSegments = normalizedFilter.split("/");
  const topicSegments = normalizedTopic.split("/");

  for (let index = 0; index < filterSegments.length; index += 1) {
    const filterSegment = filterSegments[index];
    const topicSegment = topicSegments[index];

    if (filterSegment === "#") {
      return true;
    }

    if (filterSegment === "+") {
      if (typeof topicSegment === "undefined") {
        return false;
      }

      continue;
    }

    if (filterSegment !== topicSegment) {
      return false;
    }
  }

  return filterSegments.length === topicSegments.length;
}

function queueStatusCardRefresh(itemId, item = null) {
  const normalizedItemId = String(itemId || "").trim();

  if (!normalizedItemId) {
    return;
  }

  if (shouldThrottleCollapsedHistoryRefresh(item)) {
    throttledStatusRefreshIds.add(normalizedItemId);
    pendingStatusRefreshIds.delete(normalizedItemId);
    return;
  }

  pendingStatusRefreshIds.add(normalizedItemId);
  throttledStatusRefreshIds.delete(normalizedItemId);
}

function startStatusRefreshTimer() {
  if (statusRefreshTimer !== null) {
    return;
  }

  statusRefreshTimer = window.setTimeout(() => {
    statusRefreshTimer = null;
    flushStatusCardRefreshes();
  }, STATUS_UI_FLUSH_INTERVAL_MS);
}

function shouldThrottleCollapsedHistoryRefresh(item) {
  if (!item) {
    return false;
  }

  return (
    item.collapsed === true
    && item.showHistory === true
    && item.historyRefreshWhileCollapsedThrottled === true
    && item.historyRefreshWhileCollapsed !== true
  );
}

function startThrottledStatusRefreshTimer() {
  if (throttledStatusRefreshTimer !== null) {
    return;
  }

  throttledStatusRefreshTimer = window.setTimeout(() => {
    throttledStatusRefreshTimer = null;
    flushThrottledStatusCardRefreshes();
  }, STATUS_UI_THROTTLED_FLUSH_INTERVAL_MS);
}

function flushStatusCardRefreshes() {
  if (pendingStatusRefreshIds.size === 0) {
    return;
  }

  const itemIdsToRefresh = [...pendingStatusRefreshIds];
  pendingStatusRefreshIds.clear();

  itemIdsToRefresh.forEach((itemId) => {
    const item = state.statusItems.find((entry) => entry.id === itemId);
    const card = statusCardRegistry.get(itemId);

    if (!item || !(card instanceof HTMLElement)) {
      return;
    }

    updateStatusCardDisplay(card, item);
  });
}

function flushThrottledStatusCardRefreshes() {
  if (throttledStatusRefreshIds.size === 0) {
    return;
  }

  const itemIdsToRefresh = [...throttledStatusRefreshIds];
  throttledStatusRefreshIds.clear();

  itemIdsToRefresh.forEach((itemId) => {
    const item = state.statusItems.find((entry) => entry.id === itemId);
    const card = statusCardRegistry.get(itemId);

    if (!item || !(card instanceof HTMLElement)) {
      return;
    }

    updateStatusCardDisplay(card, item);
  });
}

function saveAll() {
  saveState(state);
}

function buildLoggingStatusItems() {
  return state.statusItems
    .filter((item) => item.topic.trim() && item.key.trim())
    .map((item) => ({
      id: item.id,
      label: item.label,
      group: item.group,
      topic: item.topic,
      key: item.key
    }));
}

async function refreshLoggingStatus(silent = true) {
  try {
    const loggingStatus = await fetchLoggingStatus();
    applyLoggingStatus(loggingStatus);
  } catch (error) {
    applyLoggingStatus({
      ...loggingRuntimeState,
      active: false,
      status: mqttClient.isConnected() ? "IDLE" : "STOPPED",
      connected: mqttClient.isConnected(),
      lastError: silent ? loggingRuntimeState.lastError : error.message
    });

    if (!silent) {
      appendLogEntry(
        elements.logOutput,
        `Logging-Status konnte nicht abgefragt werden: ${error.message}`,
        state.appSettings.autoScrollLog
      );
    }
  }
}

function applyLoggingStatus(loggingStatus) {
  loggingRuntimeState = {
    active: loggingStatus?.active === true,
    status: String(loggingStatus?.status || "IDLE").trim() || "IDLE",
    outputDir: String(loggingStatus?.outputDir || "").trim(),
    fileCount: Number(loggingStatus?.fileCount || 0),
    itemCount: Number(loggingStatus?.itemCount || 0),
    totalSizeBytes: Number(loggingStatus?.totalSizeBytes || 0),
    lastWriteAt: loggingStatus?.lastWriteAt ?? null,
    lastError: String(loggingStatus?.lastError || "").trim(),
    connected: loggingStatus?.connected === true
  };

  if (loggingRuntimeState.outputDir && elements.loggingOutputDirInput.value.trim() === "") {
    elements.loggingOutputDirInput.value = loggingRuntimeState.outputDir;
    state.appSettings.loggingOutputDir = loggingRuntimeState.outputDir;
    saveAll();
  }

  const badgeState = resolveLoggingBadgeState(loggingRuntimeState.status);
  setStatusBadge(
    elements.loggingStatusBadge,
    badgeState,
    `Logging: ${loggingRuntimeState.status}`
  );
  renderLoggingSummary();
  updateLoggingSummaryVisibility();
  updateLoggingButtons();
}

function resolveLoggingBadgeState(status) {
  if (status === "RUN" || status === "STARTED") {
    return "running";
  }

  if (status === "ERROR") {
    return "error";
  }

  return "idle";
}

function renderLoggingSummary() {
  const summaryParts = [];
  const outputDir = loggingRuntimeState.outputDir || state.appSettings.loggingOutputDir || "-";
  summaryParts.push(`Status ${loggingRuntimeState.status}`);
  summaryParts.push(`Ordner ${outputDir}`);
  summaryParts.push(`CSV-Dateien ${loggingRuntimeState.fileCount}`);
  summaryParts.push(`Statuswerte ${loggingRuntimeState.itemCount}`);
  summaryParts.push(`CSV-Gesamtgroesse ${formatByteSize(loggingRuntimeState.totalSizeBytes)}`);

  if (loggingRuntimeState.lastWriteAt) {
    summaryParts.push(`Letzter Schreibvorgang ${formatTimestamp(loggingRuntimeState.lastWriteAt)}`);
  }

  if (loggingRuntimeState.lastError) {
    summaryParts.push(`Fehler ${loggingRuntimeState.lastError}`);
  }

  elements.loggingSummary.textContent = summaryParts.join(" | ");
}

function updateLoggingSummaryVisibility() {
  const isLoggingCollapsed = state.appSettings.loggingPanelCollapsed === true;
  const shouldShowSummary = !isLoggingCollapsed || loggingRuntimeState.active === true;
  elements.loggingSummary.hidden = !shouldShowSummary;
}

function formatByteSize(byteCount) {
  const normalizedByteCount = Number.isFinite(byteCount) && byteCount > 0 ? byteCount : 0;

  if (normalizedByteCount < 1024) {
    return `${normalizedByteCount} B`;
  }

  if (normalizedByteCount < 1024 * 1024) {
    return `${(normalizedByteCount / 1024).toFixed(1)} KB`;
  }

  if (normalizedByteCount < 1024 * 1024 * 1024) {
    return `${(normalizedByteCount / (1024 * 1024)).toFixed(1)} MB`;
  }

  return `${(normalizedByteCount / (1024 * 1024 * 1024)).toFixed(1)} GB`;
}

function updateLoggingButtons() {
  const canStart = mqttClient.isConnected() && loggingRuntimeState.active !== true;
  const canStop = loggingRuntimeState.active === true;
  elements.startLoggingButton.disabled = !canStart;
  elements.stopLoggingButton.disabled = !canStop;
}

function startLoggingStatusPolling() {
  if (loggingStatusTimer !== null) {
    window.clearInterval(loggingStatusTimer);
  }

  loggingStatusTimer = window.setInterval(() => {
    refreshLoggingStatus();
  }, LOGGING_STATUS_REFRESH_INTERVAL_MS);
}

function scheduleLoggingConfigurationSync() {
  if (loggingRuntimeState.active !== true) {
    return;
  }

  if (loggingConfigSyncTimer !== null) {
    window.clearTimeout(loggingConfigSyncTimer);
  }

  loggingConfigSyncTimer = window.setTimeout(async () => {
    loggingConfigSyncTimer = null;
    const outputDir = state.appSettings.loggingOutputDir || loggingRuntimeState.outputDir;

    try {
      const loggingStatus = await startLogging(
        outputDir,
        buildLoggingStatusItems()
      );
      applyLoggingStatus(loggingStatus);
    } catch (error) {
      appendLogEntry(
        elements.logOutput,
        `Aktives Logging konnte nicht aktualisiert werden: ${error.message}`,
        state.appSettings.autoScrollLog
      );
      refreshLoggingStatus();
    }
  }, LOGGING_CONFIG_SYNC_DELAY_MS);
}

function applyStatusItemChange(item, field, value) {
  if (field === "showHistory") {
    item.showHistory = value === true;

    if (item.showHistory !== true) {
      item.historyValues = [];
      item.historyRefreshWhileCollapsed = false;
      item.historyRefreshWhileCollapsedThrottled = false;
      item.historyManualScale = false;
      item.historyMin = null;
      item.historyMax = null;
    }

    return;
  }

  if (field === "historyLimit") {
    item.historyLimit = clampHistoryLimit(value);
    item.historyValues = Array.isArray(item.historyValues)
      ? item.historyValues.slice(-item.historyLimit)
      : [];
    return;
  }

  if (field === "historyManualScale") {
    item.historyManualScale = value === true;

    if (item.historyManualScale === true) {
      const axisBounds = resolveHistoryAxisBounds(item.historyValues || [], item);
      item.historyMin = axisBounds.minValue;
      item.historyMax = axisBounds.maxValue;
    } else {
      item.historyMin = null;
      item.historyMax = null;
    }

    return;
  }

  if (field === "historyRefreshWhileCollapsed") {
    item.historyRefreshWhileCollapsed = value === true;

    if (item.historyRefreshWhileCollapsed === true) {
      item.historyRefreshWhileCollapsedThrottled = false;
    }

    return;
  }

  if (field === "historyRefreshWhileCollapsedThrottled") {
    item.historyRefreshWhileCollapsedThrottled = value === true;

    if (item.historyRefreshWhileCollapsedThrottled === true) {
      item.historyRefreshWhileCollapsed = false;
    }

    return;
  }

  if (field === "historyMin") {
    item.historyMin = normalizeAxisValue(value);
    ensureManualAxisRangeOrder(item, "historyMin");
    return;
  }

  if (field === "historyMax") {
    item.historyMax = normalizeAxisValue(value);
    ensureManualAxisRangeOrder(item, "historyMax");
    return;
  }

  item[field] = value;
}

function ensureManualAxisRangeOrder(item, preferredField) {
  const manualMin = normalizeAxisValue(item.historyMin);
  const manualMax = normalizeAxisValue(item.historyMax);

  if (manualMin === null || manualMax === null || manualMin < manualMax) {
    return;
  }

  if (preferredField === "historyMin") {
    item.historyMax = manualMin + 1;
    return;
  }

  item.historyMin = manualMax - 1;
}

function applyImportedConfiguration(importedConfiguration) {
  state.connection = importedConfiguration.connection;
  state.appSettings = importedConfiguration.appSettings;
  state.templateCatalog = normalizeTemplateCatalog(importedConfiguration.templateCatalog);
  state.statusItems = importedConfiguration.statusItems;
  state.commandItems = importedConfiguration.commandItems;
  templateDiscoveryState = {};

  saveAll();
  populateConnectionForm();
  renderStatusItems();
  renderCommandItems();
  renderTemplateCatalogPanel();
  applyTheme();
  applyPanelStates();
  applySectionVisibility();
  applyTemplateToolVisibility();
  refreshActiveConfigurationName();
  syncTopicSubscriptions();
  refreshLoggingStatus();
  scheduleLoggingConfigurationSync();
}

function refreshSavedConfigurationOptions(selectedName = state.appSettings.configName || "") {
  const savedConfigurationNames = listSavedConfigurationNames();
  const previousValue = selectedName.trim() || elements.savedConfigSelect.value.trim();

  elements.savedConfigSelect.textContent = "";

  const emptyOption = document.createElement("option");
  emptyOption.value = "";
  emptyOption.textContent = savedConfigurationNames.length
    ? "Konfiguration auswaehlen"
    : "Keine gespeicherte Konfiguration";
  elements.savedConfigSelect.append(emptyOption);

  savedConfigurationNames.forEach((configurationName) => {
    const option = document.createElement("option");
    option.value = configurationName;
    option.textContent = configurationName;
    elements.savedConfigSelect.append(option);
  });

  if (savedConfigurationNames.includes(previousValue)) {
    elements.savedConfigSelect.value = previousValue;
  }

  elements.loadConfigButton.disabled = savedConfigurationNames.length === 0;
  elements.deleteConfigButton.disabled = savedConfigurationNames.length === 0;
}

function refreshActiveConfigurationName() {
  const activeConfigurationName = String(state.appSettings.configName || "").trim();

  elements.activeConfigName.hidden = activeConfigurationName === "";
  elements.activeConfigName.textContent = activeConfigurationName
    ? `Konfiguration: ${activeConfigurationName}`
    : "";
  elements.activeConfigName.title = activeConfigurationName
    ? `Aktive Konfiguration: ${activeConfigurationName}`
    : "";
}

function applyTheme() {
  const normalizedTheme = state.appSettings.theme === "dark" ? "dark" : "light";
  document.documentElement.dataset.theme = normalizedTheme;
}

function buildGroupedStatusSections() {
  return buildGroups(state.statusItems).map(({ groupName, items }) => {
    return createGroupSection(groupName, items, {
      type: "status",
      collapsed: isGroupCollapsed("status", groupName),
      onMoveGroup(draggedGroupName, targetGroupName, insertAfterTarget) {
        state.statusItems = reorderGroups(
          state.statusItems,
          draggedGroupName,
          targetGroupName,
          insertAfterTarget
        );
        saveAll();
        renderStatusItems();
      },
      onRemoveGroup() {
        removeGroupItems("status", groupName);
      },
      buildCard(item) {
        const card = buildStatusCard(elements.statusTemplate, item, {
          onChange(field, value) {
            applyStatusItemChange(item, field, value);
            saveAll();
            if (field !== "activeTab") {
              syncTopicSubscriptions();
              scheduleLoggingConfigurationSync();
            }
            renderStatusItems();
          },
          onToggleCollapse() {
            item.collapsed = !item.collapsed;
            saveAll();
            renderStatusItems();
          },
          onRemove() {
            state.statusItems = state.statusItems.filter((entry) => entry.id !== item.id);
            saveAll();
            renderStatusItems();
            syncTopicSubscriptions();
            scheduleLoggingConfigurationSync();
          }
        });

        return card;
      },
      onMoveItem(draggedItemId, targetItemId, insertAfterTarget) {
        state.statusItems = reorderItemsWithinGroup(
          state.statusItems,
          groupName,
          draggedItemId,
          targetItemId,
          insertAfterTarget
        );
        saveAll();
        renderStatusItems();
      },
      onToggleGroup(nextCollapsed) {
        setGroupCollapsedState("status", groupName, nextCollapsed);
        saveAll();
        renderStatusItems();
      }
    });
  });
}

function buildGroupedCommandSections() {
  return buildGroups(state.commandItems).map(({ groupName, items }) => {
    return createGroupSection(groupName, items, {
      type: "command",
      collapsed: isGroupCollapsed("command", groupName),
      onMoveGroup(draggedGroupName, targetGroupName, insertAfterTarget) {
        state.commandItems = reorderGroups(
          state.commandItems,
          draggedGroupName,
          targetGroupName,
          insertAfterTarget
        );
        saveAll();
        renderCommandItems();
      },
      onRemoveGroup() {
        removeGroupItems("command", groupName);
      },
      buildCard(item) {
        return buildCommandCard(elements.commandTemplate, item, {
          onChange(field, value) {
            item[field] = value;
            saveAll();
            renderCommandItems();
          },
          onToggleCollapse() {
            item.collapsed = !item.collapsed;
            saveAll();
            renderCommandItems();
          },
          onRemove() {
            state.commandItems = state.commandItems.filter((entry) => entry.id !== item.id);
            saveAll();
            renderCommandItems();
          },
          onSend() {
            sendCommand(item);
          }
        });
      },
      onMoveItem(draggedItemId, targetItemId, insertAfterTarget) {
        state.commandItems = reorderItemsWithinGroup(
          state.commandItems,
          groupName,
          draggedItemId,
          targetItemId,
          insertAfterTarget
        );
        saveAll();
        renderCommandItems();
      },
      onToggleGroup(nextCollapsed) {
        setGroupCollapsedState("command", groupName, nextCollapsed);
        saveAll();
        renderCommandItems();
      }
    });
  });
}

function buildGroups(items) {
  const groups = new Map();

  items.forEach((item) => {
    const groupName = item.group?.trim() || "Ohne Gruppe";

    if (!groups.has(groupName)) {
      groups.set(groupName, []);
    }

    groups.get(groupName).push(item);
  });

  return [...groups.entries()].map(([groupName, groupedItems]) => ({
    groupName,
    items: groupedItems
  }));
}

function renderGroupedItems(container, sections) {
  const fragment = document.createDocumentFragment();
  sections.forEach((section) => {
    fragment.append(section);
  });
  container.append(fragment);
}

function createGroupSection(groupName, items, handlers) {
  const section = document.createElement("section");
  section.className = "group-section";
  section.dataset.groupName = groupName;
  section.dataset.itemType = handlers.type;

  const header = document.createElement("div");
  header.className = "group-header";

  const titleRow = document.createElement("div");
  titleRow.className = "group-title-row";

  const dragHandle = document.createElement("button");
  dragHandle.type = "button";
  dragHandle.className = "drag-handle";
  dragHandle.dataset.action = "group-drag-handle";
  dragHandle.setAttribute("aria-label", `${groupName} verschieben`);
  dragHandle.title = `${groupName} verschieben`;
  dragHandle.draggable = true;
  titleRow.append(dragHandle);

  const title = document.createElement("h3");
  title.className = "group-title";
  title.textContent = groupName;
  titleRow.append(title);
  header.append(titleRow);

  const toggleButton = document.createElement("button");
  toggleButton.type = "button";
  toggleButton.className = "collapse-toggle";
  const actionRow = document.createElement("div");
  actionRow.className = "group-actions";
  const removeGroupButton = document.createElement("button");
  removeGroupButton.type = "button";
  removeGroupButton.className = "danger-button";
  removeGroupButton.textContent = "Entfernen";
  removeGroupButton.hidden = handlers.collapsed === true;
  removeGroupButton.addEventListener("click", () => {
    handlers.onRemoveGroup();
  });
  actionRow.append(removeGroupButton);
  setCollapseToggleState(toggleButton, handlers.collapsed === true, {
    expand: `${groupName} einblenden`,
    collapse: `${groupName} ausblenden`
  });
  toggleButton.addEventListener("click", () => {
    const nextCollapsed = handlers.collapsed !== true;

    // Die Anzeige wird sofort umgeschaltet, damit der erste Klick
    // ohne wahrnehmbare Verzoegerung genau den gewuenschten Effekt hat.
    itemsContainer.hidden = nextCollapsed;
    removeGroupButton.hidden = nextCollapsed;
    setCollapseToggleState(toggleButton, nextCollapsed, {
      expand: `${groupName} einblenden`,
      collapse: `${groupName} ausblenden`
    });
    handlers.onToggleGroup(nextCollapsed);
  });
  actionRow.append(toggleButton);
  header.append(actionRow);

  section.append(header);
  attachGroupSectionDragAndDrop(section, dragHandle, {
    itemType: handlers.type,
    groupName,
    onMoveGroup: handlers.onMoveGroup
  });

  const itemsContainer = document.createElement("div");
  itemsContainer.className = "group-items";
  itemsContainer.dataset.groupName = groupName;
  itemsContainer.dataset.itemType = handlers.type;
  itemsContainer.hidden = handlers.collapsed === true;

  items.forEach((item) => {
    const card = handlers.buildCard(item);
    attachDragAndDrop(card, itemsContainer, {
      itemType: handlers.type,
      groupName,
      onMoveItem: handlers.onMoveItem
    });
    itemsContainer.append(card);
  });

  attachGroupDropZone(itemsContainer, {
    itemType: handlers.type,
    groupName,
    onMoveItem: handlers.onMoveItem,
    lastItemId: items.length > 0 ? items[items.length - 1].id : ""
  });

  section.append(itemsContainer);
  return section;
}

function attachDragAndDrop(card, itemsContainer, handlers) {
  const dragHandle = card.querySelector('[data-action="drag-handle"]');

  if (!(dragHandle instanceof HTMLButtonElement)) {
    return;
  }

  dragHandle.addEventListener("dragstart", (event) => {
    // Die Drag-Information wird zentral gehalten, damit nur Karten
    // derselben Gruppe und desselben Bereichs umsortiert werden koennen.
    activeDragOperation = {
      mode: "item",
      itemId: card.dataset.itemId || "",
      itemType: handlers.itemType,
      groupName: handlers.groupName
    };

    if (event.dataTransfer) {
      event.dataTransfer.effectAllowed = "move";
      event.dataTransfer.setData("text/plain", activeDragOperation.itemId);
    }

    itemsContainer.classList.add("drag-active");
    card.classList.add("drag-source");
  });

  dragHandle.addEventListener("dragend", () => {
    activeDragOperation = null;
    clearDragState();
  });

  card.addEventListener("dragover", (event) => {
    if (!canDropOnGroup(handlers.itemType, handlers.groupName)) {
      return;
    }

    event.preventDefault();
    const insertAfterTarget = shouldInsertAfter(event, card);
    card.dataset.dropPosition = insertAfterTarget ? "after" : "before";
  });

  card.addEventListener("dragleave", (event) => {
    if (event.relatedTarget instanceof Node && card.contains(event.relatedTarget)) {
      return;
    }

    delete card.dataset.dropPosition;
  });

  card.addEventListener("drop", (event) => {
    if (!canDropOnGroup(handlers.itemType, handlers.groupName)) {
      return;
    }

    event.preventDefault();
    const draggedItemId = activeDragOperation?.itemId || "";
    const targetItemId = card.dataset.itemId || "";
    const insertAfterTarget = shouldInsertAfter(event, card);
    delete card.dataset.dropPosition;

    if (!draggedItemId || !targetItemId || draggedItemId === targetItemId) {
      clearDragState();
      return;
    }

    handlers.onMoveItem(draggedItemId, targetItemId, insertAfterTarget);
    activeDragOperation = null;
    clearDragState();
  });
}

function attachGroupDropZone(itemsContainer, handlers) {
  itemsContainer.addEventListener("dragover", (event) => {
    if (!canDropOnGroup(handlers.itemType, handlers.groupName)) {
      return;
    }

    event.preventDefault();
    itemsContainer.dataset.dragHover = "true";
  });

  itemsContainer.addEventListener("dragleave", (event) => {
    if (event.relatedTarget instanceof Node && itemsContainer.contains(event.relatedTarget)) {
      return;
    }

    delete itemsContainer.dataset.dragHover;
  });

  itemsContainer.addEventListener("drop", (event) => {
    if (!canDropOnGroup(handlers.itemType, handlers.groupName)) {
      return;
    }

    const dropCard = event.target instanceof Element
      ? event.target.closest(".config-card")
      : null;

    if (dropCard) {
      return;
    }

    event.preventDefault();
    delete itemsContainer.dataset.dragHover;

    const draggedItemId = activeDragOperation?.itemId || "";
    const targetItemId = handlers.lastItemId;

    if (!draggedItemId || !targetItemId || draggedItemId === targetItemId) {
      clearDragState();
      return;
    }

    handlers.onMoveItem(draggedItemId, targetItemId, true);
    activeDragOperation = null;
    clearDragState();
  });
}

function canDropOnGroup(itemType, groupName) {
  return (
    activeDragOperation?.mode === "item" &&
    activeDragOperation?.itemType === itemType &&
    activeDragOperation?.groupName === groupName
  );
}

function attachGroupSectionDragAndDrop(section, dragHandle, handlers) {
  dragHandle.addEventListener("dragstart", (event) => {
    activeDragOperation = {
      mode: "group",
      itemType: handlers.itemType,
      groupName: handlers.groupName
    };

    if (event.dataTransfer) {
      event.dataTransfer.effectAllowed = "move";
      event.dataTransfer.setData("text/plain", handlers.groupName);
    }

    section.classList.add("drag-source");
  });

  dragHandle.addEventListener("dragend", () => {
    activeDragOperation = null;
    clearDragState();
  });

  section.addEventListener("dragover", (event) => {
    if (!canDropOnSection(handlers.itemType, handlers.groupName)) {
      return;
    }

    event.preventDefault();
    const insertAfterTarget = shouldInsertAfter(event, section);
    section.dataset.dropPosition = insertAfterTarget ? "after" : "before";
  });

  section.addEventListener("dragleave", (event) => {
    if (event.relatedTarget instanceof Node && section.contains(event.relatedTarget)) {
      return;
    }

    delete section.dataset.dropPosition;
  });

  section.addEventListener("drop", (event) => {
    if (!canDropOnSection(handlers.itemType, handlers.groupName)) {
      return;
    }

    event.preventDefault();
    const draggedGroupName = activeDragOperation?.groupName || "";
    const targetGroupName = handlers.groupName;
    const insertAfterTarget = shouldInsertAfter(event, section);
    delete section.dataset.dropPosition;

    if (!draggedGroupName || !targetGroupName || draggedGroupName === targetGroupName) {
      clearDragState();
      return;
    }

    handlers.onMoveGroup(draggedGroupName, targetGroupName, insertAfterTarget);
    activeDragOperation = null;
    clearDragState();
  });
}

function canDropOnSection(itemType, groupName) {
  return (
    activeDragOperation?.mode === "group" &&
    activeDragOperation?.itemType === itemType &&
    activeDragOperation?.groupName !== groupName
  );
}

function shouldInsertAfter(event, card) {
  const { top, height } = card.getBoundingClientRect();
  return event.clientY > top + height / 2;
}

function clearDragState() {
  document.querySelectorAll(".drag-active").forEach((element) => {
    element.classList.remove("drag-active");
    delete element.dataset.dragHover;
  });

  document.querySelectorAll(".drag-source").forEach((element) => {
    element.classList.remove("drag-source");
  });

  document.querySelectorAll('[data-drop-position="before"], [data-drop-position="after"]').forEach((element) => {
    delete element.dataset.dropPosition;
  });
}

function reorderItemsWithinGroup(items, groupName, draggedItemId, targetItemId, insertAfterTarget) {
  const matchingGroupName = String(groupName || "").trim();
  const groupItems = items.filter((item) => normalizeGroupName(item.group) === matchingGroupName);
  const draggedItem = groupItems.find((item) => item.id === draggedItemId);
  const targetItem = groupItems.find((item) => item.id === targetItemId);

  if (!draggedItem || !targetItem) {
    return items;
  }

  const reorderedGroupItems = groupItems.filter((item) => item.id !== draggedItemId);
  const targetIndex = reorderedGroupItems.findIndex((item) => item.id === targetItemId);
  const insertionIndex = insertAfterTarget ? targetIndex + 1 : targetIndex;

  reorderedGroupItems.splice(insertionIndex, 0, draggedItem);

  // Es wird nur die Reihenfolge innerhalb derselben Gruppe ersetzt.
  // Alle anderen Gruppen behalten ihre Position unveraendert bei.
  let reorderedItemIndex = 0;
  return items.map((item) => {
    if (normalizeGroupName(item.group) !== matchingGroupName) {
      return item;
    }

    const reorderedItem = reorderedGroupItems[reorderedItemIndex];
    reorderedItemIndex += 1;
    return reorderedItem;
  });
}

function reorderGroups(items, draggedGroupName, targetGroupName, insertAfterTarget) {
  const normalizedDraggedGroupName = normalizeGroupName(draggedGroupName);
  const normalizedTargetGroupName = normalizeGroupName(targetGroupName);

  if (normalizedDraggedGroupName === normalizedTargetGroupName) {
    return items;
  }

  const groupedItems = buildGroups(items);
  const draggedGroup = groupedItems.find((group) => group.groupName === normalizedDraggedGroupName);
  if (!draggedGroup) {
    return items;
  }

  const reorderedGroups = groupedItems.filter((group) => group.groupName !== normalizedDraggedGroupName);
  const targetGroupIndex = reorderedGroups.findIndex(
    (group) => group.groupName === normalizedTargetGroupName
  );

  if (targetGroupIndex === -1) {
    return items;
  }

  const insertionIndex = insertAfterTarget ? targetGroupIndex + 1 : targetGroupIndex;
  reorderedGroups.splice(insertionIndex, 0, draggedGroup);

  return reorderedGroups.flatMap((group) => group.items);
}

function removeGroupItems(itemType, groupName) {
  const normalizedGroupName = normalizeGroupName(groupName);
  const shouldDeleteGroup = window.confirm(
    `Soll die Gruppe "${normalizedGroupName}" mit allen Eintraegen wirklich entfernt werden?`
  );

  if (!shouldDeleteGroup) {
    return;
  }

  if (itemType === "status") {
    state.statusItems = state.statusItems.filter(
      (item) => normalizeGroupName(item.group) !== normalizedGroupName
    );
    saveAll();
    renderStatusItems();
    syncTopicSubscriptions();
    scheduleLoggingConfigurationSync();
    return;
  }

  state.commandItems = state.commandItems.filter(
    (item) => normalizeGroupName(item.group) !== normalizedGroupName
  );
  saveAll();
  renderCommandItems();
}

function normalizeGroupName(groupName) {
  return String(groupName || "").trim() || "Ohne Gruppe";
}

function isGroupCollapsed(groupType, groupName) {
  const normalizedGroupName = normalizeGroupName(groupName);
  const groupState = groupType === "status"
    ? state.appSettings.collapsedStatusGroups
    : state.appSettings.collapsedCommandGroups;

  return groupState?.[normalizedGroupName] === true;
}

function setGroupCollapsedState(groupType, groupName, collapsed) {
  const normalizedGroupName = normalizeGroupName(groupName);
  const stateKey = groupType === "status"
    ? "collapsedStatusGroups"
    : "collapsedCommandGroups";
  const currentGroupState = {
    ...(state.appSettings[stateKey] || {})
  };

  currentGroupState[normalizedGroupName] = collapsed === true;
  state.appSettings[stateKey] = currentGroupState;
}

function captureActiveInputState(container) {
  const activeElement = document.activeElement;

  if (!(activeElement instanceof HTMLInputElement) || !container.contains(activeElement)) {
    return null;
  }

  const parentCard = activeElement.closest(".config-card");

  if (!(parentCard instanceof HTMLElement)) {
    return null;
  }

  return {
    itemId: parentCard.dataset.itemId || "",
    field: activeElement.dataset.field || "",
    currentValue: activeElement.value,
    selectionStart: activeElement.selectionStart,
    selectionEnd: activeElement.selectionEnd
  };
}

function restoreActiveInputState(container, activeInputState) {
  if (!activeInputState?.itemId || !activeInputState.field) {
    return;
  }

  const inputToFocus = container.querySelector(
    `.config-card[data-item-id="${activeInputState.itemId}"] input[data-field="${activeInputState.field}"]`
  );

  if (!(inputToFocus instanceof HTMLInputElement)) {
    return;
  }

  if (typeof activeInputState.currentValue === "string") {
    // Nicht bestaetigte Eingaben sollen bei Live-Updates sichtbar bleiben,
    // damit der Nutzer Zahlenwerte in Ruhe fertig eingeben kann.
    inputToFocus.value = activeInputState.currentValue;
  }

  // Der Fokus wird nach dem Neuzeichnen sofort wieder auf dasselbe
  // Eingabefeld gesetzt, damit Live-Daten das Tippen nicht stoeren.
  inputToFocus.focus();

  if (
    typeof activeInputState.selectionStart === "number" &&
    typeof activeInputState.selectionEnd === "number"
  ) {
    inputToFocus.setSelectionRange(
      activeInputState.selectionStart,
      activeInputState.selectionEnd
    );
  }
}

function handleToggleThemeMenu() {
  const nextExpanded = elements.themeMenu.hidden;
  elements.themeMenu.hidden = !nextExpanded;
  elements.themeMenuButton.setAttribute("aria-expanded", nextExpanded ? "true" : "false");
}

function closeThemeMenu() {
  elements.themeMenu.hidden = true;
  elements.themeMenuButton.setAttribute("aria-expanded", "false");
}

function handleDocumentClick(event) {
  if (!(event.target instanceof Node)) {
    return;
  }

  if (
    elements.themeMenu.hidden === false &&
    !elements.themeMenu.contains(event.target) &&
    !elements.themeMenuButton.contains(event.target)
  ) {
    closeThemeMenu();
  }
}

function handleDocumentKeydown(event) {
  if (event.key === "Escape") {
    closeThemeMenu();
  }
}

function startHardwareMonitor() {
  updateHardwareMonitor();

  if (hardwareMonitorTimer !== null) {
    window.clearInterval(hardwareMonitorTimer);
  }

  hardwareMonitorTimer = window.setInterval(updateHardwareMonitor, 5000);
}

async function updateHardwareMonitor() {
  const monitorEntries = buildBrowserMonitorEntries();

  try {
    const response = await fetch(buildApiPath("/api/system"), { cache: "no-store" });

    if (response.ok) {
      const payload = await response.json();
      monitorEntries.push(
        { label: "Server Prozessspeicher", value: formatOptionalMetric(payload.processMemoryMb, "MB") },
        { label: "Server CPU", value: formatOptionalMetric(payload.processCpuPercent, "%") },
        { label: "Aktive MQTT-Sitzungen", value: String(payload.activeInstances ?? "-") },
        { label: "Server Uptime", value: payload.uptimeText || "-" },
        { label: "Letzte Messung", value: payload.measuredAt || "-" }
      );
    }
  } catch (error) {
    monitorEntries.push({
      label: "Server Monitoring",
      value: "Nicht erreichbar"
    });
  }

  renderHardwareMonitor(monitorEntries);
}

function buildBrowserMonitorEntries() {
  const entries = [];
  const performanceMemory = window.performance?.memory;

  entries.push({
    label: "Browser Sitzung",
    value: resolveInstanceLabel()
  });

  if (performanceMemory) {
    entries.push(
      {
        label: "Browser Heap genutzt",
        value: `${formatMegabytes(performanceMemory.usedJSHeapSize)} MB`
      },
      {
        label: "Browser Heap Limit",
        value: `${formatMegabytes(performanceMemory.jsHeapSizeLimit)} MB`
      }
    );
  } else {
    entries.push({
      label: "Browser Heap",
      value: "Vom Browser nicht bereitgestellt"
    });
  }

  entries.push({
    label: "Historienwerte gesamt",
    value: String(state.statusItems.reduce(
      (sum, item) => sum + (Array.isArray(item.historyValues) ? item.historyValues.length : 0),
      0
    ))
  });

  entries.push({
    label: "Statuskarten mit Historie",
    value: String(state.statusItems.filter((item) => item.showHistory === true).length)
  });

  return entries;
}

function renderHardwareMonitor(entries) {
  elements.monitorGrid.textContent = "";
  const fragment = document.createDocumentFragment();

  entries.forEach((entry) => {
    const rowFragment = elements.monitorRowTemplate.content.cloneNode(true);
    rowFragment.querySelector('[data-role="monitor-label"]').textContent = entry.label;
    rowFragment.querySelector('[data-role="monitor-value"]').textContent = entry.value;
    fragment.append(rowFragment);
  });

  elements.monitorGrid.append(fragment);
}

function resolveInstanceLabel() {
  return window.sessionStorage.getItem("mqtt-webinterface-instance-id") || "-";
}

function formatMegabytes(bytes) {
  return (bytes / (1024 * 1024)).toFixed(2);
}

function formatOptionalMetric(value, unit) {
  if (typeof value !== "number" || Number.isNaN(value)) {
    return "Nicht verfuegbar";
  }

  return `${value} ${unit}`;
}

function shouldDisplayDebugMessage(message) {
  const normalizedMessage = String(message || "");

  if (normalizedMessage.startsWith("PINGRESP")) {
    return false;
  }

  if (normalizedMessage.startsWith("Subscription bestaetigt")) {
    return state.statusItems.some((item) => item.logEnabled === true);
  }

  if (normalizedMessage.startsWith("Topic abonniert")) {
    return state.statusItems.some((item) => item.logEnabled === true);
  }

  if (normalizedMessage.startsWith("Publish an")) {
    return state.commandItems.some((item) => item.logEnabled === true);
  }

  return true;
}

function buildApiPath(path) {
  if (window.location.protocol === "file:") {
    return `http://127.0.0.1:8080${path}`;
  }

  return path;
}
