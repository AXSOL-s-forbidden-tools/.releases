# Architektur

## Uebersicht

```mermaid
flowchart TD
  A[Browser] --> B[web/index.html]
  B --> C[web/app.js]
  C --> D[web/functions/storage.js]
  C --> E[web/functions/ui.js]
  C --> F[web/functions/mqtt-client.js]
  F --> S[backend/server.py]
  S --> H[backend/functions/mqtt_backend.py]
  S --> M[backend/functions/system_monitor.py]
  H --> G[MQTT Broker ueber TCP]
```

## Datenfluss

```mermaid
sequenceDiagram
  participant U as Benutzer
  participant UI as Webinterface
  participant API as Lokaler Python-Server
  participant MQ as MQTT Broker

  U->>UI: Verbindungsdaten eingeben
  UI->>API: Connect-Anfrage senden
  API->>MQ: TCP-MQTT-Verbindung aufbauen
  U->>UI: Statuswert mit Topic und Key anlegen
  UI->>API: Topic-Liste senden
  API->>MQ: Topic abonnieren
  MQ-->>API: JSON-Payload senden
  API-->>UI: Ereignisse und Nutzdaten liefern
  UI->>UI: Key aus Payload lesen und Wert anzeigen
  U->>UI: Befehlsbutton druecken
  UI->>API: Publish-Anfrage senden
  API->>MQ: JSON-Payload mit Key und Wert senden
```

## Module
- `web/app.js` steuert den Ablauf der Anwendung.
- `web/functions/storage.js` kuemmert sich um das Laden und Speichern der Konfiguration im Browser.
- `web/functions/mqtt-client.js` kapselt die Kommunikation vom Browser zur lokalen API.
- `backend/server.py` liefert die statischen Dateien aus und stellt die HTTP-Endpunkte bereit.
- `backend/functions/mqtt_backend.py` erzeugt und liest die benoetigten MQTT-Pakete ueber einen TCP-Socket.
- `backend/functions/system_monitor.py` liefert einfache Laufzeitwerte fuer den Hardware-Monitor der Weboberflaeche.
- `web/functions/ui.js` enthaelt kleine UI-Bausteine fuer Karten, Statusanzeige und Protokoll.
- `web/app.js` ordnet Gruppen, Kachel-Layout und Drag&Drop innerhalb derselben Gruppe.

## Konfigurationsdaten
- Brokerdaten, Statusfelder und Befehlsdefinitionen werden lokal im Browser gehalten.
- Vollstaendige Konfigurationen koennen unter einem frei waehlenbaren Namen im Browser gespeichert und spaeter wieder geladen werden.
- Dieselbe Konfiguration kann ausserdem als JSON-Datei exportiert und spaeter wieder in eine laufende Sitzung importiert werden.
- Pro Status- und Befehlskarte wird auch gespeichert, ob die Konfiguration sichtbar oder eingeklappt ist.
- Pro Status- und Befehlskarte werden ausserdem Gruppenname und Konfigurationsname mitgespeichert.
- Pro Status- und Befehlskarte wird ebenfalls gespeichert, ob Topic-bezogenes Logging aktiv ist.
- Der Ein-/Ausklappzustand kompletter Status- und Befehlsgruppen wird ebenfalls lokal gespeichert.
- Historiengrafen fuer Statuswerte beziehen sich nur auf Live-Daten der aktuellen Sitzung und werden absichtlich nicht gespeichert.
- Aeltere Konfigurationen ohne Historien-Feld werden beim Import automatisch mit deaktivierter Historie migriert.

## Monitoring und Theme
- Das Burger-Menue in der Kopfzeile schaltet zwischen hellem und dunklem Erscheinungsbild um.
- Der separate Hardware-Monitor zeigt Browser- und Server-Laufzeitwerte getrennt in Kacheln an.
- Monitoring-Daten sind reine Laufzeitinformationen und werden nicht in Konfigurationsdateien oder Browser-Profilen gesammelt.

## Parallele Instanzen
- Der lokale Python-Server verwaltet mehrere getrennte MQTT-Sitzungen parallel.
- Jede Browser-Instanz verwendet dafuer eine eigene Sitzungs-ID.
- Dieselbe Sitzungs-ID trennt auch die lokale Arbeitskonfiguration pro Instanz.
- Gespeicherte benannte Konfigurationen koennen dagegen browserweit von allen Instanzen geladen werden.

## Hinweis zum Start
- Die UI kann ueber `http://127.0.0.1:<dein-port>`, `http://localhost:<dein-port>` oder direkt per `file://` geoeffnet werden.
- Beim Start ueber `startWebserver.bat` kann der Port fuer die Weboberflaeche frei gewaehlt werden. Ohne Eingabe bleibt es bei `8080`.
- In beiden Faellen muss der lokale Python-Server laufen, weil darueber die MQTT-TCP-Verbindung stattfindet.
