import json
import socket
import threading
import time
from dataclasses import dataclass

from functions.logging_backend import CsvLoggingSession


@dataclass
class MqttConnectionConfig:
    host: str
    port: int
    username: str = ""
    password: str = ""
    client_id: str = ""


class MqttBackend:
    def __init__(self):
        self._lock = threading.Lock()
        self._socket = None
        self._reader_thread = None
        self._ping_thread = None
        self._connected = False
        self._running = False
        self._subscriptions = set()
        self._events = []
        self._next_event_id = 1
        self._packet_identifier = 1
        self._current_config = None
        self._connection_id = 0
        self._logging_session = CsvLoggingSession()

    def connect(self, config: MqttConnectionConfig):
        self.disconnect()

        if not config.client_id:
            config.client_id = f"mqtt-webinterface-{int(time.time() * 1000)}"

        self._current_config = config
        self._running = True
        self._publish_event("debug", f"TCP-Verbindung zu {config.host}:{config.port} wird aufgebaut.")

        try:
            mqtt_socket = socket.create_connection((config.host, config.port), timeout=5)
        except OSError as error:
            self._running = False
            self._publish_event("error", f"Broker nicht erreichbar: {error}")
            raise

        mqtt_socket.settimeout(1.0)

        with self._lock:
            self._connection_id += 1
            connection_id = self._connection_id
            self._socket = mqtt_socket

        self._send_packet(_build_connect_packet(config))
        self._reader_thread = threading.Thread(target=self._reader_loop, args=(connection_id,), daemon=True)
        self._reader_thread.start()
        return {"connected": False, "message": "Verbindungsaufbau gestartet."}

    def disconnect(self):
        self._running = False
        self._connected = False
        self._logging_session.handle_connection_closed()

        with self._lock:
            mqtt_socket = self._socket
            self._socket = None
            self._connection_id += 1

        if mqtt_socket is not None:
            try:
                mqtt_socket.sendall(_build_disconnect_packet())
            except OSError:
                pass

            try:
                mqtt_socket.close()
            except OSError:
                pass

        self._subscriptions = set()

    def publish(self, topic: str, payload: str):
        if not self._connected:
            raise RuntimeError("Keine aktive MQTT-Verbindung.")

        self._send_packet(_build_publish_packet(topic, payload))
        self._publish_event("debug", f"Publish an {topic} gesendet.")

    def sync_subscriptions(self, topics):
        cleaned_topics = {topic.strip() for topic in topics if topic and topic.strip()}

        if not self._connected:
            self._subscriptions = cleaned_topics
            return

        new_topics = cleaned_topics - self._subscriptions

        for topic in sorted(new_topics):
            self._send_packet(_build_subscribe_packet(self._next_packet_identifier(), topic))
            self._publish_event("debug", f"Topic abonniert: {topic}")

        self._subscriptions = cleaned_topics

    def get_events(self, after_event_id: int):
        with self._lock:
            events = [event for event in self._events if event["id"] > after_event_id]
            connected = self._connected

        return {
            "connected": connected,
            "events": events
        }

    def start_logging(self, output_dir: str, status_items):
        if not self._connected:
            raise RuntimeError("Logging kann erst nach einer Broker-Verbindung gestartet werden.")

        return self._logging_session.start(output_dir, status_items)

    def stop_logging(self):
        return self._logging_session.stop()

    def get_logging_status(self):
        status = self._logging_session.get_status()
        status["connected"] = self._connected
        return status

    def is_alive(self):
        with self._lock:
            return self._running or self._connected or self._socket is not None

    def _reader_loop(self, connection_id: int):
        buffer = bytearray()
        connack_received = False

        while self._running:
            if not self._is_current_connection(connection_id):
                return

            mqtt_socket = self._socket

            if mqtt_socket is None:
                return

            try:
                chunk = mqtt_socket.recv(4096)
            except socket.timeout:
                continue
            except OSError as error:
                if not self._is_current_connection(connection_id):
                    return
                self._handle_disconnect(f"Socket-Fehler: {error}")
                return

            if not chunk:
                if not self._is_current_connection(connection_id):
                    return
                self._handle_disconnect("Broker hat die Verbindung geschlossen.")
                return

            buffer.extend(chunk)

            while True:
                packet = _decode_packet(buffer)

                if packet is None:
                    break

                packet_type, packet_payload, consumed_length = packet
                del buffer[:consumed_length]

                if packet_type == "connack":
                    return_code = packet_payload["return_code"]

                    if return_code != 0:
                        self._publish_event("error", f"MQTT-Verbindung abgelehnt. Rueckgabecode: {return_code}")
                        self.disconnect()
                        return

                    if not connack_received:
                        connack_received = True
                        with self._lock:
                            self._connected = True
                        self._publish_event("connected", "Verbindung zum Broker hergestellt.")
                        self._restart_ping_loop(connection_id)

                        if self._subscriptions:
                            self.sync_subscriptions(self._subscriptions)

                elif packet_type == "publish":
                    self._logging_session.handle_message(
                        packet_payload["topic"],
                        packet_payload["payload"],
                    )
                    self._publish_event(
                        "message",
                        f"Nachricht auf {packet_payload['topic']} empfangen.",
                        topic=packet_payload["topic"],
                        payload=packet_payload["payload"],
                    )
                elif packet_type == "suback":
                    self._publish_event("debug", f"Subscription bestaetigt. Paket-ID: {packet_payload['packet_identifier']}")
                elif packet_type == "pingresp":
                    self._publish_event("debug", "PINGRESP empfangen.")

    def _restart_ping_loop(self, connection_id: int):
        self._ping_thread = threading.Thread(target=self._ping_loop, args=(connection_id,), daemon=True)
        self._ping_thread.start()

    def _ping_loop(self, connection_id: int):
        while self._running:
            time.sleep(20)

            if not self._running or not self._connected or not self._is_current_connection(connection_id):
                return

            try:
                self._send_packet(_build_ping_request_packet())
            except OSError as error:
                if not self._is_current_connection(connection_id):
                    return
                self._handle_disconnect(f"Ping fehlgeschlagen: {error}")
                return

    def _handle_disconnect(self, message: str):
        was_connected = self._connected
        self.disconnect()

        if was_connected:
            self._publish_event("disconnected", message)
        else:
            self._publish_event("error", message)

    def _send_packet(self, packet: bytes):
        with self._lock:
            mqtt_socket = self._socket

        if mqtt_socket is None:
            raise RuntimeError("Keine Socket-Verbindung vorhanden.")

        mqtt_socket.sendall(packet)

    def _publish_event(self, event_type: str, message: str, topic: str = "", payload: str = ""):
        with self._lock:
            event = {
                "id": self._next_event_id,
                "type": event_type,
                "message": message,
                "topic": topic,
                "payload": payload,
            }
            self._next_event_id += 1
            self._events.append(event)
            self._events = self._events[-500:]

    def _next_packet_identifier(self):
        with self._lock:
            self._packet_identifier += 1

            if self._packet_identifier > 65535:
                self._packet_identifier = 1

            return self._packet_identifier

    def _is_current_connection(self, connection_id: int):
        with self._lock:
            return connection_id == self._connection_id


def _build_connect_packet(config: MqttConnectionConfig) -> bytes:
    variable_header = _encode_string("MQTT") + bytes([4, _build_connect_flags(config), 0, 30])
    payload = _encode_string(config.client_id)

    if config.username:
        payload += _encode_string(config.username)

    if config.password:
        payload += _encode_string(config.password)

    return _wrap_packet(0x10, variable_header + payload)


def _build_subscribe_packet(packet_identifier: int, topic: str) -> bytes:
    return _wrap_packet(0x82, _encode_uint16(packet_identifier) + _encode_string(topic) + bytes([0]))


def _build_publish_packet(topic: str, payload: str) -> bytes:
    return _wrap_packet(0x30, _encode_string(topic) + payload.encode("utf-8"))


def _build_ping_request_packet() -> bytes:
    return bytes([0xC0, 0x00])


def _build_disconnect_packet() -> bytes:
    return bytes([0xE0, 0x00])


def _build_connect_flags(config: MqttConnectionConfig) -> int:
    flags = 0b00000010

    if config.username:
        flags |= 0b10000000

    if config.password:
        flags |= 0b01000000

    return flags


def _wrap_packet(header: int, body: bytes) -> bytes:
    return bytes([header]) + _encode_remaining_length(len(body)) + body


def _encode_string(value: str) -> bytes:
    encoded = value.encode("utf-8")
    return _encode_uint16(len(encoded)) + encoded


def _encode_uint16(value: int) -> bytes:
    return bytes([(value >> 8) & 0xFF, value & 0xFF])


def _encode_remaining_length(length: int) -> bytes:
    result = bytearray()
    remaining = length

    while True:
        encoded_byte = remaining % 128
        remaining //= 128

        if remaining > 0:
            encoded_byte |= 0x80

        result.append(encoded_byte)

        if remaining == 0:
            break

    return bytes(result)


def _decode_packet(buffer: bytearray):
    if len(buffer) < 2:
        return None

    remaining_length_info = _decode_remaining_length(buffer, 1)

    if remaining_length_info is None:
        return None

    remaining_length, remaining_length_bytes = remaining_length_info
    packet_length = 1 + remaining_length_bytes + remaining_length

    if len(buffer) < packet_length:
        return None

    packet_type = buffer[0] >> 4
    payload_start = 1 + remaining_length_bytes
    payload = bytes(buffer[payload_start:packet_length])

    if packet_type == 2:
        return "connack", {"return_code": payload[1]}, packet_length

    if packet_type == 3:
        topic_length = _decode_uint16(payload, 0)
        topic = payload[2:2 + topic_length].decode("utf-8")
        message = payload[2 + topic_length:].decode("utf-8")
        return "publish", {"topic": topic, "payload": message}, packet_length

    if packet_type == 9:
        return "suback", {"packet_identifier": _decode_uint16(payload, 0)}, packet_length

    if packet_type == 13:
        return "pingresp", {}, packet_length

    return "ignored", {}, packet_length


def _decode_remaining_length(buffer: bytearray, offset: int):
    multiplier = 1
    value = 0
    index = offset

    while index < len(buffer):
        encoded_byte = buffer[index]
        value += (encoded_byte & 127) * multiplier

        if (encoded_byte & 128) == 0:
            return value, (index - offset + 1)

        multiplier *= 128
        index += 1

    return None


def _decode_uint16(buffer: bytes, offset: int):
    return (buffer[offset] << 8) | buffer[offset + 1]
