# Wichtige Ablaeufe

Dieser Ordner ist fuer spaetere Ablaufbeschreibungen vorgesehen, zum Beispiel fuer Verbindungsaufbau, Statusverarbeitung oder Sendeablaeufe.
