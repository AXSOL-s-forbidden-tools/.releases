# Architekturentscheidungen

Dieser Ordner ist fuer spaetere ADRs vorgesehen, falls wesentliche technische Entscheidungen dokumentiert werden sollen.
