import { resolveInstanceId } from "./instance.js";

export function createMqttClient(callbacks) {
  let pollingTimer = null;
  let lastEventId = 0;
  let connected = false;
  const apiBaseUrl = resolveApiBaseUrl();
  const instanceId = resolveInstanceId();

  startPolling();

  return {
    async connect(connection) {
      try {
        const response = await sendJson("/api/connect", {
          instanceId,
          host: connection.host,
          port: connection.port,
          username: connection.username,
          password: connection.password
        }, apiBaseUrl);

        connected = response.connected === true;
        callbacks.onDebug(response.message || "Verbindung wird aufgebaut.");
      } catch (error) {
        callbacks.onError(`Verbindung konnte nicht gestartet werden: ${error.message}`);
      }
    },

    async disconnect() {
      try {
        await sendJson("/api/disconnect", { instanceId }, apiBaseUrl);
      } catch (error) {
        callbacks.onError(`Trennen fehlgeschlagen: ${error.message}`);
      }
    },

    isConnected() {
      return connected;
    },

    async publish(topic, payloadText) {
      try {
        await sendJson("/api/publish", {
          instanceId,
          topic,
          payload: payloadText
        }, apiBaseUrl);
      } catch (error) {
        callbacks.onError(`Senden fehlgeschlagen: ${error.message}`);
      }
    },

    async syncSubscriptions(topics) {
      try {
        await sendJson("/api/subscriptions", {
          instanceId,
          topics
        }, apiBaseUrl);
      } catch (error) {
        callbacks.onError(`Topics konnten nicht aktualisiert werden: ${error.message}`);
      }
    }
  };

  function startPolling() {
    stopPolling();
    pollingTimer = window.setInterval(async () => {
      try {
        const response = await fetch(
          buildApiUrl(
            `/api/events?instanceId=${encodeURIComponent(instanceId)}&after=${lastEventId}`,
            apiBaseUrl
          ),
          {
            cache: "no-store"
          }
        );

        if (!response.ok) {
          return;
        }

        const payload = await response.json();
        connected = payload.connected === true;
        payload.events.forEach(processEvent);
      } catch (error) {
        callbacks.onError(`Backend nicht erreichbar: ${error.message}`);
      }
    }, 1000);
  }

  function stopPolling() {
    if (pollingTimer !== null) {
      window.clearInterval(pollingTimer);
      pollingTimer = null;
    }
  }

  function processEvent(event) {
    lastEventId = Math.max(lastEventId, Number(event.id) || 0);

    if (event.type === "connected") {
      connected = true;
      callbacks.onConnected();
      return;
    }

    if (event.type === "disconnected") {
      connected = false;
      callbacks.onConnectionLost(event.message || "Verbindung getrennt");
      return;
    }

    if (event.type === "error") {
      callbacks.onError(event.message || "Unbekannter Fehler");
      return;
    }

    if (event.type === "debug") {
      callbacks.onDebug(event.message || "");
      return;
    }

    if (event.type === "message") {
      callbacks.onMessageArrived(event.topic || "", event.payload || "");
    }
  }
}

function resolveApiBaseUrl() {
  if (window.location.protocol === "file:") {
    return "http://127.0.0.1:8080";
  }

  return window.location.origin;
}

function buildApiUrl(path, apiBaseUrl) {
  return `${apiBaseUrl}${path}`;
}

async function sendJson(url, body, apiBaseUrl) {
  const response = await fetch(buildApiUrl(url, apiBaseUrl), {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });

  const payload = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(payload.error || `HTTP ${response.status}`);
  }

  return payload;
}
