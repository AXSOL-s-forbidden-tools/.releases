# Beispiel fuer die Import-Ordnerstruktur

Diese Struktur zeigt, wie ein oberster Import-Ordner fuer Statuswert-Vorlagen aufgebaut sein soll.

```text
import-root/
  inverter/
    mqttWebImport.json
    values/
      SysCurrent.json
      SysVoltage.json
      SysTemp.json
    child/
      CellVoltage.json
      CellTemp.json

  battery/
    mqttWebImport.json
    values/
      BatteryCurrent.json
      BatteryVoltage.json
    child/
      CellVoltage.json
      CellBalance.json
```

## Bedeutung der Struktur

- `import-root/`
  - Diesen obersten Ordner waehlst du im Webinterface beim Vorlagenimport aus.
- `mqttWebImport.json`
  - Enthalten die Basisdaten der jeweiligen Komponente.
  - Wichtig sind vor allem:
    - `mqttTopic`
    - optional `childSubtopic`, wenn ein `child/`-Ordner genutzt wird
    - optional `parentDescription` und `childDescription` fuer die Bereichsnamen in der Auswahlliste
- `values/`
  - Enthalten die Vorlagen fuer `Parent`-Statuswerte.
  - Daraus entstehen Topics im Schema:
    - `$mqttTopic/1`
    - `$mqttTopic/1/1`
    - `$mqttTopic/1/2`
    - `$mqttTopic/2`
    - `$mqttTopic/2/1`
    - ...
    - `$mqttTopic/999`
- `child/`
  - Enthalten die Vorlagen fuer `Child`-Statuswerte.
  - Daraus entstehen Topics im Schema:
    - `$mqttTopic/1/$childSubtopic/1`
    - `$mqttTopic/1/$childSubtopic/2`
    - `$mqttTopic/2/$childSubtopic/1`
    - `$mqttTopic/3/$childSubtopic/1`

## Wichtige Regeln

- Jede Wertedatei muss gueltiges JSON sein.
- Der Key `mqttName` beschreibt den Payload-Key auf dem Broker.
- Ist `mqttName` leer, wird die Datei beim Import automatisch ignoriert.
- Der Key `mqttUnit` wird, wenn vorhanden, spaeter direkt in der Statusanzeige angezeigt.
- Im `child/`-Ordner duerfen nur Werte liegen, wenn in `mqttWebImport.json` auch `childSubtopic` gesetzt ist.
- Fuer `childDescription` und `parentDescription` akzeptiert das Projekt aktuell dieselbe Schreibweise wie in deinen gelieferten Beispielen innerhalb von `child` und `parent`.

## Kleines Beispiel

Angenommen in `mqttWebImport.json` steht:

```json
{
  "mqttTopic": "TRLY2501/Node/1/Container",
  "parentDescription": "Container",
  "childSubtopic": "unit",
  "childDescription": "Rack"
}
```

Dann gilt:

- eine Datei in `values/` fuer `mqttName = "ME_I_Tot"` passt z. B. zu:
  - `TRLY2501/Node/1/Container/1`
  - `TRLY2501/Node/1/Container/1/1`
  - `TRLY2501/Node/1/Container/1/2`
  - und wird im Webinterface trotzdem nur als `Container 1` angezeigt
- eine Datei in `child/` fuer `mqttName = "ME_V_Cell"` passt z. B. zu:
  - `TRLY2501/Node/1/Container/1/unit/1`
  - `TRLY2501/Node/1/Container/1/unit/2`
  - `TRLY2501/Node/1/Container/2/unit/1`

Im Webinterface wird dann bei Parent z. B. `Container 2` angezeigt. Bei Child wird die Kombination angezeigt, z. B. `Container 2 / Rack 1`, damit gleich benannte Child-Nummern unter verschiedenen Parents sauber unterscheidbar bleiben. Beim eigentlichen Anlegen eines Statuswerts wird trotzdem der konkret erkannte Broker-Topic fuer den gewaehlten `mqttName` uebernommen.
