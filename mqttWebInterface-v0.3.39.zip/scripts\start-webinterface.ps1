# Python startet hier den lokalen HTTP-Server und gleichzeitig die
# MQTT-TCP-Bruecke fuer den Browser.
param(
    [int]$Port = 8080
)

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $scriptRoot
Set-Location -LiteralPath $projectRoot

if ($Port -lt 1 -or $Port -gt 65535) {
    Write-Host "Der Port muss zwischen 1 und 65535 liegen."
    exit 1
}

Write-Host "Webinterface laeuft unter http://localhost:$Port/"
Write-Host "Webinterface laeuft unter http://127.0.0.1:$Port/"
Write-Host "Beenden mit Strg+C"

python .\backend\server.py --port $Port
