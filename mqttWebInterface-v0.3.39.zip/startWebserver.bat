@echo off
setlocal
cd /d "%~dp0"
set "WEB_PORT="
set /p WEB_PORT=Port fuer Webserver [8080]: 

if "%WEB_PORT%"=="" set "WEB_PORT=8080"

powershell -ExecutionPolicy Bypass -File ".\scripts\start-webinterface.ps1" -Port "%WEB_PORT%"
