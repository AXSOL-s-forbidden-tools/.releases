import csv
import json
import math
import re
import threading
import time
from pathlib import Path

CSV_DELIMITER = ";"


class CsvLoggingSession:
    def __init__(self):
        self._lock = threading.Lock()
        self._active = False
        self._status = "IDLE"
        self._output_dir = None
        self._targets = {}
        self._last_write_at = None
        self._last_error = ""

    def start(self, output_dir, status_items):
        normalized_output_dir_text = str(output_dir or "").strip()

        if not normalized_output_dir_text:
            raise ValueError("Der Ausgabepfad fuer die CSV-Dateien ist erforderlich.")

        normalized_output_dir = Path(normalized_output_dir_text).expanduser()

        normalized_items = _normalize_status_items(status_items)

        if not normalized_items:
            raise ValueError("Es ist mindestens ein gueltiger Statuswert mit Topic und Key erforderlich.")

        normalized_output_dir.mkdir(parents=True, exist_ok=True)
        targets = _build_targets(normalized_output_dir, normalized_items)

        for target in targets.values():
            _ensure_csv_file(target["file_path"])

        with self._lock:
            self._output_dir = normalized_output_dir
            self._targets = targets
            self._active = True
            self._status = "STARTED"
            self._last_error = ""

        return self.get_status()

    def stop(self):
        with self._lock:
            self._active = False
            self._status = "STOPPED"

        return self.get_status()

    def handle_connection_closed(self):
        with self._lock:
            if not self._active:
                return

            self._active = False
            self._status = "STOPPED"

    def handle_message(self, topic, payload_text):
        with self._lock:
            if not self._active:
                return

            targets = list(self._targets.values())

        try:
            payload = json.loads(payload_text)
        except json.JSONDecodeError:
            return

        if not isinstance(payload, dict):
            return

        timestamp_ms = _extract_timestamp_ms(payload)

        if timestamp_ms is None:
            timestamp_ms = int(time.time() * 1000)

        matching_targets = [
            target for target in targets if _mqtt_topic_matches_filter(target["topic"], topic)
        ]

        if not matching_targets:
            return

        try:
            for target, value in _iter_logged_values(payload, matching_targets):
                with target["file_path"].open("a", newline="", encoding="utf-8") as csv_file:
                    writer = csv.writer(csv_file, delimiter=CSV_DELIMITER)
                    writer.writerow([
                        timestamp_ms,
                        _format_timestamp_iso(timestamp_ms),
                        topic,
                        target["key"],
                        value,
                    ])
        except OSError as error:
            with self._lock:
                self._active = False
                self._status = "ERROR"
                self._last_error = str(error)
            return

        with self._lock:
            self._status = "RUN"
            self._last_write_at = timestamp_ms

    def get_status(self):
        with self._lock:
            output_dir_path = self._output_dir
            output_dir = str(output_dir_path) if output_dir_path is not None else ""
            file_count = len(self._targets)
            item_count = len(self._targets)
            last_write_at = self._last_write_at
            last_error = self._last_error
            active = self._active
            status = self._status

        total_size_bytes = _calculate_total_csv_size(output_dir_path)

        return {
            "active": active,
            "status": status,
            "outputDir": output_dir,
            "fileCount": file_count,
            "itemCount": item_count,
            "totalSizeBytes": total_size_bytes,
            "lastWriteAt": last_write_at,
            "lastError": last_error,
        }


def _normalize_status_items(status_items):
    normalized_items = []

    for raw_item in status_items or []:
        if not isinstance(raw_item, dict):
            continue

        item_id = str(raw_item.get("id", "")).strip()
        topic = str(raw_item.get("topic", "")).strip()
        key = str(raw_item.get("key", "")).strip()

        if not item_id or not topic or not key:
            continue

        normalized_items.append(
            {
                "id": item_id,
                "label": str(raw_item.get("label", "")).strip(),
                "group": str(raw_item.get("group", "")).strip(),
                "topic": topic,
                "key": key,
            }
        )

    return normalized_items


def _build_targets(output_dir, status_items):
    used_names = set()
    targets = {}

    for item in status_items:
        file_name = _build_csv_name(item, used_names)
        targets[item["id"]] = {
            "item_id": item["id"],
            "topic": item["topic"],
            "key": item["key"],
            "file_path": output_dir / file_name,
        }

    return targets


def _build_csv_name(item, used_names):
    raw_parts = [item["group"], item["label"], item["key"]]
    cleaned_parts = [_sanitize_path_part(part) for part in raw_parts if str(part or "").strip()]
    base_name = "__".join(cleaned_parts) or _sanitize_path_part(item["id"])
    candidate = f"{base_name}.csv"
    suffix = 2

    while candidate.lower() in used_names:
        candidate = f"{base_name}_{suffix}.csv"
        suffix += 1

    used_names.add(candidate.lower())
    return candidate


def _sanitize_path_part(value):
    normalized = re.sub(r"[^\w.-]+", "_", str(value or "").strip(), flags=re.ASCII)
    normalized = normalized.strip("._")
    return normalized or "status"


def _ensure_csv_file(file_path):
    if file_path.exists():
        return

    with file_path.open("w", newline="", encoding="utf-8") as csv_file:
        writer = csv.writer(csv_file, delimiter=CSV_DELIMITER)
        writer.writerow(["timestamp_ms", "timestamp_iso", "topic", "key", "value"])


def _extract_timestamp_ms(payload):
    if not isinstance(payload, dict):
        return None

    return _coerce_timestamp_ms(payload.get("ts"))


def _coerce_timestamp_ms(value):
    if value is None or isinstance(value, bool):
        return None

    if isinstance(value, int):
        return value

    if isinstance(value, float):
        if not math.isfinite(value):
            return None
        return int(value)

    if isinstance(value, str):
        stripped_value = value.strip()
        if not stripped_value:
            return None

        try:
            return int(stripped_value)
        except ValueError:
            try:
                float_value = float(stripped_value)
            except ValueError:
                return None

            if not math.isfinite(float_value):
                return None
            return int(float_value)

    return None


def _iter_logged_values(payload, matching_targets):
    if isinstance(payload, dict):
        direct_matches = [
            (target, payload[target["key"]])
            for target in matching_targets
            if target["key"] in payload
        ]

        if direct_matches:
            return direct_matches

    if len(matching_targets) == 1:
        # Single-value topics remain loggable even when the JSON shape does not expose the configured key.
        return [(matching_targets[0], _normalize_logged_value(payload))]

    return []


def _normalize_logged_value(value):
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))

    return value


def _format_timestamp_iso(timestamp_ms):
    timestamp_iso = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(timestamp_ms / 1000))
    milliseconds = timestamp_ms % 1000
    return f"{timestamp_iso}.{milliseconds:03d}Z"


def _mqtt_topic_matches_filter(topic_filter, topic):
    filter_levels = str(topic_filter or "").split("/")
    topic_levels = str(topic or "").split("/")

    for index, filter_level in enumerate(filter_levels):
        if filter_level == "#":
            return True

        if index >= len(topic_levels):
            return False

        if filter_level == "+":
            continue

        if filter_level != topic_levels[index]:
            return False

    return len(filter_levels) == len(topic_levels)


def _calculate_total_csv_size(output_dir):
    if output_dir is None or not output_dir.exists() or not output_dir.is_dir():
        return 0

    total_size_bytes = 0

    for csv_file in output_dir.glob("*.csv"):
        try:
            total_size_bytes += csv_file.stat().st_size
        except OSError:
            continue

    return total_size_bytes
