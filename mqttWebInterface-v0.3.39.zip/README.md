# MQTT Webinterface

A lightweight web interface that connects to an MQTT broker through a local Python bridge, shows freely configurable live status values, and sends freely configurable JSON commands.

![Example configuration](./media/screen1.png)

## Features
- Connect to an MQTT broker with host, port, username, and password
- Create status values manually from `topic` and `key`
- Create status values from imported component/value folders
- Ignore imported values with an empty `mqttName`
- Show imported `mqttUnit` values directly in the live display
- Discover matching parent and child entries automatically after connecting
- Batch live status refreshes so frequent MQTT updates do not overload the browser
- Optional line history for numeric status values with a configurable length up to `1000`
- Y-axis labels for minimum, midpoint, and maximum values
- History length is only applied after pressing `Enter`
- Optional manual Y-axis scaling for history charts after starting with auto-scaling
- Status and command card remove buttons are placed in the header next to the collapse button
- History charts use their own full row below the current live value
- Expanded status and command cards use tabs to switch between live view and settings
- Tab buttons keep a high-contrast appearance in dark mode, including the inactive tab
- Manual Y-axis controls use their own row in the settings grid so the history length field keeps a normal size
- Each status card can optionally refresh collapsed history either live or in a throttled mode
- Create command buttons from `topic`, `key`, and `value`
- Group status values and commands
- Save the working configuration automatically in the browser
- Save and load named configurations from browser storage
- Show the active configuration name in the header
- Import and export configurations as JSON files
- Delete saved browser configurations directly from the dropdown row
- Keep status values live-only and never persist their latest readings
- Show or hide the dedicated `Template Import` section from the burger menu
- Show or hide complete interface areas such as `CSV Logging`, `Statuswerte`, `Befehle`, `Ereignisse`, and `Hardware Monitor` from the burger menu
- Keep the global header with connection state and burger menu available even when the `Broker` area is hidden
- Group burger menu options into clear sections so theme switching stays under appearance and visibility toggles stay under area visibility
- Keep the burger menu above collapsed panels
- Log connection, receive, and send events
- Log configured status values as CSV files directly from the web interface
- CSV log files use a semicolon `;` as the field separator
- Configure the target directory for CSV log files in a dedicated collapsible logging area
- Open a native folder picker for the CSV log directory directly from the logging area
- Start and stop CSV logging with dedicated buttons
- Show the current logging state in the top header next to the broker connection state
- Show the current combined CSV size for the selected logging directory in the logging status line
- Keep the logging status line visible in collapsed mode while logging is active
- Enable detailed logging separately for each status value or command
- Switch between `light` and `dark` mode from the burger menu
- Show browser and server runtime metrics in a dedicated `Hardware Monitor` area
- Use a local MQTT TCP bridge for classic broker ports such as `1883`
- Keep text inputs stable even while live values are updating
- Collapse or expand the broker area, event log, hardware monitor, status cards, command cards, and whole groups
- Remove entire status or command groups including all assigned cards
- Reorder cards within the same group by drag and drop
- Reorder whole status groups and command groups by drag and drop
- Run multiple browser instances in parallel against the same local server
- Keep each browser instance workspace separate while sharing saved named configurations browser-wide

## Project structure
- `web/`: browser UI with HTML, CSS, and JavaScript
- `web/functions/`: frontend helpers for storage, UI, history, and API access
- `backend/`: local Python server
- `backend/functions/`: MQTT bridge, CSV logging, and system monitoring helpers
- `scripts/`: helper scripts for startup
- `startWebserver.bat`: single entry point for starting the web interface
- `docs/import-structure-example.md`: example folder structure for status template imports

## Setup
1. Make sure Python is available on the machine.
2. Start the web interface with `startWebserver.bat`.
3. At the prompt `Port fuer Webserver:`, either enter a custom port or press `Enter` to keep the default `8080`.
4. Open `http://127.0.0.1:<your-port>` or `http://localhost:<your-port>` in the browser.
5. Enter the MQTT broker host, port, username, and password.

## Usage
1. Connect to the broker.
2. Add one or more status values.
3. Enter the MQTT topic and JSON key that should be read from incoming payloads.
4. Alternatively, import a template folder and select a discovered parent or child entry plus a value.
5. After connecting, the interface automatically discovers matching entries for imported templates.
6. Once a matching entry is found, add the status value from the template with one click.
7. Optionally enable `Zeige Historie` for numeric values and enter the desired history length.
8. Press `Enter` in the history length field to apply the new value.
9. When history is enabled, the chart starts with automatic Y-axis scaling.
10. Open the `Einstellungen` tab and enable `Y-Achse manuell skalieren` if you want to define your own minimum and maximum.
11. Press `Enter` in the minimum and maximum fields in the settings tab to apply manual Y-axis limits.
12. Add one or more commands.
13. Enter topic, key, and value, then click the command button.
14. Open the `CSV Logging` area, either enter the local output directory manually or use `Ordner auswaehlen`, and then use `Start Logging` when the broker is connected.
15. Use `Stop Logging` to end CSV logging again.
16. Assign groups when needed.
17. Use the small arrow buttons to collapse or expand broker settings, CSV logging, events, hardware monitor, status cards, command cards, and complete groups.
18. Drag cards within the same group with the handle on the left.
19. Each status and command card shows its `Entfernen` button in the header directly next to the collapse button.
20. History charts are rendered on their own full row below the live value area.
21. Expanded status cards provide `Live` and `Einstellungen` tabs, with manual Y-axis scaling in the settings tab.
22. In the status settings tab you can choose whether collapsed history should refresh live or in a throttled mode.
23. Expanded command cards provide `Befehl` and `Einstellungen` tabs.
24. Drag group sections with the group handle in the group header.
25. Remove an entire expanded group with its `Entfernen` button.
26. Enter a name when saving a configuration.
27. Select a saved configuration from the dropdown and load it when needed.
28. Export the current working configuration as a JSON file with `Konfiguration exportieren`.
29. Import a JSON file into the current session with `Konfiguration importieren` without automatically saving it.
30. Delete the selected saved browser profile with the trash button next to the dropdown.
31. Switch between light and dark appearance from the burger menu.
32. Use the burger menu checkboxes to hide or show complete interface areas without deleting their configuration.

## Important notes
- The web interface expects JSON payloads.
- Status values are shown as live values only while the page is open.
- Template imports expect a top-level folder with component folders that contain `mqttWebImport.json`, `values/`, and optionally `child/`.
- Files with an empty `mqttName` are skipped on purpose because they cannot map to a broker value.
- Child templates expect `childSubtopic` inside the related `mqttWebImport.json`.
- Older imports using `component.json` are still accepted for backward compatibility.
- If available, `parentDescription` and `childDescription` from `mqttWebImport.json` are used as dropdown labels.
- Parent templates are internally mapped to MQTT filters such as `.../<parent-id>/#` so the main parent topic and its suffix topics can be evaluated together.
- Child templates expect the topic shape `.../<parent-id>/<subtopic>/<child-id>` and are shown in the dropdown as combined parent/child entries.
- When a status value is created from a template, the discovered broker topic for the selected `mqttName` is stored, even if the dropdown only shows the simplified entry label.
- Live values and histories stay in memory during the session and are not written back to browser storage on every MQTT message.
- History charts only show live data from the current session and are not persisted.
- CSV logging writes one file per configured status value and uses the payload field `ts` as the timestamp whenever it is present as an integer.
- CSV logging accepts `ts` as an integer, float, or numeric string.
- CSV logging uses `;` as the separator so the files open more reliably in spreadsheet tools with German regional settings.
- If the payload does not contain an integer `ts`, the local server time is used for the CSV timestamp instead.
- If a topic has exactly one configured status value and the incoming JSON does not expose the configured key directly, the full JSON value is stored in the CSV row instead of dropping the message.
- CSV logging uses the status values that are currently configured in the web interface and stores the selected output directory with the browser configuration.
- The logging status line also shows the current combined size of all CSV files in the selected output directory.
- When the logging panel is collapsed, the logging status line stays visible as long as logging is active.
- The folder picker opens as a native local dialog through the Python backend and returns the selected directory to the browser UI.
- Changes to history length and manual Y-axis limits are applied only after pressing `Enter`.
- The selected card tab is stored with the configuration so reopening the page returns to the same card view.
- The burger menu stores both the dedicated template import section visibility and the visibility of each main interface area in the active browser configuration.
- `Template Import` is rendered as its own panel and no longer appears inside the status section.
- The broker area is labeled with the visible title `Broker`.
- Older saved configurations from before the history feature still load correctly and start with history disabled.
- Older saved configurations from before manual Y-axis scaling still load correctly and start with auto-scaling enabled.
- The `Hardware Monitor` area is intended for current runtime visibility, not long-term recording.
- Receive and send log entries for individual status values or commands only appear when `Log` is enabled on the related card.
- If an incoming message is not valid JSON, the raw payload text is written to the event log.
- Integer values and floating-point values with `.` as decimal separator are automatically sent as numbers.
- Non-numeric inputs are sent as text.
- A normal browser cannot talk to a classic MQTT TCP port directly. That is why this project uses a local Python bridge process.
- `startWebserver.bat` starts both the local web server and the MQTT bridge backend.
- Stopping the server with `Ctrl+C` shuts it down cleanly. A `KeyboardInterrupt` is not a functional error.
- Closing the terminal window also triggers a controlled shutdown attempt for HTTP and MQTT resources.
- If `web/index.html` is opened directly with `file://`, the page automatically tries to reach the local backend at `http://127.0.0.1:8080`.
- The local server serves the start page directly from `http://127.0.0.1:<your-port>`.
- To work with multiple brokers or multiple configurations in parallel, open multiple browser windows or tabs and load a different saved configuration in each one as needed.
