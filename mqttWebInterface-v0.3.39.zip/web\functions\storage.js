import { resolveInstanceId } from "./instance.js";
import { createEmptyTemplateCatalog, normalizeTemplateCatalog } from "./template-catalog.js";
import { normalizeAxisValue } from "./history.js";

const SAVED_CONFIGS_STORAGE_KEY = "mqtt-webinterface-saved-configurations";

export function loadState() {
  // Die Konfiguration wird bewusst nur lokal im Browser gehalten,
  // damit kein zusaetzlicher Server fuer die Speicherung noetig ist.
  const rawValue = window.localStorage.getItem(resolveStorageKey());

  if (!rawValue) {
    return createDefaultState();
  }

  try {
    const parsedValue = JSON.parse(rawValue);

    return {
      connection: {
        ...createDefaultConnection(),
        ...parsedValue.connection
      },
      appSettings: {
        ...createDefaultAppSettings(),
        ...parsedValue.appSettings
      },
      templateCatalog: normalizeTemplateCatalog(parsedValue.templateCatalog),
      statusItems: Array.isArray(parsedValue.statusItems)
        ? parsedValue.statusItems.map(normalizeStatusItem)
        : [],
      commandItems: Array.isArray(parsedValue.commandItems)
        ? parsedValue.commandItems.map(normalizeCommandItem)
        : []
    };
  } catch (error) {
    return createDefaultState();
  }
}

export function saveState(state) {
  window.localStorage.setItem(resolveStorageKey(), JSON.stringify(createPersistedState(state)));
}

export function exportState(state) {
  return createPersistedState(state);
}

export function listSavedConfigurationNames() {
  return Object.keys(loadSavedConfigurations()).sort((leftName, rightName) =>
    leftName.localeCompare(rightName, "de")
  );
}

export function saveNamedConfiguration(name, state) {
  const trimmedName = String(name || "").trim();

  if (!trimmedName) {
    throw new Error("Der Konfigurationsname darf nicht leer sein.");
  }

  const savedConfigurations = loadSavedConfigurations();
  savedConfigurations[trimmedName] = createPersistedState(state);
  window.localStorage.setItem(
    SAVED_CONFIGS_STORAGE_KEY,
    JSON.stringify(savedConfigurations)
  );
}

export function deleteNamedConfiguration(name) {
  const trimmedName = String(name || "").trim();

  if (!trimmedName) {
    throw new Error("Es wurde keine Konfiguration zum Loeschen ausgewaehlt.");
  }

  const savedConfigurations = loadSavedConfigurations();

  if (!savedConfigurations[trimmedName]) {
    throw new Error("Die ausgewaehlte Konfiguration wurde nicht gefunden.");
  }

  delete savedConfigurations[trimmedName];
  window.localStorage.setItem(
    SAVED_CONFIGS_STORAGE_KEY,
    JSON.stringify(savedConfigurations)
  );
}

export function loadNamedConfiguration(name) {
  const trimmedName = String(name || "").trim();
  const savedConfigurations = loadSavedConfigurations();
  const savedConfiguration = savedConfigurations[trimmedName];

  if (!savedConfiguration) {
    throw new Error("Die ausgewaehlte Konfiguration wurde nicht gefunden.");
  }

  const importedConfiguration = importState(savedConfiguration);
  importedConfiguration.appSettings.configName = trimmedName;
  return importedConfiguration;
}

export function importState(importedState) {
  const normalizedState = {
    connection: {
      ...createDefaultConnection(),
      ...(importedState?.connection || {})
    },
    appSettings: {
      ...createDefaultAppSettings(),
      ...(importedState?.appSettings || {})
    },
    templateCatalog: normalizeTemplateCatalog(importedState?.templateCatalog),
    statusItems: Array.isArray(importedState?.statusItems)
      ? importedState.statusItems.map(normalizeImportedStatusItem)
      : [],
    commandItems: Array.isArray(importedState?.commandItems)
      ? importedState.commandItems.map(normalizeCommandItem)
      : []
  };

  // Nach dem Laden sollen nur die Struktur und nicht alte Live-Werte
  // uebernommen werden, damit die Anzeige wieder frisch vom Broker kommt.
  normalizedState.statusItems = normalizedState.statusItems.map((item) => ({
    ...item,
    lastValue: null,
    lastUpdated: null
  }));

  return normalizedState;
}

export function createDefaultConnection() {
  return {
    host: "",
    port: 1883,
    username: "",
    password: ""
  };
}

export function createDefaultAppSettings() {
  return {
    autoScrollLog: true,
    configName: "",
    theme: "light",
    showTemplateTools: true,
    sectionVisibility: createDefaultSectionVisibility(),
    brokerConfigCollapsed: false,
    loggingOutputDir: "",
    loggingPanelCollapsed: false,
    eventsCollapsed: false,
    hardwareMonitorCollapsed: false,
    collapsedStatusGroups: {},
    collapsedCommandGroups: {}
  };
}

export function createDefaultSectionVisibility() {
  return {
    templateImport: true,
    broker: true,
    logging: true,
    status: true,
    commands: true,
    events: true,
    hardwareMonitor: true
  };
}

export function createDefaultStatusItem() {
  return {
    id: createId(),
    activeTab: "primary",
    label: "",
    group: "",
    topic: "",
    key: "",
    unit: "",
    collapsed: false,
    showHistory: false,
    historyLimit: 10,
    historyManualScale: false,
    historyRefreshWhileCollapsed: false,
    historyRefreshWhileCollapsedThrottled: false,
    historyMin: null,
    historyMax: null,
    historyValues: [],
    logEnabled: false,
    lastValue: null,
    lastUpdated: null
  };
}

export function createDefaultCommand() {
  return {
    id: createId(),
    activeTab: "primary",
    label: "",
    group: "",
    topic: "",
    key: "",
    collapsed: false,
    value: "",
    logEnabled: false
  };
}

function createDefaultState() {
  return {
    connection: createDefaultConnection(),
    appSettings: createDefaultAppSettings(),
    templateCatalog: createEmptyTemplateCatalog(),
    statusItems: [],
    commandItems: []
  };
}

function createPersistedState(state) {
  return {
    connection: {
      ...createDefaultConnection(),
      ...state.connection
    },
    appSettings: {
      ...createDefaultAppSettings(),
      ...state.appSettings
    },
    templateCatalog: normalizeTemplateCatalog(state.templateCatalog),
    statusItems: Array.isArray(state.statusItems)
      ? state.statusItems.map((item) => ({
          id: item.id || createId(),
          activeTab: item.activeTab === "settings" ? "settings" : "primary",
          label: item.label || "",
          group: item.group || "",
          topic: item.topic || "",
          key: item.key || "",
          unit: item.unit || "",
          showHistory: item.showHistory === true,
          historyLimit: normalizeHistoryLimit(item.historyLimit),
          historyManualScale: item.historyManualScale === true,
          historyRefreshWhileCollapsed: item.historyRefreshWhileCollapsed === true,
          historyRefreshWhileCollapsedThrottled:
            item.historyRefreshWhileCollapsedThrottled === true,
          historyMin: normalizeAxisValue(item.historyMin),
          historyMax: normalizeAxisValue(item.historyMax),
          logEnabled: item.logEnabled === true,
          collapsed: item.collapsed === true
        }))
      : [],
    commandItems: Array.isArray(state.commandItems)
      ? state.commandItems.map((item) => ({
          id: item.id || createId(),
          activeTab: item.activeTab === "settings" ? "settings" : "primary",
          label: item.label || "",
          group: item.group || "",
          topic: item.topic || "",
          key: item.key || "",
          collapsed: item.collapsed === true,
          value: item.value || "",
          logEnabled: item.logEnabled === true
        }))
      : []
  };
}

function normalizeStatusItem(item) {
  return {
    ...createDefaultStatusItem(),
    ...item,
    id: item?.id || createId(),
    activeTab: item?.activeTab === "settings" ? "settings" : "primary",
    showHistory: item?.showHistory === true,
    historyLimit: normalizeHistoryLimit(item?.historyLimit),
    historyManualScale: item?.historyManualScale === true,
    historyRefreshWhileCollapsed: item?.historyRefreshWhileCollapsed === true,
    historyRefreshWhileCollapsedThrottled:
      item?.historyRefreshWhileCollapsedThrottled === true,
    historyMin: normalizeAxisValue(item?.historyMin),
    historyMax: normalizeAxisValue(item?.historyMax),
    logEnabled: item?.logEnabled === true,
    unit: String(item?.unit || "").trim(),
    historyValues: [],
    // Live-Werte werden bewusst nicht aus dem Browser-Speicher geladen,
    // weil Statusanzeigen laut Vorgabe nur waehrend der Laufzeit gelten.
    lastValue: null,
    lastUpdated: null
  };
}

function normalizeImportedStatusItem(item) {
  const normalizedItem = normalizeStatusItem(item);

  if (!Object.prototype.hasOwnProperty.call(item || {}, "showHistory")) {
    // Alte Konfigurationen ohne Historien-Feld werden bewusst so
    // uebernommen, dass zunaechst keine Historie aktiv ist.
    normalizedItem.showHistory = false;
  }

  return normalizedItem;
}

function normalizeCommandItem(item) {
  return {
    ...createDefaultCommand(),
    ...item,
    id: item?.id || createId(),
    activeTab: item?.activeTab === "settings" ? "settings" : "primary",
    logEnabled: item?.logEnabled === true
  };
}

function createId() {
  // Eine einfache eindeutige Kennung reicht hier aus, weil die Daten
  // nur lokal im Browser verwaltet werden.
  return `id-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`;
}

function resolveStorageKey() {
  return `mqtt-webinterface-state-${resolveInstanceId()}`;
}

function loadSavedConfigurations() {
  const rawValue = window.localStorage.getItem(SAVED_CONFIGS_STORAGE_KEY);

  if (!rawValue) {
    return {};
  }

  try {
    const parsedValue = JSON.parse(rawValue);

    if (!parsedValue || typeof parsedValue !== "object" || Array.isArray(parsedValue)) {
      return {};
    }

    return parsedValue;
  } catch (error) {
    return {};
  }
}

function normalizeHistoryLimit(limitValue) {
  const parsedLimit = Number.parseInt(String(limitValue || ""), 10);

  if (Number.isNaN(parsedLimit)) {
    return 10;
  }

  return Math.max(1, Math.min(1000, parsedLimit));
}
