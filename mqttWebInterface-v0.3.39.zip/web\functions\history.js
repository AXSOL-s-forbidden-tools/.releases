export function clampHistoryLimit(limitValue) {
  const parsedLimit = Number.parseInt(String(limitValue || ""), 10);

  if (Number.isNaN(parsedLimit)) {
    return 10;
  }

  return Math.max(1, Math.min(1000, parsedLimit));
}

export function normalizeAxisValue(axisValue) {
  if (axisValue === null || axisValue === undefined || axisValue === "") {
    return null;
  }

  const parsedValue = Number.parseFloat(String(axisValue));
  return Number.isFinite(parsedValue) ? parsedValue : null;
}

export function appendHistoryValue(item, nextValue) {
  const normalizedLimit = clampHistoryLimit(item.historyLimit);
  item.historyLimit = normalizedLimit;

  if (item.showHistory !== true) {
    item.historyValues = [];
    return;
  }

  if (typeof nextValue !== "number" || Number.isNaN(nextValue)) {
    return;
  }

  const nextHistoryValues = Array.isArray(item.historyValues)
    ? [...item.historyValues, nextValue]
    : [nextValue];

  item.historyValues = nextHistoryValues.slice(-normalizedLimit);
}

export function resolveHistoryAxisBounds(historyValues, item = {}) {
  if (!Array.isArray(historyValues) || historyValues.length === 0) {
    return {
      minValue: 0,
      maxValue: 1,
      source: item.historyManualScale === true ? "manual" : "auto"
    };
  }

  const dataMinValue = Math.min(...historyValues);
  const dataMaxValue = Math.max(...historyValues);
  const manualMinValue = normalizeAxisValue(item.historyMin);
  const manualMaxValue = normalizeAxisValue(item.historyMax);

  if (
    item.historyManualScale === true &&
    manualMinValue !== null &&
    manualMaxValue !== null &&
    manualMinValue < manualMaxValue
  ) {
    return {
      minValue: manualMinValue,
      maxValue: manualMaxValue,
      source: "manual"
    };
  }

  return {
    minValue: dataMinValue,
    maxValue: dataMaxValue,
    source: "auto"
  };
}

export function buildHistoryPolyline(historyValues, width, height, padding, item = {}) {
  if (!Array.isArray(historyValues) || historyValues.length < 2) {
    return "";
  }

  const { minValue, maxValue } = resolveHistoryAxisBounds(historyValues, item);
  const valueRange = maxValue - minValue || 1;
  const drawableWidth = width - padding * 2;
  const drawableHeight = height - padding * 2;

  return historyValues
    .map((value, index) => {
      const x = padding + (drawableWidth * index) / (historyValues.length - 1);
      const normalizedValue = (value - minValue) / valueRange;
      const y = height - padding - normalizedValue * drawableHeight;
      return `${x.toFixed(2)},${y.toFixed(2)}`;
    })
    .join(" ");
}

export function formatHistoryRange(historyValues, item = {}) {
  if (!Array.isArray(historyValues) || historyValues.length === 0) {
    return "Noch keine Historie vorhanden";
  }

  const dataMinValue = Math.min(...historyValues);
  const dataMaxValue = Math.max(...historyValues);
  const { minValue, maxValue, source } = resolveHistoryAxisBounds(historyValues, item);

  if (dataMinValue === dataMaxValue) {
    const scalePrefix = source === "manual"
      ? `Y-Achse: ${formatGraphValue(minValue)} bis ${formatGraphValue(maxValue)} | `
      : "";
    return `${scalePrefix}Konstanter Wert: ${formatGraphValue(dataMinValue)}`;
  }

  const dataSummary = `Daten: ${formatGraphValue(dataMinValue)} bis ${formatGraphValue(dataMaxValue)}`;

  if (source === "manual") {
    return `Y-Achse: ${formatGraphValue(minValue)} bis ${formatGraphValue(maxValue)} | ${dataSummary}`;
  }

  return dataSummary;
}

export function buildHistoryAxisLabels(historyValues, item = {}) {
  if (!Array.isArray(historyValues) || historyValues.length === 0) {
    return {
      maxLabel: "-",
      midLabel: "-",
      minLabel: "-"
    };
  }

  const { minValue, maxValue } = resolveHistoryAxisBounds(historyValues, item);
  const midValue = minValue + (maxValue - minValue) / 2;

  return {
    maxLabel: formatGraphValue(maxValue),
    midLabel: formatGraphValue(midValue),
    minLabel: formatGraphValue(minValue)
  };
}

function formatGraphValue(value) {
  if (Number.isInteger(value)) {
    return String(value);
  }

  return value.toFixed(2);
}
