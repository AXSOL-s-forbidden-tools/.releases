# Lokale Entwicklung

## Voraussetzungen
- Ein aktueller Browser
- Python 3
- Ein MQTT-Broker mit klassischem TCP-Zugang, zum Beispiel auf Port `1883`

## Start
1. Projektordner lokal bereitstellen.
2. `startWebserver.bat` ausfuehren.
3. Beim Prompt `Port fuer Webserver:` optional einen anderen Port eingeben oder direkt mit Enter bestaetigen.
4. Im Browser `http://127.0.0.1:<dein-port>` oder `http://localhost:<dein-port>` oeffnen.
5. Im Webinterface Host, Port, Benutzername und Passwort des Brokers eintragen.
6. Zum Beenden `Strg+C` im Serverfenster druecken. Das ist ein normaler Stop und kein Laufzeitfehler.
7. Wird das Terminalfenster direkt geschlossen, versucht der Server ebenfalls einen geordneten Shutdown.

## Entwicklungshinweise
- Die Anwendung speichert ihre Konfiguration im `localStorage` des Browsers.
- Jede Browser-Instanz nutzt dafuer bewusst einen eigenen Speicherbereich fuer die aktuelle Arbeitskonfiguration, damit parallele Sitzungen sich nicht ueberschreiben.
- Benannte Konfigurationen werden zusaetzlich browserweit gespeichert und koennen in anderen Browserfenstern wieder geladen werden.
- Importierte JSON-Dateien werden nur in die aktuelle Sitzung uebernommen und nicht automatisch als benannte Browser-Konfiguration gespeichert.
- Exportierte JSON-Dateien enthalten nur die Konfiguration und bewusst keine Live-Statuswerte.
- Empfangene Statuswerte werden absichtlich nicht gespeichert, sondern nur live angezeigt.
- Aktivierte Historiengraphen sammeln nur numerische Live-Werte und werden beim Neuladen bewusst verworfen.
- Die Y-Achse der Historie zeigt zur groben Orientierung Minimal-, Mittel- und Maximalwert an.
- Die Historienlaenge wird erst mit `Enter` gespeichert, damit mehrstellige Werte ohne Zwischenvalidierung eingegeben werden koennen.
- Die `Log`-Checkbox an Status- und Befehlskarten reduziert bewusst die Menge an Topic-bezogenen Eintraegen im Ereignisbereich.
- Der separate Bereich `Hardware Monitor` kombiniert Browser-Werte wie JavaScript-Heap und Historienanzahl mit Serverwerten wie Prozessspeicher, CPU und Uptime.
- Bereiche mit dem HTML-Attribut `hidden` werden im CSS explizit ausgeblendet, damit optionale Felder und Diagramme nicht versehentlich sichtbar bleiben.
- Aeltere Konfigurationen ohne Historien-Option lassen sich weiter laden und erhalten dabei automatisch `Zeige Historie = aus`.
- Status- und Befehlskarten koennen nach der Einrichtung platzsparend eingeklappt werden.
- Eingeklappte Karten werden in ihren Gruppen automatisch als kompakte Kacheln nebeneinander angeordnet.
- Status- und Befehlskarten koennen optional in Gruppen zusammengefasst werden.
- Ganze Gruppen von Status- und Befehlskarten lassen sich zusaetzlich gemeinsam ein- und ausklappen.
- Ganze Gruppen von Status- und Befehlskarten lassen sich ueber ihr Zieh-Symbol auch als kompletter Block umsortieren.
- Der Gruppenpfeil schaltet die Gruppe sofort sichtbar um und speichert danach den neuen Zustand.
- Die Reihenfolge innerhalb derselben Gruppe kann per Drag&Drop ueber das Zieh-Symbol an jeder Karte angepasst werden.
- Auch Broker-Konfiguration und Ereignisprotokoll koennen ein- und ausgeblendet werden.
- Der separate Hardware-Monitor kann ebenfalls ein- und ausgeklappt werden.
- Statuswerte werden anhand von `topic` und `key` ausgewertet.
- Befehle werden als JSON-Objekt mit genau einem konfigurierten Key gesendet.
- Der Browser spricht nur mit dem lokalen HTTP-Server.
- Die eigentliche MQTT-TCP-Kommunikation uebernimmt `functions/mqtt_backend.py`.
- Fuer das Server-Monitoring liefert `backend/functions/system_monitor.py` einfache Laufzeitkennzahlen ohne zusaetzliche Fremdbibliotheken.
- Auch bei `file://` nutzt das Frontend gezielt `http://127.0.0.1:8080` als API-Basis.
- Wenn das Webinterface ueber den lokalen Server geoeffnet wird, nutzt das Frontend automatisch genau den gewaehlten Webserver-Port.
- Jede Browser-Instanz arbeitet mit einer eigenen Sitzungs-ID, damit mehrere parallele Instanzen moeglich sind.

## Testidee
1. Mit einem Test-Broker verbinden.
2. Einen bekannten Statuswert abonnieren.
3. Eine Testnachricht mit JSON-Payload auf das konfigurierte Topic senden.
4. Pruefen, ob der Wert im Webinterface sichtbar wird.
5. Einen Befehlsbutton ausloesen und die gesendete Payload im Broker pruefen.
