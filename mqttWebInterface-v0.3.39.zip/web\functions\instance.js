const INSTANCE_STORAGE_KEY = "mqtt-webinterface-instance-id";

export function resolveInstanceId() {
  const existingId = window.sessionStorage.getItem(INSTANCE_STORAGE_KEY);

  if (existingId) {
    return existingId;
  }

  // Jede Browser-Instanz bekommt eine eigene Kennung, damit getrennte
  // Verbindungen und getrennte lokale Konfigurationen moeglich bleiben.
  const newId = `instance-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`;
  window.sessionStorage.setItem(INSTANCE_STORAGE_KEY, newId);
  return newId;
}
