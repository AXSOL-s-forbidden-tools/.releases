import { resolveInstanceId } from "./instance.js";

const apiBaseUrl = resolveApiBaseUrl();
const instanceId = resolveInstanceId();

export async function fetchLoggingStatus() {
  const response = await fetch(
    buildApiUrl(`/api/logging/status?instanceId=${encodeURIComponent(instanceId)}`),
    { cache: "no-store" }
  );
  const payload = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(payload.error || `HTTP ${response.status}`);
  }

  return payload;
}

export async function startLogging(outputDir, statusItems) {
  return sendJson("/api/logging/start", {
    instanceId,
    outputDir,
    statusItems,
  });
}

export async function stopLogging() {
  return sendJson("/api/logging/stop", { instanceId });
}

export async function selectLoggingDirectory(initialDir) {
  const payload = await sendJson("/api/dialog/select-directory", {
    initialDir: String(initialDir || "").trim()
  });

  return String(payload.path || "").trim();
}

function resolveApiBaseUrl() {
  if (window.location.protocol === "file:") {
    return "http://127.0.0.1:8080";
  }

  return window.location.origin;
}

function buildApiUrl(path) {
  return `${apiBaseUrl}${path}`;
}

async function sendJson(path, body) {
  const response = await fetch(buildApiUrl(path), {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });
  const payload = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(payload.error || `HTTP ${response.status}`);
  }

  return payload;
}
