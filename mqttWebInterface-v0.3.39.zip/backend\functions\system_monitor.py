import os
import time
import ctypes


_PROCESS_HANDLE = ctypes.windll.kernel32.GetCurrentProcess() if hasattr(ctypes, "windll") else None
_PSAPI = ctypes.WinDLL("Psapi.dll") if hasattr(ctypes, "WinDLL") else None
_LAST_CPU_SAMPLE = {
    "wall_time": None,
    "cpu_time": None,
}


class ProcessMemoryCounters(ctypes.Structure):
    _fields_ = [
        ("cb", ctypes.c_ulong),
        ("PageFaultCount", ctypes.c_ulong),
        ("PeakWorkingSetSize", ctypes.c_size_t),
        ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
        ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t),
        ("PeakPagefileUsage", ctypes.c_size_t),
    ]


if _PSAPI is not None:
    _PSAPI.GetProcessMemoryInfo.argtypes = [
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_ulong,
    ]
    _PSAPI.GetProcessMemoryInfo.restype = ctypes.c_int


def collect_system_metrics(active_instances: int, start_time: float):
    return {
        "activeInstances": active_instances,
        "processMemoryMb": _read_process_memory_mb(),
        "processCpuPercent": _read_process_cpu_percent(),
        "uptimeText": _format_uptime(time.time() - start_time),
        "measuredAt": time.strftime("%d.%m.%Y %H:%M:%S"),
    }


def _read_process_memory_mb():
    if _PROCESS_HANDLE is None:
        return None

    counters = ProcessMemoryCounters()
    counters.cb = ctypes.sizeof(ProcessMemoryCounters)

    if _PSAPI is None:
        return None

    success = _PSAPI.GetProcessMemoryInfo(
        _PROCESS_HANDLE,
        ctypes.byref(counters),
        counters.cb,
    )

    if not success:
        return None

    return round(counters.WorkingSetSize / (1024 * 1024), 2)


def _read_process_cpu_percent():
    current_wall_time = time.time()
    current_cpu_time = time.process_time()
    previous_wall_time = _LAST_CPU_SAMPLE["wall_time"]
    previous_cpu_time = _LAST_CPU_SAMPLE["cpu_time"]

    _LAST_CPU_SAMPLE["wall_time"] = current_wall_time
    _LAST_CPU_SAMPLE["cpu_time"] = current_cpu_time

    if previous_wall_time is None or previous_cpu_time is None:
        return None

    elapsed_wall_time = max(current_wall_time - previous_wall_time, 0.001)
    elapsed_cpu_time = max(current_cpu_time - previous_cpu_time, 0.0)
    cpu_cores = os.cpu_count() or 1
    cpu_percent = (elapsed_cpu_time / elapsed_wall_time) * 100 / cpu_cores
    return round(cpu_percent, 2)


def _format_uptime(seconds: float):
    total_seconds = max(int(seconds), 0)
    hours, remaining_seconds = divmod(total_seconds, 3600)
    minutes, seconds_only = divmod(remaining_seconds, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds_only:02d}"
