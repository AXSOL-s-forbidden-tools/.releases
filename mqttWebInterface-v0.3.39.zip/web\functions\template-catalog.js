export function createEmptyTemplateCatalog() {
  return {
    components: []
  };
}

export function normalizeTemplateCatalog(catalog) {
  if (!catalog || !Array.isArray(catalog.components)) {
    return createEmptyTemplateCatalog();
  }

  return {
    components: catalog.components
      .map((component) => normalizeCatalogComponent(component))
      .filter((component) => component !== null)
  };
}

export function buildTemplateCatalog(fileEntries) {
  const componentsByFolder = new Map();

  fileEntries.forEach((entry) => {
    const normalizedPath = normalizeEntryPath(entry.path);
    const importFileName = normalizedPath.split("/").filter(Boolean).at(-1)?.toLowerCase() || "";

    if (importFileName !== "mqttwebimport.json" && importFileName !== "component.json") {
      return;
    }

    const folderPath = normalizedPath.slice(0, normalizedPath.length - `/${importFileName}`.length);
    const componentDefinition = safeParseJson(entry.content, entry.path);
    const baseTopic = normalizeTopic(
      componentDefinition?.mqttTopic
      || componentDefinition?.MQTT?.topic
    );

    if (!baseTopic) {
      throw new Error(`In ${entry.path} fehlt mqttTopic.`);
    }

    const folderName = folderPath.split("/").filter(Boolean).at(-1) || folderPath || "Komponente";
    const childSubtopic = String(
      componentDefinition?.childSubtopic
      || componentDefinition?.Child?.subtopic
      || componentDefinition?.child?.subtopic
      || ""
    ).trim();
    componentsByFolder.set(folderPath, {
      id: createComponentId(folderPath),
      folderPath,
      folderName,
      displayName: String(
        componentDefinition?.displayName
        || componentDefinition?.Component?.componentName
        || folderName
      ).trim() || folderName,
      baseTopic,
      childSubtopic,
      parentDescription: String(
        componentDefinition?.parentDescription
        || componentDefinition?.Parent?.parentDescription
        || componentDefinition?.parent?.parentDescription
        || "Parent"
      ).trim() || "Parent",
      childDescription: String(
        componentDefinition?.childDescription
        || componentDefinition?.Child?.childDescription
        || componentDefinition?.child?.childDescription
        || "Child"
      ).trim() || "Child",
      parentTemplates: [],
      childTemplates: []
    });
  });

  fileEntries.forEach((entry) => {
    const normalizedPath = normalizeEntryPath(entry.path);
    const pathSegments = normalizedPath.split("/").filter(Boolean);

    if (pathSegments.length < 3 || !normalizedPath.toLowerCase().endsWith(".json")) {
      return;
    }

    if (
      pathSegments[pathSegments.length - 1].toLowerCase() === "component.json"
      || pathSegments[pathSegments.length - 1].toLowerCase() === "mqttwebimport.json"
    ) {
      return;
    }

    const scopeFolderName = pathSegments[pathSegments.length - 2].toLowerCase();
    const componentFolderPath = pathSegments.slice(0, -2).join("/");
    const component = componentsByFolder.get(componentFolderPath);

    if (!component) {
      return;
    }

    if (scopeFolderName !== "values" && scopeFolderName !== "child") {
      return;
    }

    const valueDefinition = safeParseJson(entry.content, entry.path);
    const mqttName = String(valueDefinition?.mqttName || "").trim();

    if (!mqttName) {
      return;
    }

    const template = {
      id: `${component.id}:${scopeFolderName}:${pathSegments[pathSegments.length - 1]}`,
      label: String(valueDefinition?.description || mqttName).trim() || mqttName,
      key: mqttName,
      unit: String(valueDefinition?.mqttUnit || "").trim(),
      decimals: normalizeOptionalNumber(valueDefinition?.mqttDecimals),
      sourcePath: normalizedPath
    };

    if (scopeFolderName === "values") {
      component.parentTemplates.push(template);
      return;
    }

    if (!component.childSubtopic) {
      throw new Error(
        `In ${component.folderPath}/mqttWebImport.json fehlt childSubtopic fuer Werte im child-Ordner.`
      );
    }

    component.childTemplates.push(template);
  });

  return normalizeTemplateCatalog({
    components: [...componentsByFolder.values()]
  });
}

export function getCatalogComponent(catalog, componentId) {
  return normalizeTemplateCatalog(catalog).components.find((component) => component.id === componentId) || null;
}

export function getTemplatesForScope(component, scope) {
  if (!component) {
    return [];
  }

  if (scope === "child") {
    return Array.isArray(component.childTemplates) ? component.childTemplates : [];
  }

  return Array.isArray(component.parentTemplates) ? component.parentTemplates : [];
}

export function buildDiscoveryTopics(catalog) {
  const topics = new Set();

  normalizeTemplateCatalog(catalog).components.forEach((component) => {
    if (component.parentTemplates.length > 0 || component.childTemplates.length > 0) {
      topics.add(`${component.baseTopic}/#`);
    }
  });

  return [...topics].sort((leftTopic, rightTopic) => leftTopic.localeCompare(rightTopic, "de"));
}

export function findDiscoveryMatches(catalog, topic, payload) {
  const matches = [];
  const normalizedTopic = normalizeTopic(topic);
  const payloadKeys = payload && typeof payload === "object" && !Array.isArray(payload)
    ? new Set(Object.keys(payload))
    : new Set();

  if (payloadKeys.size === 0) {
    return matches;
  }

  normalizeTemplateCatalog(catalog).components.forEach((component) => {
    const parentInstanceId = extractParentInstanceId(normalizedTopic, `${component.baseTopic}/`);
    if (parentInstanceId !== null) {
      const matchingTemplates = component.parentTemplates.filter((template) => payloadKeys.has(template.key));

      if (matchingTemplates.length > 0) {
        matches.push({
          componentId: component.id,
          scope: "parent",
          instanceId: parentInstanceId,
          matchingTemplates
        });
      }
    }

    if (!component.childSubtopic) {
      return;
    }

    const childInstanceId = extractChildInstanceId(
      normalizedTopic,
      `${component.baseTopic}/`,
      component.childSubtopic
    );

    if (childInstanceId === null) {
      return;
    }

    const matchingTemplates = component.childTemplates.filter((template) => payloadKeys.has(template.key));

    if (matchingTemplates.length > 0) {
      matches.push({
        componentId: component.id,
        scope: "child",
        instanceId: childInstanceId,
        matchingTemplates
      });
    }
  });

  return matches;
}

export function buildStatusTopic(component, scope, instanceId) {
  const normalizedInstanceId = normalizeInstanceId(instanceId);

  if (!normalizedInstanceId) {
    return "";
  }

  if (scope === "child") {
    const childSubtopic = String(component?.childSubtopic || "").trim();
    const [parentInstanceId, childInstanceId] = splitChildInstanceId(normalizedInstanceId);

    if (!childSubtopic || !parentInstanceId || !childInstanceId) {
      return "";
    }

    return `${component.baseTopic}/${parentInstanceId}/${childSubtopic}/${childInstanceId}`;
  }

  return `${component.baseTopic}/${normalizedInstanceId}/#`;
}

export function createStatusItemFromTemplate(component, scope, instanceId, template, groupName, createDefaultStatusItem) {
  const statusItem = createDefaultStatusItem();
  statusItem.group = String(groupName || component?.folderName || "").trim();
  statusItem.label = String(template?.label || template?.key || "").trim();
  statusItem.topic = buildStatusTopic(component, scope, instanceId);
  statusItem.key = String(template?.key || "").trim();
  statusItem.unit = String(template?.unit || "").trim();
  return statusItem;
}

function normalizeCatalogComponent(component) {
  if (!component || typeof component !== "object") {
    return null;
  }

  const baseTopic = normalizeTopic(component.baseTopic);

  if (!baseTopic) {
    return null;
  }

  return {
    id: String(component.id || createComponentId(component.folderPath || component.folderName || baseTopic)),
    folderPath: String(component.folderPath || "").trim(),
    folderName: String(component.folderName || component.displayName || "Komponente").trim() || "Komponente",
    displayName: String(component.displayName || component.folderName || "Komponente").trim() || "Komponente",
    baseTopic,
    childSubtopic: String(component.childSubtopic || "").trim(),
    parentDescription: String(component.parentDescription || "Parent").trim() || "Parent",
    childDescription: String(component.childDescription || "Child").trim() || "Child",
    parentTemplates: normalizeTemplates(component.parentTemplates),
    childTemplates: normalizeTemplates(component.childTemplates)
  };
}

function normalizeTemplates(templates) {
  if (!Array.isArray(templates)) {
    return [];
  }

  return templates
    .map((template) => ({
      id: String(template?.id || ""),
      label: String(template?.label || template?.key || "").trim(),
      key: String(template?.key || "").trim(),
      unit: String(template?.unit || "").trim(),
      decimals: normalizeOptionalNumber(template?.decimals),
      sourcePath: String(template?.sourcePath || "").trim()
    }))
    .filter((template) => template.key !== "")
    .sort((leftTemplate, rightTemplate) =>
      `${leftTemplate.label} ${leftTemplate.key}`.localeCompare(
        `${rightTemplate.label} ${rightTemplate.key}`,
        "de"
      )
    );
}

function normalizeEntryPath(path) {
  return String(path || "").replace(/\\/g, "/").replace(/^\/+|\/+$/g, "");
}

function safeParseJson(content, sourcePath) {
  try {
    return JSON.parse(content);
  } catch (error) {
    throw new Error(`Datei ${sourcePath} enthaelt kein gueltiges JSON.`);
  }
}

function normalizeTopic(topic) {
  return String(topic || "").trim().replace(/\/+$/g, "");
}

function createComponentId(input) {
  return String(input || "komponente").trim().replace(/[^\w/-]+/g, "-");
}

function normalizeOptionalNumber(value) {
  const parsedValue = Number(value);
  return Number.isFinite(parsedValue) ? parsedValue : null;
}

function extractParentInstanceId(topic, prefix) {
  if (!topic.startsWith(prefix)) {
    return null;
  }

  const trailingPart = topic.slice(prefix.length).replace(/^\/+|\/+$/g, "");

  if (!trailingPart) {
    return null;
  }

  const segments = trailingPart.split("/").filter(Boolean);

  if (segments.length < 1) {
    return null;
  }

  if (!/^\d{1,3}$/.test(segments[0])) {
    return null;
  }

  return segments[0];
}

function extractChildInstanceId(topic, prefix, childSubtopic) {
  if (!topic.startsWith(prefix)) {
    return null;
  }

  const trailingPart = topic.slice(prefix.length).replace(/^\/+|\/+$/g, "");

  if (!trailingPart) {
    return null;
  }

  const segments = trailingPart.split("/").filter(Boolean);

  if (segments.length < 3) {
    return null;
  }

  if (!/^\d{1,3}$/.test(segments[0])) {
    return null;
  }

  if (segments[1] !== String(childSubtopic || "").trim()) {
    return null;
  }

  if (!/^\d{1,2}$/.test(segments[2])) {
    return null;
  }

  return `${segments[0]}/${segments[2]}`;
}

function normalizeInstanceId(instanceId) {
  const normalizedSuffix = String(instanceId || "").trim().replace(/^\/+|\/+$/g, "");

  if (!normalizedSuffix) {
    return "";
  }

  if (/^\d{1,3}$/.test(normalizedSuffix)) {
    return normalizedSuffix;
  }

  if (!/^\d{1,3}\/\d{1,2}$/.test(normalizedSuffix)) {
    return "";
  }

  return normalizedSuffix;
}

function splitChildInstanceId(instanceId) {
  const segments = String(instanceId || "").split("/");
  return [segments[0] || "", segments[1] || ""];
}
