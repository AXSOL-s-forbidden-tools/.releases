from datetime import datetime, timezone


def parse_cutoff_date(raw_value: str | None) -> datetime | None:
    if not raw_value:
        return None

    parsed_date = datetime.strptime(raw_value, "%Y-%m-%d")
    return parsed_date.replace(hour=23, minute=59, second=59, tzinfo=timezone.utc)
