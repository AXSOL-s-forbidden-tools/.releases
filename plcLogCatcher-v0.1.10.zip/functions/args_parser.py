import argparse


def build_argument_parser(tool_version: str) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            f"PLC Log Catcher {tool_version} laedt Log-Dateien "
            "von einer WAGO SPS per SSH/SFTP herunter."
        )
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {tool_version}",
    )
    parser.add_argument("--host", required=True, help="IP-Adresse oder DNS-Name der SPS.")
    parser.add_argument(
        "--port",
        type=int,
        default=22,
        help="SSH-Port der SPS. Standard ist 22.",
    )
    parser.add_argument(
        "--username",
        default="root",
        help="Benutzername fuer die SSH-Anmeldung. Standard ist root.",
    )
    parser.add_argument(
        "--count",
        type=int,
        default=10,
        help="Anzahl der neuesten Dateien, die kopiert werden sollen.",
    )
    parser.add_argument(
        "--before-date",
        help="Nur Dateien bis einschliesslich diesem Datum kopieren. Format: YYYY-MM-DD.",
    )
    parser.add_argument(
        "--remote-dir",
        default="/home/logging",
        help="Remote-Ordner mit den Log-Dateien. Standard ist /home/logging.",
    )
    parser.add_argument(
        "--target-dir",
        default="downloads",
        help="Lokales Zielverzeichnis fuer die kopierten Dateien.",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=15,
        help="Zeitlimit fuer den Verbindungsaufbau in Sekunden.",
    )
    parser.add_argument(
        "--no-cache",
        action="store_true",
        help="Gespeicherte Zugangsdaten fuer diesen Lauf ignorieren.",
    )
    parser.add_argument(
        "--copy-live-log-only",
        action="store_true",
        help="Kopiert nur die aktuelle Live-Logdatei statt der allgemeinen Dateiauswahl.",
    )
    parser.add_argument(
        "--list-remote-files-only",
        action="store_true",
        help="Listet nur die aktuell verfuegbaren Dateien im Remote-Verzeichnis auf.",
    )
    parser.add_argument(
        "--quiet-console",
        action="store_true",
        help="Schreibt Log-Eintraege nur in die Log-Datei und nicht zusaetzlich auf die Konsole.",
    )
    return parser
