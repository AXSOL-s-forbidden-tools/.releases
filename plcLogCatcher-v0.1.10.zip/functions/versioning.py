from pathlib import Path


VERSION_FILE_PATH = Path(__file__).resolve().parent.parent / "VERSION"
FALLBACK_VERSION = "0.0.0"


def read_tool_version() -> str:
    if not VERSION_FILE_PATH.exists():
        return FALLBACK_VERSION

    version_value = VERSION_FILE_PATH.read_text(encoding="utf-8").strip()
    if not version_value:
        return FALLBACK_VERSION

    return version_value
