import json
import re
from pathlib import Path
from typing import Any


CACHE_ROOT = Path(".plc_log_catcher")
HOSTS_ROOT = CACHE_ROOT / "hosts"
CREDENTIALS_FILE = Path(".credentials.json")


def ensure_cache_directories() -> None:
    HOSTS_ROOT.mkdir(parents=True, exist_ok=True)


def build_host_slug(host: str, port: int, username: str) -> str:
    raw_slug = f"{host}_{port}_{username}"
    return re.sub(r"[^a-zA-Z0-9._-]", "_", raw_slug)


def get_host_directory(host: str, port: int, username: str) -> Path:
    ensure_cache_directories()
    return HOSTS_ROOT / build_host_slug(host, port, username)


def load_connection_profile(host: str, port: int, username: str) -> dict[str, Any]:
    profile_path = get_host_directory(host, port, username) / "profile.json"
    if not profile_path.exists():
        return {}

    return json.loads(profile_path.read_text(encoding="utf-8"))


def save_connection_profile(host: str, port: int, username: str, profile: dict[str, Any]) -> None:
    host_directory = get_host_directory(host, port, username)
    host_directory.mkdir(parents=True, exist_ok=True)
    profile_path = host_directory / "profile.json"
    profile_path.write_text(json.dumps(profile, indent=2), encoding="utf-8")


def _load_credentials_file() -> dict[str, Any]:
    if not CREDENTIALS_FILE.exists():
        return {}

    return json.loads(CREDENTIALS_FILE.read_text(encoding="utf-8"))


def load_cached_password(host: str, port: int, username: str) -> str | None:
    credentials = _load_credentials_file()
    host_entries = credentials.get("hosts", {})
    host_key = build_host_slug(host, port, username)
    entry = host_entries.get(host_key)
    if not isinstance(entry, dict):
        return None

    password = entry.get("password")
    if not isinstance(password, str) or not password:
        return None

    return password


def save_cached_password(host: str, port: int, username: str, password: str) -> None:
    credentials = _load_credentials_file()
    host_entries = credentials.setdefault("hosts", {})
    host_entries[build_host_slug(host, port, username)] = {
        "host": host,
        "port": port,
        "username": username,
        "password": password,
    }
    CREDENTIALS_FILE.write_text(json.dumps(credentials, indent=2), encoding="utf-8")
