import logging
import shutil
from pathlib import Path

from functions.file_selection import RemoteLogFile
from functions.paths import resolve_from_project_root


def ensure_target_directory(target_dir: str) -> Path:
    target_path = resolve_from_project_root(target_dir)
    target_path.mkdir(parents=True, exist_ok=True)
    return target_path


def prepare_target_directory_for_download(target_path: Path) -> None:
    existing_entries = list(target_path.iterdir())
    if not existing_entries:
        logging.info("Lokales Zielverzeichnis ist bereits leer: %s", target_path)
        print(f"Lokales Zielverzeichnis ist leer: {target_path}")
        return

    if not _should_delete_existing_entries(target_path):
        print(
            f"Lokales Zielverzeichnis bleibt unveraendert: {target_path}. "
            "Gleichnamige Dateien werden beim Kopieren ueberschrieben."
        )
        logging.info(
            "Lokales Zielverzeichnis bleibt vor dem Download erhalten: %s. "
            "Vorhandene Dateien mit gleichem Namen werden ueberschrieben.",
            target_path,
        )
        return

    print(f"Lokales Zielverzeichnis ist nicht leer und wird vor dem Kopieren geleert: {target_path}")
    for entry in existing_entries:
        if entry.is_dir():
            # Remove nested folders completely so the target directory contains only the files from the new run.
            shutil.rmtree(entry)
        else:
            entry.unlink()

    logging.info(
        "Lokales Zielverzeichnis wurde vor dem Download geleert: %s. Entfernte Eintraege: %s",
        target_path,
        len(existing_entries),
    )


def _should_delete_existing_entries(target_path: Path) -> bool:
    print("")
    print(f"Das Zielverzeichnis enthaelt bereits Dateien oder Unterordner: {target_path}")
    print("Soll der vorhandene Inhalt vor dem Kopieren geloescht werden? [y/N]")

    while True:
        try:
            user_input = input("> ").strip().lower()
        except EOFError:
            print("Keine interaktive Eingabe verfuegbar. Das Zielverzeichnis bleibt unveraendert.")
            logging.warning(
                "Keine interaktive Eingabe verfuegbar. Das Zielverzeichnis bleibt erhalten: %s",
                target_path,
            )
            return False

        if user_input in {"y", "yes", "j", "ja"}:
            logging.info("Benutzer bestaetigt das Leeren des Zielverzeichnisses: %s", target_path)
            return True
        if user_input in {"", "n", "no", "nein"}:
            logging.info("Benutzer behaelt den vorhandenen Inhalt im Zielverzeichnis: %s", target_path)
            return False

        print("Bitte mit y oder n antworten.")


def print_selected_files(files: list[RemoteLogFile]) -> None:
    if not files:
        print("Keine passenden Log-Dateien gefunden.")
        return

    print("Folgende Dateien werden kopiert:")
    for item in files:
        print(
            f"- {item.filename} | Datum: {item.modified_at.isoformat()} | Groesse: {item.size_bytes} Byte"
        )


def print_remote_file_overview(files: list[RemoteLogFile], remote_dir: str) -> None:
    print("")
    print(f"Dateien im SPS-Verzeichnis {remote_dir}:")
    if not files:
        print("- Keine passenden Dateien gefunden.")
        return

    for index, item in enumerate(
        sorted(files, key=lambda entry: entry.modified_at, reverse=True),
        start=1,
    ):
        print(
            f"{index}. {item.filename} | Datum: {item.modified_at.isoformat()} | Groesse: {item.size_bytes} Byte"
        )
