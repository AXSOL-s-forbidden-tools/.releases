from dataclasses import dataclass
from datetime import datetime

EXCLUDED_REMOTE_FILE_SUFFIXES = (".sh",)
LIVE_LOG_FILE_MARKER = "_runtimelog_live.log"


@dataclass(slots=True)
class RemoteLogFile:
    filename: str
    remote_path: str
    modified_at: datetime
    size_bytes: int


def filter_and_limit_files(
    remote_files: list[RemoteLogFile],
    cutoff_date: datetime | None,
    count: int,
) -> list[RemoteLogFile]:
    filtered_files = [
        item
        for item in remote_files
        if not item.filename.lower().endswith(EXCLUDED_REMOTE_FILE_SUFFIXES)
    ]
    if cutoff_date is not None:
        filtered_files = [
            item for item in filtered_files if item.modified_at <= cutoff_date
        ]

    sorted_files = sorted(filtered_files, key=lambda item: item.modified_at, reverse=True)
    return sorted_files[:count]


def select_latest_live_log_file(remote_files: list[RemoteLogFile]) -> list[RemoteLogFile]:
    live_log_files = [
        item
        for item in remote_files
        if item.filename.lower().endswith(LIVE_LOG_FILE_MARKER)
    ]
    sorted_live_log_files = sorted(
        live_log_files,
        key=lambda item: item.modified_at,
        reverse=True,
    )
    return sorted_live_log_files[:1]
