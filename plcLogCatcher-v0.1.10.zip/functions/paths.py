from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent.parent


def resolve_from_project_root(raw_path: str) -> Path:
    candidate_path = Path(raw_path).expanduser()
    if candidate_path.is_absolute():
        return candidate_path.resolve()

    return (PROJECT_ROOT / candidate_path).resolve()
