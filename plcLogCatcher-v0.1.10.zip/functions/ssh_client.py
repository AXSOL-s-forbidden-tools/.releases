import getpass
import logging
import socket
import stat
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

import paramiko

from functions.cache_store import (
    get_host_directory,
    load_cached_password,
    load_connection_profile,
    save_cached_password,
    save_connection_profile,
)
from functions.file_selection import RemoteLogFile

MAX_PASSWORD_ATTEMPTS = 3
REMOTE_COPY_LIVE_LOG_COMMAND = "/etc/config-tools/copyLiveLog.sh"
PROGRESS_BAR_WIDTH = 24


@dataclass(slots=True)
class ConnectionSettings:
    host: str
    port: int
    username: str
    remote_dir: str
    timeout: int
    use_cache: bool


class AuthenticationRetriesExceededError(paramiko.AuthenticationException):
    pass


class RemoteCommandExecutionError(RuntimeError):
    pass


def _format_size(size_bytes: int) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    size_value = float(size_bytes)
    for unit in units:
        if size_value < 1024 or unit == units[-1]:
            if unit == "B":
                return f"{int(size_value)} {unit}"
            return f"{size_value:.1f} {unit}"
        size_value /= 1024

    return f"{size_bytes} B"


def _build_progress_callback(remote_file: RemoteLogFile) -> Callable[[int, int], None]:
    progress_state = {"last_percent": -1, "is_finished": False, "last_line_length": 0}

    def print_progress_line(message: str) -> None:
        padded_message = message
        if len(message) < progress_state["last_line_length"]:
            padded_message = message + (" " * (progress_state["last_line_length"] - len(message)))

        print(f"\r{padded_message}", end="", flush=True)
        progress_state["last_line_length"] = len(message)

    def show_progress(transferred_bytes: int, total_bytes: int) -> None:
        effective_total = total_bytes if total_bytes > 0 else remote_file.size_bytes
        if effective_total <= 0:
            print_progress_line(
                f"Copying {remote_file.filename}: {_format_size(transferred_bytes)} transferred"
            )
            return

        percent_complete = min(int((transferred_bytes / effective_total) * 100), 100)
        if (
            percent_complete == progress_state["last_percent"]
            and transferred_bytes < effective_total
        ):
            return

        progress_state["last_percent"] = percent_complete
        filled_width = int((percent_complete / 100) * PROGRESS_BAR_WIDTH)
        progress_bar = "#" * filled_width + "-" * (PROGRESS_BAR_WIDTH - filled_width)
        print_progress_line(
            (
                f"Copying {remote_file.filename}: "
                f"[{progress_bar}] {percent_complete:3d}% "
                f"({_format_size(transferred_bytes)} / {_format_size(effective_total)})"
            )
        )

        if transferred_bytes >= effective_total and not progress_state["is_finished"]:
            progress_state["is_finished"] = True
            print()

    return show_progress


def _build_private_key_path(settings: ConnectionSettings) -> Path:
    return get_host_directory(settings.host, settings.port, settings.username) / "id_rsa"


def _load_private_key(key_path: Path) -> paramiko.PKey | None:
    if not key_path.exists():
        return None

    return paramiko.RSAKey.from_private_key_file(str(key_path))


def _store_host_profile(settings: ConnectionSettings, key_path: Path) -> None:
    save_connection_profile(
        settings.host,
        settings.port,
        settings.username,
        {
            "host": settings.host,
            "port": settings.port,
            "username": settings.username,
            "private_key": str(key_path),
        },
    )


def _create_client() -> paramiko.SSHClient:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    return client


def _connect_with_password(client: paramiko.SSHClient, settings: ConnectionSettings) -> str:
    logging.info("Passwortanmeldung fuer %s@%s wird verwendet.", settings.username, settings.host)

    for attempt in range(1, MAX_PASSWORD_ATTEMPTS + 1):
        # Mehrere Versuche verhindern, dass die Anwendung bei einem Tippfehler sofort beendet wird.
        password = getpass.getpass(
            prompt=(
                f"Passwort fuer {settings.username}@{settings.host} eingeben "
                f"(Versuch {attempt}/{MAX_PASSWORD_ATTEMPTS}): "
            )
        )
        try:
            client.connect(
                hostname=settings.host,
                port=settings.port,
                username=settings.username,
                password=password,
                timeout=settings.timeout,
                look_for_keys=False,
                allow_agent=False,
            )
            logging.info(
                "Passwortanmeldung fuer %s@%s war erfolgreich im Versuch %s.",
                settings.username,
                settings.host,
                attempt,
            )
            return password
        except paramiko.AuthenticationException:
            logging.warning(
                "Falsches Passwort fuer %s@%s im Versuch %s von %s.",
                settings.username,
                settings.host,
                attempt,
                MAX_PASSWORD_ATTEMPTS,
            )
            if attempt < MAX_PASSWORD_ATTEMPTS:
                print("Das Passwort war nicht korrekt. Bitte erneut versuchen.")

    raise AuthenticationRetriesExceededError(
        "Die maximale Anzahl an Passwortversuchen wurde erreicht."
    )


def _connect_with_cached_password(
    client: paramiko.SSHClient,
    settings: ConnectionSettings,
) -> bool:
    cached_password = load_cached_password(settings.host, settings.port, settings.username)
    if not cached_password:
        return False

    try:
        client.connect(
            hostname=settings.host,
            port=settings.port,
            username=settings.username,
            password=cached_password,
            timeout=settings.timeout,
            look_for_keys=False,
            allow_agent=False,
        )
        logging.info(
            "Gespeichertes Passwort fuer %s@%s wurde erfolgreich verwendet.",
            settings.username,
            settings.host,
        )
        return True
    except paramiko.AuthenticationException:
        logging.warning(
            "Gespeichertes Passwort fuer %s@%s war ungueltig. Interaktive Passwortabfrage wird gestartet.",
            settings.username,
            settings.host,
        )
        return False


def _connect_with_cached_key(
    client: paramiko.SSHClient,
    settings: ConnectionSettings,
    key_path: Path,
) -> bool:
    private_key = _load_private_key(key_path)
    if private_key is None:
        return False

    try:
        client.connect(
            hostname=settings.host,
            port=settings.port,
            username=settings.username,
            pkey=private_key,
            timeout=settings.timeout,
            look_for_keys=False,
            allow_agent=False,
        )
        logging.info(
            "Gespeicherter SSH-Schluessel fuer %s@%s wurde erfolgreich verwendet.",
            settings.username,
            settings.host,
        )
        return True
    except paramiko.AuthenticationException:
        logging.warning(
            "Gespeicherter SSH-Schluessel fuer %s@%s war ungueltig. Passwortabfrage wird gestartet.",
            settings.username,
            settings.host,
        )
        return False


def _ensure_remote_key_authentication(
    client: paramiko.SSHClient,
    settings: ConnectionSettings,
    key_path: Path,
) -> None:
    # Der private Schluessel wird lokal gespeichert, damit spaetere Downloads ohne neue Passworteingabe moeglich sind.
    generated_private_key = paramiko.RSAKey.generate(3072)
    generated_private_key.write_private_key_file(str(key_path))
    logging.info(
        "Neuer lokaler SSH-Schluessel fuer %s@%s wurde erzeugt.",
        settings.username,
        settings.host,
    )

    public_key_text = f"{generated_private_key.get_name()} {generated_private_key.get_base64()}"

    sftp_client = client.open_sftp()
    try:
        ssh_directory = f"/home/{settings.username}/.ssh"
        if settings.username == "root":
            ssh_directory = "/root/.ssh"

        try:
            sftp_client.stat(ssh_directory)
        except FileNotFoundError:
            sftp_client.mkdir(ssh_directory)

        authorized_keys_path = f"{ssh_directory}/authorized_keys"
        existing_content = ""
        try:
            with sftp_client.open(authorized_keys_path, "r") as remote_file:
                existing_content = remote_file.read().decode("utf-8")
        except FileNotFoundError:
            existing_content = ""

        if public_key_text not in existing_content:
            # Vorhandene Eintraege bleiben erhalten, damit keine bestehenden Zugriffe verloren gehen.
            combined_content = f"{existing_content.rstrip()}\n{public_key_text}\n".lstrip()
            with sftp_client.open(authorized_keys_path, "w") as remote_file:
                remote_file.write(combined_content)
            logging.info(
                "Der neue SSH-Schluessel wurde auf der SPS fuer %s@%s hinterlegt.",
                settings.username,
                settings.host,
            )

        sftp_client.chmod(ssh_directory, 0o700)
        sftp_client.chmod(authorized_keys_path, 0o600)
    finally:
        sftp_client.close()

    _store_host_profile(settings, key_path)


def connect_ssh(settings: ConnectionSettings) -> paramiko.SSHClient:
    host_profile = load_connection_profile(settings.host, settings.port, settings.username)
    key_path = Path(host_profile.get("private_key", _build_private_key_path(settings)))
    key_path.parent.mkdir(parents=True, exist_ok=True)

    client = _create_client()

    if settings.use_cache and _connect_with_cached_key(client, settings, key_path):
        return client

    if settings.use_cache and _connect_with_cached_password(client, settings):
        if not key_path.exists():
            _ensure_remote_key_authentication(client, settings, key_path)
        else:
            _store_host_profile(settings, key_path)
        return client

    password = _connect_with_password(client, settings)
    if settings.use_cache:
        save_cached_password(settings.host, settings.port, settings.username, password)
        logging.info(
            "Passwort fuer %s@%s wurde in .credentials.json gespeichert.",
            settings.username,
            settings.host,
        )

    if not key_path.exists():
        _ensure_remote_key_authentication(client, settings, key_path)
    else:
        _store_host_profile(settings, key_path)
        logging.info(
            "Vorhandener lokaler SSH-Schluessel fuer %s@%s bleibt gespeichert.",
            settings.username,
            settings.host,
        )

    return client


def run_remote_live_log_copy(client: paramiko.SSHClient) -> None:
    logging.info(
        "Starte einmalig das SPS-Skript zur Erzeugung der neuesten Live-Logdatei: %s",
        REMOTE_COPY_LIVE_LOG_COMMAND,
    )
    stdin_stream, stdout_stream, stderr_stream = client.exec_command(
        REMOTE_COPY_LIVE_LOG_COMMAND
    )
    stdin_stream.close()
    exit_status = stdout_stream.channel.recv_exit_status()
    standard_error_output = stderr_stream.read().decode("utf-8", errors="replace").strip()

    if exit_status != 0:
        logging.error(
            "Das SPS-Skript %s wurde mit Exit-Code %s beendet. Fehlerausgabe: %s",
            REMOTE_COPY_LIVE_LOG_COMMAND,
            exit_status,
            standard_error_output,
        )
        raise RemoteCommandExecutionError(
            f"Das SPS-Skript {REMOTE_COPY_LIVE_LOG_COMMAND} konnte nicht erfolgreich ausgefuehrt werden."
        )

    logging.info(
        "Das SPS-Skript %s wurde erfolgreich ausgefuehrt.",
        REMOTE_COPY_LIVE_LOG_COMMAND,
    )


def list_remote_log_files(client: paramiko.SSHClient, remote_dir: str) -> list[RemoteLogFile]:
    sftp_client = client.open_sftp()
    try:
        logging.info("Lese Dateien aus dem SPS-Verzeichnis %s.", remote_dir)
        remote_entries = sftp_client.listdir_attr(remote_dir)
        collected_files: list[RemoteLogFile] = []
        for entry in remote_entries:
            if entry.filename in {".", ".."}:
                continue
            if not stat.S_ISREG(entry.st_mode):
                continue
            if entry.filename.lower().endswith(".sh"):
                logging.info(
                    "Datei wird uebersprungen, weil Shell-Skripte nicht kopiert werden: %s",
                    entry.filename,
                )
                continue

            remote_path = f"{remote_dir.rstrip('/')}/{entry.filename}"
            modified_at = datetime.fromtimestamp(entry.st_mtime, tz=timezone.utc)
            collected_files.append(
                RemoteLogFile(
                    filename=entry.filename,
                    remote_path=remote_path,
                    modified_at=modified_at,
                    size_bytes=entry.st_size,
                )
            )

        return collected_files
    finally:
        sftp_client.close()


def download_files(
    client: paramiko.SSHClient,
    files: list[RemoteLogFile],
    target_directory: Path,
) -> list[Path]:
    sftp_client = client.open_sftp()
    try:
        downloaded_paths: list[Path] = []
        for remote_file in files:
            # Es wird bewusst nur der Dateiname lokal verwendet, damit keine Remote-Ordnerstruktur nachgebaut werden muss.
            target_path = target_directory / remote_file.filename
            logging.info(
                "Kopiervorgang gestartet: %s -> %s (%s)",
                remote_file.remote_path,
                target_path,
                _format_size(remote_file.size_bytes),
            )
            sftp_client.get(
                remote_file.remote_path,
                str(target_path),
                callback=_build_progress_callback(remote_file),
            )
            downloaded_paths.append(target_path)
            logging.info(
                "Datei kopiert: %s -> %s",
                remote_file.remote_path,
                target_path,
            )

        return downloaded_paths
    finally:
        sftp_client.close()


def build_error_message(error: Exception) -> str:
    if isinstance(error, AuthenticationRetriesExceededError):
        return "Authentifizierung fehlgeschlagen. Nach 3 Versuchen wurde der Vorgang beendet."
    if isinstance(error, paramiko.AuthenticationException):
        return "Authentifizierung fehlgeschlagen. Bitte Zugangsdaten pruefen."
    if isinstance(error, RemoteCommandExecutionError):
        return "Die aktuelle Live-Logdatei konnte auf der SPS nicht erzeugt werden."
    if isinstance(error, FileNotFoundError):
        return "Das angegebene Log-Verzeichnis wurde auf der SPS nicht gefunden."
    if isinstance(error, socket.timeout):
        return "Zeitueberschreitung beim Verbindungsaufbau zur SPS."
    return f"Unerwarteter Fehler: {error}"
