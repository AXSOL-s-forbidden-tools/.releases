import logging

from functions.args_parser import build_argument_parser
from functions.date_filter import parse_cutoff_date
from functions.file_selection import filter_and_limit_files, select_latest_live_log_file
from functions.logger_setup import prepare_logging
from functions.output import (
    ensure_target_directory,
    prepare_target_directory_for_download,
    print_remote_file_overview,
    print_selected_files,
)
from functions.ssh_client import (
    ConnectionSettings,
    build_error_message,
    connect_ssh,
    download_files,
    list_remote_log_files,
    run_remote_live_log_copy,
)
from functions.versioning import read_tool_version


def main() -> int:
    tool_version = read_tool_version()
    parser = build_argument_parser(tool_version)
    args = parser.parse_args()
    log_file_path = prepare_logging(quiet_console=args.quiet_console)
    logging.info(
        "Tool gestartet. Version: %s. Log-Datei: %s",
        tool_version,
        log_file_path.resolve(),
    )
    logging.info(
        "Aufrufparameter: host=%s port=%s username=%s count=%s before_date=%s remote_dir=%s target_dir=%s no_cache=%s copy_live_log_only=%s list_remote_files_only=%s",
        args.host,
        args.port,
        args.username,
        args.count,
        args.before_date,
        args.remote_dir,
        args.target_dir,
        args.no_cache,
        args.copy_live_log_only,
        args.list_remote_files_only,
    )

    if args.count < 1:
        logging.error("Ungueltige Anzahl angefordert: %s", args.count)
        print("Die Anzahl der Dateien muss mindestens 1 sein.")
        return 1

    try:
        cutoff_date = parse_cutoff_date(args.before_date)
    except ValueError:
        logging.error("Ungueltiges Datumsformat erhalten: %s", args.before_date)
        print("Das Datum muss im Format YYYY-MM-DD angegeben werden.")
        return 1

    settings = ConnectionSettings(
        host=args.host,
        port=args.port,
        username=args.username,
        remote_dir=args.remote_dir,
        timeout=args.timeout,
        use_cache=not args.no_cache,
    )

    client = None
    try:
        client = connect_ssh(settings)
        run_remote_live_log_copy(client)
        remote_files = list_remote_log_files(client, args.remote_dir)
        logging.info("Es wurden %s Dateien im Remote-Verzeichnis gefunden.", len(remote_files))
        if args.list_remote_files_only:
            logging.info("Modus 'list remote files only' ist aktiv.")
            print_remote_file_overview(remote_files, args.remote_dir)
            return 0

        target_directory = ensure_target_directory(args.target_dir)
        if args.copy_live_log_only:
            logging.info("Modus 'copy live log only' ist aktiv.")
            # In diesem Modus wird bewusst nur die neueste erzeugte Live-Logdatei uebernommen.
            selected_files = select_latest_live_log_file(remote_files)
        else:
            selected_files = filter_and_limit_files(remote_files, cutoff_date, args.count)
        logging.info("Es wurden %s Dateien fuer den Download ausgewaehlt.", len(selected_files))
        print_selected_files(selected_files)

        if not selected_files:
            logging.info("Keine passenden Dateien fuer den Download gefunden.")
            return 0

        prepare_target_directory_for_download(target_directory)
        downloaded_files = download_files(client, selected_files, target_directory)
        print("")
        print("Download abgeschlossen:")
        for item in downloaded_files:
            print(f"- {item}")
        logging.info("Download erfolgreich abgeschlossen.")
        return 0
    except Exception as error:
        logging.exception("Fehler waehrend der Ausfuehrung.")
        print(build_error_message(error))
        return 1
    finally:
        if client is not None:
            client.close()
            logging.info("SSH-Verbindung wurde geschlossen.")
