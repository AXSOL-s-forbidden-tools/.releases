import logging
from datetime import datetime
from pathlib import Path


LOG_DIRECTORY = Path("log")
MAX_LOG_DIRECTORY_SIZE_BYTES = 100 * 1024 * 1024
TARGET_LOG_DIRECTORY_SIZE_BYTES = 50 * 1024 * 1024


def prepare_logging(quiet_console: bool = False) -> Path:
    LOG_DIRECTORY.mkdir(parents=True, exist_ok=True)
    _shrink_log_directory_if_needed()

    log_file_path = LOG_DIRECTORY / f"{datetime.now().strftime('%Y-%m-%d')}.log"

    handlers: list[logging.Handler] = [
        logging.FileHandler(log_file_path, encoding="utf-8"),
    ]
    if not quiet_console:
        handlers.append(logging.StreamHandler())

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=handlers,
        force=True,
    )
    return log_file_path


def _shrink_log_directory_if_needed() -> None:
    log_files = [item for item in LOG_DIRECTORY.glob("*.log") if item.is_file()]
    total_size = sum(item.stat().st_size for item in log_files)
    if total_size <= MAX_LOG_DIRECTORY_SIZE_BYTES:
        return

    sorted_files = sorted(log_files, key=lambda item: item.stat().st_mtime)
    for log_file in sorted_files:
        if total_size <= TARGET_LOG_DIRECTORY_SIZE_BYTES:
            break

        file_size = log_file.stat().st_size
        log_file.unlink(missing_ok=True)
        total_size -= file_size
