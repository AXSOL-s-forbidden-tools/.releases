# PLC Log Catcher

`PLC Log Catcher` is a terminal tool for downloading log files from a WAGO PLC via SSH/SFTP. It can copy the latest `x` log files, filter files up to a cutoff date, store them in a configurable local target directory, and write a local execution log for every run.

Current tool version: see [`VERSION`](VERSION)

## Project Description

- Python CLI for retrieving PLC log files
- local storage for connection details and SSH keys per PLC
- local password cache in `.credentials.json` for previously entered PLC connections
- guided startup via batch file for non-technical users
- local Python dependencies stored only in `.env`
- execution logs in `log/` with automatic size control
- shell scripts ending in `.sh` are never copied from the PLC log directory
- `/etc/config-tools/copyLiveLog.sh` is executed once before every download so the latest live log file is available
- the version number is maintained centrally in `VERSION`
- relative target paths such as `.\downloads` are always resolved relative to the tool root
- an optional mode copies only the current live log file
- a numbered preview of the PLC directory is shown before mode, file count, and date selection
- before each download, the user is asked whether the local target directory should be cleared
- if the target directory is kept, files with the same name are overwritten during the copy process
- each active file copy shows a live progress bar with percentage and transferred file size
- refreshed progress lines are padded so no leftover characters remain when the displayed size text becomes shorter

## Setup

### Start via Batch File

The simplest option is a double-click on:

```bat
start_plc_log_catcher.bat
```

The batch file:

- checks whether Python is installed
- offers installation via `winget` when needed
- creates a local virtual environment in `.env`
- installs missing Python packages only locally
- starts a guided input flow
- writes execution logs to `log/YYYY-MM-DD.log`
- shows the current tool version from `VERSION`
- uses `.\downloads` as the default target directory and accepts it with Enter
- logs batch errors before Python starts in the same daily log file
- opens the target directory in Windows Explorer after a successful run

### Manual Start

```powershell
python -m venv .env
.\.env\Scripts\python.exe -m pip install -r requirements.txt
.\.env\Scripts\python.exe app.py --host 192.168.1.10 --username root --count 5 --target-dir .\downloads
```

## Important Commands

```powershell
.\start_plc_log_catcher.bat
.\.env\Scripts\python.exe app.py --help
.\.env\Scripts\python.exe app.py --host 192.168.1.10 --username root --count 10 --before-date 2026-05-01 --target-dir .\downloads
.\.env\Scripts\python.exe app.py --host 192.168.1.10 --username root --copy-live-log-only --target-dir .\downloads
.\.env\Scripts\python.exe app.py --host 192.168.1.10 --username root --list-remote-files-only
```

## Usage

### Guided Mode

1. Start `start_plc_log_catcher.bat`.
2. Answer the prompts for PLC address, user, log directory, file count, date, and target directory.
3. Before mode, count, and date selection, the tool shows a numbered preview of the files currently available in the PLC directory.
4. For the target directory, `.\downloads` can be accepted with a simple Enter key press.
5. For TAB completion on local subdirectories, use a Windows path with backslashes such as `.\downloads\pfc100`.
6. You can optionally choose to copy only the current live log file.
7. During the first connection, the password is requested, stored locally in `.credentials.json`, and the local SSH key is requested or created as needed. Up to three retries are allowed for an incorrect password.
8. Before copying, the tool executes `/etc/config-tools/copyLiveLog.sh` once on the PLC.
9. If the local target directory is not empty, the tool asks whether its content should be deleted first.
10. If the directory is not cleared, files with the same name are overwritten while other files remain untouched.
11. The selected log files are copied to the target directory, and each active transfer shows a live progress bar with percentage and current file size.
12. After a successful run, the target directory is opened automatically in Windows Explorer.
13. The execution is documented in `log/`.

### CLI Mode

```powershell
.\.env\Scripts\python.exe app.py `
  --host 192.168.1.10 `
  --username root `
  --count 20 `
  --before-date 2026-05-01 `
  --remote-dir /home/logging `
  --target-dir .\downloads
```

More details are available in [docs/architecture.md](docs/architecture.md) and [docs/development.md](docs/development.md).

## Logging

- One log file per day is written to `log/YYYY-MM-DD.log`.
- Logged information includes start time, selected parameters, copied files, errors, and whether a password or stored key was used.
- Previously entered passwords are stored locally in `.credentials.json` and can be reused on later runs when the cache is enabled.
- Batch events before Python starts are also written to `log/YYYY-MM-DD.log`.
- The call to `/etc/config-tools/copyLiveLog.sh` is logged before file download begins.
- The PLC directory preview shown before selection is also logged.
- The decision to clear or keep a non-empty target directory is logged as well.
- Files ending in `.sh` are excluded before download and logged as skipped.
- In `copy live log only` mode, only the newest file matching `_runtimelog_live.log` is copied.
- Up to three authentication retries are allowed before the run is aborted.
- If `log/` grows beyond 100 MB, the oldest log files are deleted until the directory is below 50 MB again.
