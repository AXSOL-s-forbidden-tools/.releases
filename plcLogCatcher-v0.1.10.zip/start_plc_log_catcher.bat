@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
set "PROJECT_ROOT=%SCRIPT_DIR%"
set "LOG_DIR=%PROJECT_ROOT%log"
set "LOG_FILE=%LOG_DIR%\%date:~6,4%-%date:~3,2%-%date:~0,2%.log"
set "PYTHON_EXE="
set "VENV_PYTHON=%PROJECT_ROOT%.env\Scripts\python.exe"
set "TOOL_VERSION=unbekannt"
set "HOST_VALUE="
set "USERNAME_VALUE=root"
set "PORT_VALUE=22"
set "REMOTE_DIR_VALUE=/home/logging"
set "COUNT_VALUE=10"
set "BEFORE_DATE_VALUE="
set "TARGET_DIR_VALUE=.\downloads"
set "COPY_LIVE_LOG_ONLY_VALUE=n"

call :prepare_log_directory
call :read_tool_version
call :log_info "Batch-Start initialisiert. Version %TOOL_VERSION%."
call :ensure_python || goto :finish
call :ensure_local_environment || goto :finish
call :collect_inputs
call :run_tool

:finish
if "%PYTHON_EXIT_CODE%"=="0" (
    call :open_target_directory
)
call :log_info "Batch-Datei wird beendet."
echo.
pause
endlocal
exit /b

:prepare_log_directory
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"
exit /b 0

:ensure_python
where python >nul 2>nul
if %errorlevel%==0 (
    call :log_info "Python wurde im Systempfad gefunden."
    set "PYTHON_EXE=python"
    exit /b 0
)

call :log_warning "Python wurde nicht gefunden. Rueckfrage zur Installation wird angezeigt."
set /p INSTALL_PYTHON=Python wurde nicht gefunden. Moechten Sie Python 3.12 per winget nachinstallieren? [y/n]:
if /i not "%INSTALL_PYTHON%"=="y" (
    call :log_error "Python-Installation wurde vom Benutzer abgelehnt."
    echo Python ist erforderlich, um das Tool zu starten.
    exit /b 1
)

call :log_info "Python-Installation per winget wird gestartet."
winget install Python.Python.3.12
where python >nul 2>nul
if not %errorlevel%==0 (
    call :log_error "Python wurde nach der Installation nicht im Systempfad gefunden."
    echo Python wurde nach der Installation noch nicht gefunden. Bitte Konsole neu starten.
    exit /b 1
)

call :log_info "Python wurde erfolgreich installiert und gefunden."
set "PYTHON_EXE=python"
exit /b 0

:ensure_local_environment
if not exist "%VENV_PYTHON%" (
    call :log_info "Lokale Python-Umgebung wird neu erstellt."
    "%PYTHON_EXE%" -m venv "%PROJECT_ROOT%.env"
    if errorlevel 1 (
        call :log_error "Die lokale Python-Umgebung konnte nicht erstellt werden."
        exit /b 1
    )
)

call :log_info "Lokale Python-Abhaengigkeiten werden aktualisiert."
"%VENV_PYTHON%" -m pip install --upgrade pip
if errorlevel 1 (
    call :log_error "pip konnte nicht aktualisiert werden."
    exit /b 1
)

"%VENV_PYTHON%" -m pip install -r "%PROJECT_ROOT%requirements.txt"
if errorlevel 1 (
    call :log_error "Die benoetigten Python-Abhaengigkeiten konnten nicht installiert werden."
    exit /b 1
)
call :log_info "Lokale Python-Umgebung ist betriebsbereit."
exit /b 0

:collect_inputs
echo.
echo PLC Log Catcher Version %TOOL_VERSION%
echo ----------------
echo Relative Zielpfade beginnen immer im Tool-Hauptverzeichnis.
echo Fuer die TAB-Vervollstaendigung bei lokalen Ordnern bitte Windows-Pfade mit Backslash verwenden, z. B. .\downloads\pfc100
echo Fuer das Standard-Zielverzeichnis reicht ein einfacher Enter-Tastendruck.
set /p HOST_VALUE=IP-Adresse oder Hostname der SPS:
call :read_with_default "Benutzername" "root" USERNAME_VALUE
call :read_with_default "SSH-Port" "22" PORT_VALUE
call :read_with_default "Log-Verzeichnis auf der SPS" "/home/logging" REMOTE_DIR_VALUE
call :show_remote_files || goto :finish
call :read_with_default "Nur aktuelle Live-Log kopieren? [y/n]" "n" COPY_LIVE_LOG_ONLY_VALUE
if /i "%COPY_LIVE_LOG_ONLY_VALUE%"=="y" (
    set "COUNT_VALUE=1"
    set "BEFORE_DATE_VALUE="
    call :log_info "Benutzerauswahl: Nur aktuelle Live-Logdatei kopieren."
) else (
    call :read_with_default "Wie viele Dateien sollen kopiert werden" "10" COUNT_VALUE
    call :read_optional_value "Nur Dateien bis Datum YYYY-MM-DD, leer = kein Filter" BEFORE_DATE_VALUE
    call :log_info "Benutzerauswahl: Allgemeiner Downloadmodus mit count=%COUNT_VALUE% und before_date=%BEFORE_DATE_VALUE%."
)
call :read_with_default "Lokales Zielverzeichnis" ".\downloads" TARGET_DIR_VALUE
call :normalize_local_target_dir TARGET_DIR_VALUE
call :log_info "Benutzereingaben erfasst: host=%HOST_VALUE% username=%USERNAME_VALUE% port=%PORT_VALUE% remote_dir=%REMOTE_DIR_VALUE% target_dir=%TARGET_DIR_VALUE% live_only=%COPY_LIVE_LOG_ONLY_VALUE%."
exit /b 0

:show_remote_files
echo.
echo Verfuegbare Dateien auf der SPS werden geladen...
"%VENV_PYTHON%" "%PROJECT_ROOT%app.py" --host "%HOST_VALUE%" --username "%USERNAME_VALUE%" --port "%PORT_VALUE%" --remote-dir "%REMOTE_DIR_VALUE%" --list-remote-files-only --quiet-console
set "PREVIEW_EXIT_CODE=%errorlevel%"
if not "%PREVIEW_EXIT_CODE%"=="0" (
    echo Die Dateivorschau konnte nicht geladen werden.
    exit /b %PREVIEW_EXIT_CODE%
)
exit /b 0

:run_tool
echo.
if /i "%COPY_LIVE_LOG_ONLY_VALUE%"=="y" (
    call :log_info "Python-Tool wird im Modus copy-live-log-only gestartet."
    "%VENV_PYTHON%" "%PROJECT_ROOT%app.py" --host "%HOST_VALUE%" --username "%USERNAME_VALUE%" --port "%PORT_VALUE%" --remote-dir "%REMOTE_DIR_VALUE%" --count "1" --copy-live-log-only --target-dir "%TARGET_DIR_VALUE%" --quiet-console
) else (
    if "%BEFORE_DATE_VALUE%"=="" (
        call :log_info "Python-Tool wird im Standardmodus ohne Datumsfilter gestartet."
        "%VENV_PYTHON%" "%PROJECT_ROOT%app.py" --host "%HOST_VALUE%" --username "%USERNAME_VALUE%" --port "%PORT_VALUE%" --remote-dir "%REMOTE_DIR_VALUE%" --count "%COUNT_VALUE%" --target-dir "%TARGET_DIR_VALUE%" --quiet-console
    ) else (
        call :log_info "Python-Tool wird im Standardmodus mit Datumsfilter gestartet."
        "%VENV_PYTHON%" "%PROJECT_ROOT%app.py" --host "%HOST_VALUE%" --username "%USERNAME_VALUE%" --port "%PORT_VALUE%" --remote-dir "%REMOTE_DIR_VALUE%" --count "%COUNT_VALUE%" --before-date "%BEFORE_DATE_VALUE%" --target-dir "%TARGET_DIR_VALUE%" --quiet-console
    )
)
set "PYTHON_EXIT_CODE=%errorlevel%"
if not "%PYTHON_EXIT_CODE%"=="0" (
    call :log_error "Das Python-Tool wurde mit einem Fehler beendet. Exit-Code %PYTHON_EXIT_CODE%."
) else (
    call :log_info "Das Python-Tool wurde erfolgreich beendet."
)
exit /b %PYTHON_EXIT_CODE%

:open_target_directory
if not defined TARGET_DIR_VALUE exit /b 0
set "OPEN_TARGET_DIR=%TARGET_DIR_VALUE%"
pushd "%PROJECT_ROOT%" >nul
for %%I in ("%OPEN_TARGET_DIR%") do set "OPEN_TARGET_DIR=%%~fI"
popd >nul
if not exist "%OPEN_TARGET_DIR%" exit /b 0
call :log_info "Zielverzeichnis wird im Explorer geoeffnet: %OPEN_TARGET_DIR%"
start "" /d "%OPEN_TARGET_DIR%" explorer.exe .
exit /b 0

:read_tool_version
if exist "%PROJECT_ROOT%VERSION" (
    set /p TOOL_VERSION=<"%PROJECT_ROOT%VERSION"
)
exit /b 0

:read_with_default
set "PROMPT_TEXT=%~1"
set "DEFAULT_VALUE=%~2"
set "TARGET_VARIABLE=%~3"
set "USER_VALUE="
set /p USER_VALUE=%PROMPT_TEXT% [%DEFAULT_VALUE%]:
if "%USER_VALUE%"=="" (
    set "%TARGET_VARIABLE%=%DEFAULT_VALUE%"
) else (
    set "%TARGET_VARIABLE%=%USER_VALUE%"
)
exit /b 0

:read_optional_value
set "PROMPT_TEXT=%~1"
set "TARGET_VARIABLE=%~2"
set "USER_VALUE="
rem Diese Abfrage liegt in einer eigenen Funktion, damit Klammern im Prompt keinen IF-Block beim Parsen zerlegen.
set /p USER_VALUE=%PROMPT_TEXT%:
set "%TARGET_VARIABLE%=%USER_VALUE%"
exit /b 0

:normalize_local_target_dir
set "TARGET_VARIABLE=%~1"
call set "NORMALIZED_VALUE=%%%TARGET_VARIABLE%%%"
set "NORMALIZED_VALUE=%NORMALIZED_VALUE:/=\%"
set "%TARGET_VARIABLE%=%NORMALIZED_VALUE%"
exit /b 0

:log_info
call :write_log INFO "%~1"
exit /b 0

:log_warning
call :write_log WARNING "%~1"
exit /b 0

:log_error
call :write_log ERROR "%~1"
exit /b 0

:write_log
>>"%LOG_FILE%" echo %date% %time% ^| %~1 ^| %~2
exit /b 0
