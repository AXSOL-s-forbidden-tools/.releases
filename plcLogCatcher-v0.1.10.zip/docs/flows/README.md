# Flows

In diesem Ordner koennen spaeter wichtige Ablaufbeschreibungen dokumentiert werden, zum Beispiel der Download-Ablauf oder die Behandlung gespeicherter SPS-Zugaenge.
