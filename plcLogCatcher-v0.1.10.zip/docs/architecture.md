# Architektur

## Überblick

Das Tool besteht aus einer kleinen Python-CLI, einer lokalen Cache-Struktur für bekannte SPS-Verbindungen, einer reinen Batch-Einstiegsdatei für die geführte Nutzung unter Windows und einem lokalen Laufprotokoll.

```mermaid
flowchart TD
  A[Batch-Datei] --> B[Python-Umgebung in .env]
  B --> C[CLI app.py]
  C --> D[SSH Verbindung zur SPS]
  D --> E[Log-Dateien in /home/logging]
  C --> F[Lokales Zielverzeichnis]
  C --> G[Lokaler Verbindungs-Cache]
  C --> H[Lokaler Log-Ordner]
```

## Bausteine

- `start_plc_log_catcher.bat`: einfacher Start per Doppelklick inklusive Benutzerführung
- `app.py`: Einstiegspunkt für die CLI
- `functions/`: kleine Fachmodule für Argumente, Auswahl, Ausgabe, Datum und SSH
- `.plc_log_catcher/hosts/...`: lokaler Cache für bekannte Verbindungen und erzeugte Schlüssel
- `log/`: Tagesprotokolle mit automatischer Bereinigung bei Größenüberschreitung
- `VERSION`: zentrale Versionsnummer für Batch, CLI und Logging
- relative Zielpfade werden im Python-Code immer gegen das Tool-Hauptverzeichnis aufgelöst

## Datenfluss

1. Die Batch-Datei prüft Python und die lokale `.env`-Umgebung.
2. Die CLI initialisiert das Tageslog und bereinigt bei Bedarf alte Protokolle.
3. Die CLI baut per SSH/SFTP eine Verbindung zur SPS auf.
4. Vor dem Lesen des Log-Verzeichnisses wird `/etc/config-tools/copyLiveLog.sh` auf der SPS ausgeführt.
5. Beim ersten erfolgreichen Passwort-Login wird ein lokaler Schlüssel erzeugt und auf der SPS hinterlegt.
6. Auf Wunsch wird zunächst eine reine Dateivorschau des SPS-Verzeichnisses angezeigt.
7. Je nach Modus wird entweder nur die neueste Live-Logdatei oder eine allgemeine Dateiauswahl ermittelt.
8. Die ausgewählten Dateien werden in das lokale Zielverzeichnis kopiert.
9. Kopierte Dateien, Fehler und Verbindungsart werden im Log festgehalten.
