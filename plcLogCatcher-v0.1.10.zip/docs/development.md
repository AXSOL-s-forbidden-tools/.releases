# Entwicklung

## Lokale Entwicklung

```powershell
python -m venv .env
.\.env\Scripts\python.exe -m pip install -r requirements.txt
.\.env\Scripts\python.exe app.py --help
```

## Wichtige Hinweise

- Das Referenzprojekt unter `install_tool/` dient nur zur Recherche und bleibt unverändert.
- Python-Abhängigkeiten werden nur lokal im Ordner `.env` installiert.
- Bekannte SPS-Verbindungen und lokale Schlüssel liegen unter `.plc_log_catcher/`.
- Laufprotokolle liegen unter `log/` und werden automatisch begrenzt.
- Passwortanmeldungen werden bei Fehleingaben bis zu drei Mal wiederholt.
- Dateien mit der Endung `.sh` werden aus dem Remote-Verzeichnis nicht in die Auswahl aufgenommen.
- Vor jeder Dateiliste wird auf der SPS `/etc/config-tools/copyLiveLog.sh` ausgeführt, damit die neueste Live-Logdatei vorhanden ist.
- Die Tool-Version wird ausschließlich in der Datei `VERSION` gepflegt.
- Relative Zielpfade wie `.\downloads` werden immer gegen das Tool-Hauptverzeichnis aufgelöst.
- Mit `--copy-live-log-only` wird nur die neueste Live-Logdatei kopiert.
- Mit `--list-remote-files-only` wird nur die aktuelle Dateiliste des SPS-Verzeichnisses angezeigt.
- Fehler im Batch-Start werden ebenfalls in `log/YYYY-MM-DD.log` protokolliert.
- Prompt-Texte mit Klammern liegen in eigenen Batch-Hilfsfunktionen, damit `cmd` keine IF-Bloecke beim Parsen beschaedigt.

## Manuelle Prüfung

```powershell
.\start_plc_log_catcher.bat
.\.env\Scripts\python.exe app.py --host 192.168.1.10 --username root --count 5 --target-dir .\downloads
.\.env\Scripts\python.exe app.py --host 192.168.1.10 --username root --copy-live-log-only --target-dir .\downloads
.\.env\Scripts\python.exe app.py --host 192.168.1.10 --username root --list-remote-files-only
```

## Erweiterungsideen

- optionale Dateinamen-Filter
- Protokolldatei für erfolgreiche und fehlgeschlagene Downloads
- Export einer einfachen CSV-Übersicht der kopierten Dateien
