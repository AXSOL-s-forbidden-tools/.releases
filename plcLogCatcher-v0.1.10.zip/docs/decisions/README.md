# Decisions

In diesem Ordner koennen Architekturentscheidungen als kurze ADRs festgehalten werden, falls sich das Tool spaeter funktional erweitert.
