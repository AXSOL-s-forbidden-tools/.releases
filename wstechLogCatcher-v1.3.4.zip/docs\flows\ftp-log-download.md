# FTP-Log-Download

```mermaid
sequenceDiagram
  participant U as Benutzer
  participant B as Batch-Datei
  participant V as Virtuelle Umgebung
  participant M as main.py
  participant I as Interaktive Eingabe
  participant S as Credential Store
  participant F as FTP-Server
  participant D as Zielordner

  U->>B: Doppelklick auf start_log_catcher.bat
  alt Python fehlt
    B->>U: Installation ueber winget anbieten
  end
  B->>V: .venv erstellen und Pakete installieren
  B->>M: Python-Skript starten
  alt Start ohne Parameter
    M->>I: Eingaben abfragen
    I-->>M: IP, Port, Quelle
  end
  M->>S: Gespeicherte Zugangsdaten laden
  alt Zugangsdaten fehlen oder sind ungueltig
    M->>U: Username und Password abfragen
    M->>S: Neue Zugangsdaten speichern
  end
  M->>F: Verbindung aufbauen und gewaehlten Ordner /Log oder /TR oeffnen
  F-->>M: Dateiliste zurueckgeben
  M->>U: 10 neueste CSV-Dateien anzeigen
  alt Start ohne Parameter
    M->>I: Tage und Zielordner abfragen
    I-->>M: Tage, Zielordner
  end
  M->>M: CSV-Dateien nach Zeitstempel filtern
  loop Fuer jede passende Datei
    M->>D: Datei herunterladen
    M->>U: Fortschritt und Ueberschreiben melden
  end
  M->>U: Zusammenfassung ausgeben
```

## Ablaufbeschreibung

Der Benutzer startet das Skript ueber die Kommandozeile. Danach prueft das Skript zuerst, ob fuer das gewuenschte FTP-Ziel bereits Zugangsdaten gespeichert wurden. Wenn die Verbindung damit nicht gelingt, werden neue Zugangsdaten abgefragt.

Nach erfolgreicher Verbindung liest das Skript alle `*.csv` Dateien im gewaehlten FTP-Ordner `/Log` oder `/TR`. Fuer die Filterung nutzt es zuerst den Zeitstempel im Dateinamen, auch wenn nach der Uhrzeit noch ein Suffix wie `_TR` folgt, und faellt falls noetig auf den Aenderungszeitpunkt des FTP-Servers zurueck.
