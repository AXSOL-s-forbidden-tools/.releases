# wstechLogCatcher

Small Python utility for downloading CSV log files from an FTP server.

The script connects to a configurable FTP target, reads all `*.csv` files from the `Log` or `TR` FTP folder, filters files by their timestamp, and copies only the files from the last `x` days into a target directory.

## Prerequisites

- Python 3.10 or newer
- Access to an FTP server with log files under `/Log/` or `/TR/`

## Setup

No additional Python dependencies are required.
For an easy Windows start, the project creates a local virtual environment under `.venv` when needed.

## Important Commands

Check syntax:

```powershell
python -m py_compile main.py functions\*.py
```

Download log files from `Log`:

```powershell
python main.py --ip 192.168.1.10 --days 7 --target C:\Logs
```

Use a custom FTP port:

```powershell
python main.py --ip 192.168.1.10 --port 21 --days 3 --target C:\Logs
```

Download log files from `TR`:

```powershell
python main.py --ip 192.168.1.10 --source TR --days 3 --target C:\Logs
```

Start in interactive mode without parameters:

```powershell
python main.py
```

Start with a Windows double click:

```text
start_log_catcher.bat
```

## Usage

On the first run, the script asks for `username` and `password`. The values are stored locally per FTP target in `.ftp_credentials.json`.

If a stored credential pair no longer works, the script asks again and updates the saved entry.

During the download, the script shows:

- a small activity log in the console
- the progress across all selected files
- a live progress bar per file with percentage and transferred size
- a notice when an existing target file will be overwritten

For the time filter, the script first tries to read the timestamp from the filename. This also works for filenames that add an extra suffix after the time segment, such as `_TR.csv`. If no matching timestamp is present, it falls back to the file modification time reported by the FTP server.

For users without command line experience, `start_log_catcher.bat` can be started with a double click on Windows. The interactive flow first asks whether files should be loaded from `Log` or `TR`, then asks for the number of days.
Before the day range is entered, the interactive flow also shows the latest 10 CSV files from the selected FTP folder.
If no target directory is entered, the simple start uses `C:/temp/logs` automatically.
If Python is missing, the batch file offers to install it through `winget`.
After that, a local `.venv` environment is created and the packages listed in `requirements.txt` are installed automatically.
The batch file starts the project through its own local `.venv` Python executable and does not require manual activation of the environment.
The complete release package must be extracted before starting the batch file, because `main.py` and `requirements.txt` must be present next to it.

## Documentation

Additional project information is available under `docs/`:

- `docs/architecture.md`
- `docs/development.md`
- `docs/flows/ftp-log-download.md`
- `docs/decisions/0001-dokumentationsstruktur.md`

Local planning files under `task/` or `tasks/` are intentionally excluded from version control and release packages.
