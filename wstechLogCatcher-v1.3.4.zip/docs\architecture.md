# Architektur

## Ueberblick

Dieses Projekt besteht bewusst aus wenigen, klar getrennten Python-Modulen.

```mermaid
flowchart TD
  X[start_log_catcher.bat] --> Y[.venv]
  X --> A[main.py]
  A[main.py] --> B[credential_store.py]
  A --> C[interactive_mode.py]
  A --> D[ftp_download.py]
  A --> E[console_output.py]
  D --> E
```

## Module

### `start_log_catcher.bat`

Prueft unter Windows, ob Python vorhanden ist. Falls nicht, kann die Batch-Datei eine Installation ueber `winget` anstossen. Danach wird eine lokale virtuelle Umgebung erstellt und das Python-Skript darin gestartet.

### `main.py`

Steuert den gesamten Ablauf:

- Kommandozeilenargumente lesen
- Zielordner vorbereiten
- Zugangsdaten laden oder abfragen
- FTP-Verbindung pruefen
- passende Logdateien herunterladen
- Abschlussausgabe erzeugen

### `functions/credential_store.py`

Verwaltet gespeicherte Zugangsdaten je FTP-Ziel in der Datei `.ftp_credentials.json`.

### `functions/interactive_mode.py`

Fragt die wichtigsten Eingaben direkt in der Konsole ab, wenn das Skript ohne Parameter gestartet wird. Dadurch ist ein einfacher Windows-Start per Doppelklick moeglich.

### `.venv`

Die lokale Python-Umgebung trennt das Projekt von anderen Python-Installationen auf dem Rechner. Das reduziert Probleme mit fehlenden oder falschen Paketversionen.

### `functions/ftp_download.py`

Enthaelt die Fachlogik fuer:

- Aufbau der FTP-Verbindung
- Wechsel in den ausgewaehlten Ordner `/Log` oder `/TR`
- Erkennen passender CSV-Dateien
- Filtern nach Zeitstempel aus Dateiname oder FTP-Metadaten
- Download und Ueberschreib-Logik

### `functions/console_output.py`

Kapselt die Konsolenausgabe, damit Fortschritt und Statusmeldungen zentral gepflegt werden.

## Datenfluss

1. Das Skript wird mit IP-Adresse, Port, Log-Quelle, Anzahl Tage und Zielordner gestartet.
2. Gespeicherte Zugangsdaten werden gesucht.
3. Falls keine gueltigen Zugangsdaten vorhanden sind, fragt das Skript neue Daten ab.
4. Das Skript verbindet sich mit dem FTP-Server und liest den gewaehlten Ordner `/Log` oder `/TR`.
5. CSV-Dateien werden anhand des gewuenschten Zeitraums gefiltert. Dabei wird zuerst der Zeitstempel im Dateinamen verwendet, auch wenn nach der Uhrzeit noch ein Suffix wie `_TR` folgt. Bei Bedarf wird auf FTP-Metadaten zurueckgegriffen.
6. Passende Dateien werden in den Zielordner geladen und bei Namensgleichheit ueberschrieben.
