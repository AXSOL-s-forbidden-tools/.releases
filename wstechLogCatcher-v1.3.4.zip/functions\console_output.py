from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from functions.ftp_download import DownloadResult

PROGRESS_BAR_WIDTH = 28
_last_progress_line_length = 0


def print_header(ip: str, port: int, source: str, days: int, target_directory: Path) -> None:
    print("Starte FTP-Log-Abruf")
    print(f"Quelle: {ip}:{port}/{source}/")
    print(f"Zeitraum: letzte {days} Tage")
    print(f"Zielordner: {target_directory}")
    print("-" * 60)


def print_progress(current: int, total: int, filename: str) -> None:
    print(f"[{current}/{total}] Verarbeite {filename}")


def print_file_copy_progress(filename: str, transferred_bytes: int, total_bytes: int | None) -> None:
    global _last_progress_line_length

    transferred_text = format_byte_size(transferred_bytes)
    if total_bytes is None or total_bytes <= 0:
        line = f"  -> Copying {filename}: {transferred_text}"
        print(render_progress_line(line), end="", flush=True)
        return

    percent = min(100, int((transferred_bytes / total_bytes) * 100))
    total_text = format_byte_size(total_bytes)
    progress_bar = build_progress_bar(percent)
    line = (
        f"  -> Copying {filename}: {progress_bar} {percent:3d}% "
        f"({transferred_text} / {total_text})"
    )
    print(render_progress_line(line), end="", flush=True)


def finish_file_copy_progress() -> None:
    global _last_progress_line_length

    print()
    _last_progress_line_length = 0


def print_activity(message: str) -> None:
    print(f"  -> {message}")


def print_recent_files_preview(source: str, recent_files: list[tuple[str, str]]) -> None:
    print("-" * 60)
    print(f"Latest files in /{source}")

    if not recent_files:
        print("  No CSV files found.")
        print("-" * 60)
        return

    for index, (filename, timestamp_text) in enumerate(recent_files, start=1):
        print(f"  {index:2d}. {timestamp_text}  {filename}")

    print("-" * 60)


def print_summary(result: "DownloadResult") -> None:
    print("-" * 60)
    print("Fertig")
    print(f"Gefundene Dateien: {result.found_files}")
    print(f"Heruntergeladene Dateien: {result.downloaded_files}")
    print(f"Ueberschriebene Dateien: {result.overwritten_files}")


def format_byte_size(size_in_bytes: int) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    size = float(size_in_bytes)

    for unit in units:
        if size < 1024 or unit == units[-1]:
            if unit == "B":
                return f"{int(size)} {unit}"
            return f"{size:.1f} {unit}"
        size /= 1024


def build_progress_bar(percent: int) -> str:
    filled_width = int((percent / 100) * PROGRESS_BAR_WIDTH)
    empty_width = PROGRESS_BAR_WIDTH - filled_width
    return f"[{'#' * filled_width}{'-' * empty_width}]"


def render_progress_line(line: str) -> str:
    global _last_progress_line_length

    padding = max(0, _last_progress_line_length - len(line))
    _last_progress_line_length = len(line)
    return f"\r{line}{' ' * padding}"
