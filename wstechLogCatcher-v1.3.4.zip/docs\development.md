# Entwicklung

## Voraussetzungen

- Python 3.10 oder neuer
- FTP-Zugang zu einem Zielsystem mit Logdateien unter `/Log` oder `/TR`

## Lokaler Start

Beispiel:

```powershell
python main.py --ip 192.168.1.10 --days 7 --target C:\Logs
```

Beispiel fuer den Ordner `TR`:

```powershell
python main.py --ip 192.168.1.10 --source TR --days 3 --target C:\Logs
```

Interaktiv ohne Parameter:

```powershell
python main.py
```

Mit abweichendem Port:

```powershell
python main.py --ip 192.168.1.10 --port 21 --days 3 --target C:\Logs
```

Unter Windows gibt es zusaetzlich `start_log_catcher.bat`. Diese Datei kann per Doppelklick gestartet werden und oeffnet einen einfachen Eingabedialog in der Konsole.
Dabei wird zuerst die Log-Quelle `Log` oder `TR` abgefragt. Danach zeigt das Skript die aktuellsten 10 CSV-Dateien aus dem gewaehlten FTP-Ordner an und fragt erst anschliessend die Anzahl der Tage ab.
Wenn beim Zielordner keine Eingabe erfolgt, wird automatisch `C:/temp/logs` verwendet.
Wenn Python fehlt, bietet die Batch-Datei eine Installation ueber `winget` an. Anschliessend wird automatisch eine lokale `.venv`-Umgebung vorbereitet und `requirements.txt` installiert.

## Wichtige Dateien

- `main.py`: Einstiegspunkt
- `functions/credential_store.py`: lokale Zugangsdatenverwaltung
- `functions/interactive_mode.py`: Eingaben fuer den einfachen Start ohne Parameter
- `functions/ftp_download.py`: FTP-Logik und Dateifilterung
- `functions/console_output.py`: Konsolenmeldungen
- `start_log_catcher.bat`: einfacher Windows-Start mit Python- und Umgebungspruefung
- `requirements.txt`: zentrale Liste fuer kuenftig benoetigte Python-Pakete

## Qualitaetssicherung

Syntaxpruefung:

```powershell
python -m py_compile main.py functions\__init__.py functions\console_output.py functions\credential_store.py functions\ftp_download.py functions\interactive_mode.py
```

## Hinweise

- Die Datei `.ftp_credentials.json` enthaelt lokal gespeicherte Zugangsdaten und ist nicht fuer das Repository gedacht.
- Der Zielordner wird automatisch erstellt, wenn er noch nicht existiert.
- Bereits vorhandene Dateien mit gleichem Namen werden bewusst ueberschrieben.
- Fuer die Tagesfilterung wird bevorzugt der Zeitstempel im Dateinamen verwendet. Wenn dieser fehlt, wird der Aenderungszeitpunkt vom FTP-Server verwendet.
