from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timedelta
from ftplib import FTP, all_errors
from pathlib import Path
import re
from time import monotonic

from functions.console_output import (
    finish_file_copy_progress,
    print_activity,
    print_file_copy_progress,
    print_progress,
)

LOG_DIRECTORIES = {
    "Log": "/Log",
    "TR": "/TR",
}
CSV_FILE_PATTERN = re.compile(r"(?i)\.csv$")
LOG_PATTERN = re.compile(
    r"^(?P<prefix>.+)_(?P<date>\d{8})_(?P<time>\d{6})(?P<suffix>_[^.]+)?\.csv$"
)
PREVIEW_TIMESTAMP_FORMAT = "%Y-%m-%d %H:%M:%S"


@dataclass
class DownloadResult:
    found_files: int
    downloaded_files: int
    overwritten_files: int


@contextmanager
def connect_ftp(ip: str, port: int, username: str, password: str):
    ftp = FTP()
    print_activity(f"Verbinde zu {ip}:{port}")
    try:
        ftp.connect(host=ip, port=port, timeout=15)
        ftp.login(user=username, passwd=password)
        print_activity("FTP-Verbindung aufgebaut")
        yield ftp
    finally:
        try:
            ftp.quit()
        except all_errors:
            ftp.close()


def resolve_log_directory(source: str) -> str:
    try:
        return LOG_DIRECTORIES[source]
    except KeyError as error:
        raise ValueError(f"Unbekannte Log-Quelle: {source}") from error


def parse_timestamp_from_filename(filename: str) -> datetime | None:
    match = LOG_PATTERN.match(filename)
    if match is None:
        return None

    timestamp_text = f"{match.group('date')}{match.group('time')}"
    try:
        return datetime.strptime(timestamp_text, "%Y%m%d%H%M%S")
    except ValueError:
        return None


def is_csv_file(filename: str) -> bool:
    return CSV_FILE_PATTERN.search(filename) is not None


def get_file_timestamp(ftp: FTP, filename: str) -> datetime | None:
    timestamp_from_name = parse_timestamp_from_filename(filename)
    if timestamp_from_name is not None:
        return timestamp_from_name

    try:
        modification_response = ftp.voidcmd(f"MDTM {filename}")
    except all_errors:
        return None

    parts = modification_response.split(maxsplit=1)
    if len(parts) != 2:
        return None

    try:
        return datetime.strptime(parts[1], "%Y%m%d%H%M%S")
    except ValueError:
        return None


def list_recent_log_files(ftp: FTP, source: str, days: int) -> list[str]:
    file_entries = list_csv_files_with_timestamps(ftp, source)
    cutoff = datetime.now() - timedelta(days=days)

    selected_files: list[str] = []
    for filename, timestamp in file_entries:
        if timestamp is None:
            continue

        if timestamp >= cutoff:
            selected_files.append(filename)

    selected_files.sort()
    print_activity(f"{len(selected_files)} passende Logdateien gefunden")
    return selected_files


def list_latest_log_files(ftp: FTP, source: str, limit: int = 10) -> list[tuple[str, str]]:
    file_entries = list_csv_files_with_timestamps(ftp, source)
    file_entries.sort(key=sort_key_for_latest_files, reverse=True)

    latest_files: list[tuple[str, str]] = []
    for filename, timestamp in file_entries[:limit]:
        timestamp_text = (
            timestamp.strftime(PREVIEW_TIMESTAMP_FORMAT)
            if timestamp is not None
            else "unknown timestamp    "
        )
        latest_files.append((filename, timestamp_text))

    return latest_files


def download_logs(ftp: FTP, filenames: list[str], target_directory: Path) -> DownloadResult:
    overwritten_files = 0
    downloaded_files = 0
    total = len(filenames)

    if total == 0:
        print_activity("Keine Dateien im gewuenschten Zeitraum gefunden")
        return DownloadResult(found_files=0, downloaded_files=0, overwritten_files=0)

    for index, filename in enumerate(filenames, start=1):
        print_progress(index, total, filename)
        target_file = target_directory / filename

        if target_file.exists():
            overwritten_files += 1
            print_activity(f"Datei wird ueberschrieben: {target_file.name}")

        download_file(ftp, filename, target_file)
        downloaded_files += 1

    return DownloadResult(
        found_files=total,
        downloaded_files=downloaded_files,
        overwritten_files=overwritten_files,
    )


def download_file(ftp: FTP, filename: str, target_file: Path) -> None:
    file_size = get_remote_file_size(ftp, filename)
    last_render_time = 0.0
    transferred_bytes = 0

    with target_file.open("wb") as handle:
        def write_chunk(chunk: bytes) -> None:
            nonlocal last_render_time, transferred_bytes

            handle.write(chunk)
            transferred_bytes += len(chunk)

            now = monotonic()
            # Throttling keeps the console readable while still proving that copying is active.
            if now - last_render_time >= 0.2 or (
                file_size is not None and transferred_bytes >= file_size
            ):
                print_file_copy_progress(filename, transferred_bytes, file_size)
                last_render_time = now

        ftp.retrbinary(f"RETR {filename}", write_chunk)

    print_file_copy_progress(filename, transferred_bytes, file_size)
    finish_file_copy_progress()


def get_remote_file_size(ftp: FTP, filename: str) -> int | None:
    try:
        return ftp.size(filename)
    except all_errors:
        return None


def list_csv_files_with_timestamps(ftp: FTP, source: str) -> list[tuple[str, datetime | None]]:
    log_directory = resolve_log_directory(source)
    print_activity(f"Wechsle in FTP-Ordner {log_directory}")
    ftp.cwd(log_directory)
    print_activity("Lese Dateiliste auf dem FTP-Server")
    filenames = ftp.nlst()

    file_entries: list[tuple[str, datetime | None]] = []
    for filename in filenames:
        if not is_csv_file(filename):
            continue

        file_entries.append((filename, get_file_timestamp(ftp, filename)))

    return file_entries


def sort_key_for_latest_files(file_entry: tuple[str, datetime | None]) -> tuple[datetime, str]:
    filename, timestamp = file_entry
    if timestamp is None:
        return datetime.min, filename

    return timestamp, filename
