@echo off
setlocal

set "PROJECT_ROOT=%~dp0"
if "%PROJECT_ROOT:~-1%"=="\" set "PROJECT_ROOT=%PROJECT_ROOT:~0,-1%"

set "VENV_PYTHON=%PROJECT_ROOT%\.venv\Scripts\python.exe"
set "LOCAL_PYTHON=%PROJECT_ROOT%\.python\python.exe"
set "BOOTSTRAP_PYTHON="
set "RUN_PYTHON="

if exist "%VENV_PYTHON%" (
    set "RUN_PYTHON=%VENV_PYTHON%"
    goto run_app
)

where py >nul 2>nul
if not errorlevel 1 (
    set "BOOTSTRAP_PYTHON=py -3"
    goto create_venv
)

where python >nul 2>nul
if not errorlevel 1 (
    set "BOOTSTRAP_PYTHON=python"
    goto create_venv
)

if exist "%LOCAL_PYTHON%" (
    set "RUN_PYTHON=%LOCAL_PYTHON%"
    goto ensure_local_requirements
)

echo No system Python installation was found. A local project runtime will be installed now.
powershell -ExecutionPolicy Bypass -File "%PROJECT_ROOT%\scripts\install_local_python.ps1" -ProjectRoot "%PROJECT_ROOT%"
if errorlevel 1 goto fail

set "RUN_PYTHON=%LOCAL_PYTHON%"
goto ensure_local_requirements

:create_venv
echo Creating local virtual environment
%BOOTSTRAP_PYTHON% -m venv "%PROJECT_ROOT%\.venv"
if errorlevel 1 goto fail

set "RUN_PYTHON=%VENV_PYTHON%"

:ensure_local_requirements
echo Installing local dependencies
"%RUN_PYTHON%" -m pip install --disable-pip-version-check -r "%PROJECT_ROOT%\requirements.txt"
if errorlevel 1 goto fail

:run_app
echo Starting MQTT CSV Logger
"%RUN_PYTHON%" -m functions
set "EXIT_CODE=%ERRORLEVEL%"
goto end

:fail
echo Startup failed.
set "EXIT_CODE=1"

:end
endlocal & exit /b %EXIT_CODE%
