# Decisions

This directory is reserved for architecture decision records when the project needs documented technical decisions.
