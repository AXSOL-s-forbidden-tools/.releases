from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class BrokerConfig:
    host: str
    port: int
    username: str | None
    password: str | None


@dataclass(frozen=True)
class StatusItem:
    item_id: str
    label: str
    group: str
    topic: str
    key: str
    unit: str


@dataclass(frozen=True)
class AppConfig:
    broker: BrokerConfig
    status_items: list[StatusItem]
    source_path: Path


@dataclass(frozen=True)
class CsvTarget:
    status_item: StatusItem
    file_path: Path
