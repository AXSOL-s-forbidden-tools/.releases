from __future__ import annotations

import logging
from pathlib import Path

from functions.app_logging import initialize_application_logging
from functions.cli import ask_for_command, ask_for_existing_file, ask_for_output_directory
from functions.config_loader import load_config
from functions.csv_logger import CsvLogger
from functions.mqtt_runtime import MqttLoggingRuntime

LOGGER = logging.getLogger(__name__)


def run() -> None:
    project_root = Path(__file__).resolve().parent.parent
    log_file_path = initialize_application_logging(project_root)

    print("MQTT CSV Logger")
    print("")
    print(f"Session log file: {log_file_path}")
    LOGGER.info("Application started.")

    config_path = ask_for_existing_file("Path to config JSON: ")
    output_dir = ask_for_output_directory("Directory for CSV files: ")

    app_config = load_config(config_path)
    LOGGER.info("Loaded configuration from %s.", app_config.source_path)
    LOGGER.info("Selected output directory: %s.", output_dir)
    csv_logger = CsvLogger(output_dir=output_dir, status_items=app_config.status_items)
    mqtt_runtime = MqttLoggingRuntime(app_config=app_config, csv_logger=csv_logger)

    print("")
    print(f"Loaded config: {app_config.source_path}")
    print(f"Broker: {app_config.broker.host}:{app_config.broker.port}")
    print(f"Status items: {len(app_config.status_items)}")
    print("Tip: TAB completion is available when prompt-toolkit is installed.")
    print("Commands: start logging | stop logging | status | quit")

    try:
        _command_loop(csv_logger, mqtt_runtime)
    except KeyboardInterrupt:
        LOGGER.info("Application interrupted by user.")
        print("")
        print("Interrupted by user.")
    except Exception:
        LOGGER.exception("Application stopped because of an unexpected error.")
        raise
    finally:
        mqtt_runtime.stop()
        LOGGER.info("Application closed.")
        print("Application closed.")


def _command_loop(
    csv_logger: CsvLogger,
    mqtt_runtime: MqttLoggingRuntime,
) -> None:
    commands = ["start logging", "stop logging", "status", "quit", "exit"]
    while True:
        command = ask_for_command("> ", commands, lambda: _build_live_status_lines(csv_logger, mqtt_runtime))
        if command == "start logging":
            LOGGER.info("User command: start logging")
            if mqtt_runtime.running:
                print("Logging is already running.")
                continue
            try:
                mqtt_runtime.start()
            except Exception as error:
                LOGGER.exception("Could not start logging.")
                print(f"Could not start logging: {error}")
                continue
            print("Logging started.")
            continue

        if command == "stop logging":
            LOGGER.info("User command: stop logging")
            if not mqtt_runtime.running:
                print("Logging is not running.")
                continue
            mqtt_runtime.stop()
            print("Logging stopped.")
            continue

        if command == "status":
            LOGGER.info("User command: status")
            _print_status(csv_logger.get_target_paths(), mqtt_runtime.running)
            continue

        if command in {"quit", "exit"}:
            LOGGER.info("User command: quit")
            return

        LOGGER.warning("Unknown command entered: %s", command)
        print("Unknown command. Use: start logging | stop logging | status | quit")


def _print_status(file_paths: list[Path], logging_active: bool) -> None:
    print(f"Logging active: {'yes' if logging_active else 'no'}")
    for file_path in file_paths:
        file_size = file_path.stat().st_size if file_path.exists() else 0
        print(f"  {file_path.name}: {file_size} bytes")


def _build_live_status_lines(csv_logger: CsvLogger, mqtt_runtime: MqttLoggingRuntime) -> list[str]:
    prefix = "RUN" if mqtt_runtime.running else "IDLE"
    lines: list[str] = []

    for file_path in csv_logger.get_target_paths():
        file_size = file_path.stat().st_size if file_path.exists() else 0
        lines.append(f"{prefix} | {file_path.name}: {file_size} B")

    return lines
