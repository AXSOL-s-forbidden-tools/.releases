from __future__ import annotations

import time
from shutil import get_terminal_size
from pathlib import Path
from threading import Event, Thread


class StatusDisplay:
    def __init__(self, file_paths: list[Path], refresh_seconds: float = 2.0) -> None:
        self._file_paths = file_paths
        self._refresh_seconds = refresh_seconds
        self._stop_event = Event()
        self._thread: Thread | None = None
        self._last_lines: list[str] = []

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = Thread(target=self._run, name="status-display", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=3)
        self._thread = None
        if self._last_lines:
            self._render_lines(["" for _ in self._last_lines])
            self._last_lines = []
            print("", flush=True)

    def _run(self) -> None:
        while not self._stop_event.is_set():
            new_lines = self.get_status_lines()
            if new_lines != self._last_lines:
                self._render_lines(new_lines)
            time.sleep(self._refresh_seconds)

    def get_status_lines(self) -> list[str]:
        lines: list[str] = []
        for file_path in self._file_paths:
            file_size = file_path.stat().st_size if file_path.exists() else 0
            lines.append(self._fit_to_terminal(f"{file_path.name}: {file_size} B"))
        return lines

    def _render_lines(self, new_lines: list[str]) -> None:
        if self._last_lines:
            print(f"\x1b[{len(self._last_lines)}F", end="")

        render_count = max(len(self._last_lines), len(new_lines))
        padded_new_lines = list(new_lines)
        while len(padded_new_lines) < render_count:
            padded_new_lines.append("")

        for index, line in enumerate(padded_new_lines):
            previous_length = len(self._last_lines[index]) if index < len(self._last_lines) else 0
            padded_line = line.ljust(previous_length)
            print(f"\r{padded_line}", end="")
            if index < render_count - 1:
                print("")
        print("", end="", flush=True)
        self._last_lines = new_lines

    def _fit_to_terminal(self, value: str) -> str:
        terminal_width = max(get_terminal_size((120, 20)).columns - 1, 20)
        if len(value) <= terminal_width:
            return value
        return value[: terminal_width - 3] + "..."
