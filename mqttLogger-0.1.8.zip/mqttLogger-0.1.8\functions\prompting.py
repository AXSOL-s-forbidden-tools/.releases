from __future__ import annotations

from pathlib import Path

try:
    from prompt_toolkit import PromptSession
    from prompt_toolkit import prompt as toolkit_prompt
    from prompt_toolkit.completion import PathCompleter, WordCompleter
    from prompt_toolkit.patch_stdout import patch_stdout
except ImportError:  # pragma: no cover - optional dependency
    PromptSession = None
    toolkit_prompt = None
    PathCompleter = None
    WordCompleter = None
    patch_stdout = None


class PathPrompt:
    def __init__(self, prompt: str, only_directories: bool) -> None:
        self._prompt = prompt
        self._only_directories = only_directories

    def ask(self) -> Path:
        if toolkit_prompt is not None and PathCompleter is not None:
            completer = PathCompleter(expanduser=True, only_directories=self._only_directories)
            return Path(_normalize_path_input(toolkit_prompt(self._prompt, completer=completer)))
        return Path(_normalize_path_input(input(self._prompt)))


def prompt_for_command(prompt: str, commands: list[str]) -> str:
    if toolkit_prompt is not None and WordCompleter is not None:
        completer = WordCompleter(commands, ignore_case=True, sentence=True)
        return toolkit_prompt(prompt, completer=completer).strip().lower()
    return input(prompt).strip().lower()


class CommandPrompt:
    def __init__(
        self,
        prompt: str,
        commands: list[str],
        live_lines_provider: callable | None = None,
    ) -> None:
        self._prompt = prompt
        self._commands = commands
        self._live_lines_provider = live_lines_provider
        self._session = None

        if PromptSession is not None and WordCompleter is not None:
            completer = WordCompleter(commands, ignore_case=True, sentence=True)
            self._session = PromptSession(completer=completer)

    def ask(self) -> str:
        if self._session is None:
            return input(self._prompt).strip().lower()

        prompt_arguments = {
            "message": self._prompt,
            "refresh_interval": 1.0,
        }

        if self._live_lines_provider is not None:
            prompt_arguments["bottom_toolbar"] = self._build_bottom_toolbar

        if patch_stdout is None:
            return self._session.prompt(**prompt_arguments).strip().lower()

        with patch_stdout():
            return self._session.prompt(**prompt_arguments).strip().lower()

    def _build_bottom_toolbar(self) -> str:
        if self._live_lines_provider is None:
            return ""

        lines = self._live_lines_provider()
        if not lines:
            return "Logging inactive"

        return "\n".join(lines)


def _normalize_path_input(raw_value: str) -> str:
    # Windows terminals often paste dropped files or folders with surrounding quotes.
    return raw_value.strip().strip('"')
