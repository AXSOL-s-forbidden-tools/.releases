# Development

## Local Run

```powershell
python -m pip install -r .\requirements.txt
python -m functions
```

## Batch Launcher

```powershell
.\start_logger.bat
```

The batch launcher prefers a local virtual environment in `.venv`.
If no system Python installation is available, it downloads a local embedded Python runtime into `.python` and installs the project dependencies there.

## Validation

```powershell
python -m compileall .\functions
.\scripts\build_release.ps1
```

## Notes

- The project is intentionally dependency-light.
- The application expects JSON payloads with a top-level `ts` field in milliseconds since Unix epoch.
- One semicolon-separated CSV file is created for each entry in `statusItems`.
- The `timestamp_local` column uses the local machine timezone with millisecond precision.
- TAB completion is enabled when `prompt-toolkit` is installed.
- With `prompt-toolkit`, the live terminal output is rendered separately from the command prompt to reduce flicker and keep the layout stable.
- Daily application logs are stored in `.\log` and are trimmed automatically when the folder exceeds 100 MB.
- Release ZIP files are created in `.\release` by `.\scripts\build_release.ps1`.
