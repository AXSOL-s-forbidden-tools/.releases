from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

from functions.prompting import CommandPrompt, PathPrompt


def ask_for_existing_file(prompt: str) -> Path:
    path_prompt = PathPrompt(prompt=prompt, only_directories=False)
    while True:
        file_path = path_prompt.ask().expanduser().resolve()
        if file_path.is_file():
            return file_path
        print("The file does not exist. Please try again.")


def ask_for_output_directory(prompt: str) -> Path:
    path_prompt = PathPrompt(prompt=prompt, only_directories=True)
    while True:
        output_path = path_prompt.ask().expanduser().resolve()
        if output_path.exists() and not output_path.is_dir():
            print("The selected path is a file. Please choose a directory.")
            continue
        return output_path


def ask_for_command(
    prompt: str,
    commands: list[str],
    live_lines_provider: Callable[[], list[str]] | None = None,
) -> str:
    return CommandPrompt(
        prompt=prompt,
        commands=commands,
        live_lines_provider=live_lines_provider,
    ).ask()
