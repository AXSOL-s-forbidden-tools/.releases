# Architecture

The application is a terminal-based MQTT logger with a small set of focused modules.

```mermaid
flowchart TD
  A[CLI Input] --> B[Config Loader]
  A --> G[Prompt Helper]
  A --> H[Application Logging]
  A --> J[Release Build Script]
  B --> C[MQTT Runtime]
  B --> D[CSV Logger]
  C --> D
  D --> E[CSV Files]
  H --> I[Daily Log Files]
  J --> K[Release ZIP]
  C --> F[Status Display]
```

## Main Parts

- `functions/__main__.py` starts the application package entry point.
- `functions/app.py` controls the interactive workflow and command loop.
- `functions/prompting.py` adds optional TAB completion for paths and commands.
- `functions/app_logging.py` prepares daily log files and cleans up oversized log storage.
- `functions/config_loader.py` reads and validates the exported JSON configuration.
- `functions/mqtt_runtime.py` handles the MQTT connection, subscriptions, and payload parsing.
- `functions/csv_logger.py` creates and appends to semicolon-separated CSV files.
- `scripts/build_release.ps1` builds the distributable ZIP file for GitHub releases.
- `functions/status_display.py` still provides a fallback text renderer, while the preferred interactive command view uses `prompt-toolkit` to keep status output separate from the command prompt.

## Data Flow

1. The user provides a configuration file path and an output directory.
2. The configuration loader extracts the broker settings and `statusItems`.
3. The MQTT runtime subscribes to all topics used by the configured status items.
4. Each incoming JSON payload is checked for a valid `ts` value.
5. Matching values are appended to the CSV file that belongs to the status item.
