from __future__ import annotations

import re

from functions.models import StatusItem


def build_csv_name(status_item: StatusItem) -> str:
    parts = [
        status_item.group,
        status_item.label,
        status_item.key,
        status_item.topic,
    ]
    sanitized_parts = [_sanitize_part(part) for part in parts]
    return "__".join(sanitized_parts) + ".csv"


def _sanitize_part(value: str) -> str:
    normalized_value = value.strip().replace("/", "_").replace("\\", "_")
    normalized_value = re.sub(r"[^A-Za-z0-9._()-]+", "_", normalized_value)
    normalized_value = re.sub(r"_+", "_", normalized_value).strip("._")
    return normalized_value or "value"
