param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectRoot
)

$ErrorActionPreference = "Stop"

$pythonHome = Join-Path $ProjectRoot ".python"
$pythonExe = Join-Path $pythonHome "python.exe"
$pythonZip = Join-Path $ProjectRoot ".python-embed.zip"
$getPipScript = Join-Path $ProjectRoot ".python-get-pip.py"
$pythonVersion = "3.13.3"
$pythonShortVersion = "313"
$pythonUrl = "https://www.python.org/ftp/python/$pythonVersion/python-$pythonVersion-embed-amd64.zip"
$getPipUrl = "https://bootstrap.pypa.io/get-pip.py"

if (-not (Test-Path $pythonHome)) {
    New-Item -ItemType Directory -Path $pythonHome | Out-Null
}

Write-Host "Downloading local Python runtime from $pythonUrl"
Invoke-WebRequest -Uri $pythonUrl -OutFile $pythonZip

Write-Host "Extracting local Python runtime"
Expand-Archive -LiteralPath $pythonZip -DestinationPath $pythonHome -Force

$pthFile = Join-Path $pythonHome "python$pythonShortVersion._pth"
if (-not (Test-Path $pthFile)) {
    throw "Could not find the embedded Python path file: $pthFile"
}

$pthContent = Get-Content $pthFile -Raw
if ($pthContent -notmatch "(?m)^import site$") {
    $pthContent = $pthContent -replace '(?m)^#import site$', 'import site'
    Set-Content -Path $pthFile -Value $pthContent -Encoding ASCII
}

Write-Host "Downloading pip bootstrap script"
Invoke-WebRequest -Uri $getPipUrl -OutFile $getPipScript

Write-Host "Installing pip into the local Python runtime"
& $pythonExe $getPipScript --no-warn-script-location

Write-Host "Installing project dependencies into the local Python runtime"
& $pythonExe -m pip install --disable-pip-version-check -r (Join-Path $ProjectRoot "requirements.txt")

Remove-Item -Force $pythonZip, $getPipScript -ErrorAction SilentlyContinue
