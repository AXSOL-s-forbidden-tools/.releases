# Logging Flow

```mermaid
sequenceDiagram
  participant User
  participant CLI
  participant MQTT
  participant CSV
  participant Log

  User->>CLI: Provide config path and output directory
  CLI->>Log: Open daily session log
  User->>CLI: start logging
  CLI->>MQTT: Connect and subscribe to configured topics
  MQTT-->>CLI: JSON payload with ts and values
  CLI->>CSV: Append matching value to item-specific CSV file
  User->>CLI: stop logging
  CLI->>MQTT: Stop loop and disconnect
  CLI->>Log: Write usage and error entries
```

## Release Build

```mermaid
flowchart TD
  A[Read VERSION] --> B[Create staging folder]
  B --> C[Copy runtime files]
  C --> D[Create ZIP in release]
  D --> E[Upload ZIP as GitHub release asset]
```
