from __future__ import annotations

import logging
from pathlib import Path

LOG_DIRECTORY_NAME = "log"
MAX_LOG_BYTES_BEFORE_CLEANUP = 100 * 1024 * 1024
TARGET_LOG_BYTES_AFTER_CLEANUP = 50 * 1024 * 1024


def initialize_application_logging(project_root: Path) -> Path:
    log_dir = project_root / LOG_DIRECTORY_NAME
    log_dir.mkdir(parents=True, exist_ok=True)
    _cleanup_old_log_files(log_dir)

    log_file_path = log_dir / f"{_current_day_string()}.log"
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)

    for handler in list(root_logger.handlers):
        if getattr(handler, "_mqtt_csv_logger_managed", False):
            root_logger.removeHandler(handler)
            handler.close()

    file_handler = logging.FileHandler(log_file_path, encoding="utf-8")
    file_handler._mqtt_csv_logger_managed = True  # type: ignore[attr-defined]
    file_handler.setFormatter(
        logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s")
    )
    root_logger.addHandler(file_handler)
    root_logger.info("Application logging initialized.")
    return log_file_path


def _cleanup_old_log_files(log_dir: Path) -> None:
    log_files = [path for path in log_dir.glob("*.log") if path.is_file()]
    total_size = sum(path.stat().st_size for path in log_files)
    if total_size <= MAX_LOG_BYTES_BEFORE_CLEANUP:
        return

    for log_file in sorted(log_files, key=lambda path: path.stat().st_mtime):
        try:
            file_size = log_file.stat().st_size
        except FileNotFoundError:
            continue

        log_file.unlink(missing_ok=True)
        total_size -= file_size
        if total_size <= TARGET_LOG_BYTES_AFTER_CLEANUP:
            break


def _current_day_string() -> str:
    from datetime import datetime

    return datetime.now().strftime("%Y-%m-%d")
