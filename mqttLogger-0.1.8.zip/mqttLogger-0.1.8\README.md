# mqttCsvLogger

`mqttCsvLogger` is a small terminal application that connects to an MQTT broker, reads status values from an exported `mqttWebInterface` configuration, and stores each configured status value in its own CSV file.

## Features

- Loads an exported JSON configuration from `mqttWebInterface`
- Connects to the MQTT broker defined in the configuration
- Subscribes to all topics referenced by `statusItems`
- Writes one CSV file per configured status item
- Uses the `ts` value from each JSON payload as the event timestamp
- Accepts `ts` values as integers, floats, or numeric strings
- Stores CSV data with semicolon separators for spreadsheet-friendly imports
- Converts payload timestamps into local human-readable timestamps with millisecond precision
- Falls back to the MQTT receive time if a payload does not contain a usable `ts` value
- Supports terminal commands to start and stop logging
- Supports TAB completion for paths and commands when `prompt-toolkit` is available
- Keeps the command prompt separate from the live file status view when `prompt-toolkit` is available
- Shows one continuously refreshed terminal line per CSV file with the current file size
- Recreates deleted CSV files automatically when logging starts again
- Writes daily application logs into `.\log` and trims old logs when the folder grows too large
- Includes a Windows batch launcher that prepares a local runtime for the project
- Includes a release build script that creates a ready-to-ship ZIP package in `.\release`

## Requirements

- Python 3.13 or newer for the regular manual start
- Network access during the first batch start when dependencies or the local runtime must be installed

## Setup

1. Open a terminal in the project directory.
2. Install the local dependencies:

```powershell
python -m pip install -r .\requirements.txt
```

3. Start the application:

```powershell
python -m functions
```

You can also use the batch launcher:

```powershell
.\start_logger.bat
```

## Usage

1. Enter the path to the exported configuration JSON file.
2. Enter the target directory for the CSV files.
3. Use one of the following commands:

- `start logging`
- `stop logging`
- `status`
- `quit`

When `prompt-toolkit` is available, the command input stays separate from the live status area. This avoids commands appearing between the displayed CSV file lines and reduces visible flicker.

In Windows terminals, you can also drag and drop a configuration file or output folder into the prompt. The pasted quoted path is accepted automatically.

Each CSV file contains the following columns:

- `timestamp_ms`
- `timestamp_local`
- `topic`
- `key`
- `value`

The CSV separator is `;`.

If a topic has exactly one configured status item and the incoming JSON shape does not expose the configured key directly, the logger stores the full JSON value in that CSV row instead of dropping the message. This keeps single-value topics loggable even when broker payloads differ from the exported configuration.

Application activity and errors are written into daily log files in `.\log`. On startup, the tool checks the total size of that directory. If the log folder is larger than 100 MB, the oldest log files are removed until the remaining size is below 50 MB.

## Important Commands

```powershell
python -m functions
python -m pip install -r .\requirements.txt
python -m compileall .\functions
.\start_logger.bat
.\scripts\build_release.ps1
```

## Release Package

Run the release build script to create a distributable ZIP file in `.\release`.

```powershell
.\scripts\build_release.ps1
```

The package contains the files required to start the logger with `start_logger.bat` on another Windows system.
