from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path
from threading import Lock

from functions.file_names import build_csv_name
from functions.models import CsvTarget, StatusItem


class CsvLogger:
    def __init__(self, output_dir: Path, status_items: list[StatusItem]) -> None:
        self._output_dir = output_dir
        self._targets = {
            item.item_id: CsvTarget(
                status_item=item,
                file_path=output_dir / build_csv_name(item),
            )
            for item in status_items
        }
        self._write_lock = Lock()
        self._ensure_output_files_exist()

    def append_value(self, item_id: str, topic: str, timestamp_ms: int, value: object) -> None:
        target = self._targets[item_id]
        timestamp_local = _format_timestamp(timestamp_ms)

        with self._write_lock:
            self._ensure_output_file_exists(target)
            with target.file_path.open("a", newline="", encoding="utf-8") as csv_file:
                writer = csv.writer(csv_file, delimiter=";")
                writer.writerow([timestamp_ms, timestamp_local, topic, target.status_item.key, value])

    def get_target_paths(self) -> list[Path]:
        return [target.file_path for target in self._targets.values()]

    def get_targets(self) -> list[CsvTarget]:
        return list(self._targets.values())

    def _ensure_output_files_exist(self) -> None:
        self._output_dir.mkdir(parents=True, exist_ok=True)
        for target in self._targets.values():
            self._ensure_output_file_exists(target)

    def _ensure_output_file_exists(self, target: CsvTarget) -> None:
        if target.file_path.exists():
            return
        with target.file_path.open("w", newline="", encoding="utf-8") as csv_file:
            writer = csv.writer(csv_file, delimiter=";")
            writer.writerow(["timestamp_ms", "timestamp_local", "topic", "key", "value"])


def _format_timestamp(timestamp_ms: int) -> str:
    timestamp = datetime.fromtimestamp(timestamp_ms / 1000).astimezone()
    timezone_offset = timestamp.strftime("%z")
    readable_offset = f"{timezone_offset[:-2]}:{timezone_offset[-2:]}"
    return (
        timestamp.strftime("%Y-%m-%d %H:%M:%S.")
        + f"{timestamp.microsecond // 1000:03d}"
        + readable_offset
    )
