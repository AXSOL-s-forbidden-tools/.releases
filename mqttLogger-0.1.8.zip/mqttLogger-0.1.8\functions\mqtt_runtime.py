from __future__ import annotations

import json
import logging
import math
from collections import defaultdict
from time import time_ns
from typing import Any

import paho.mqtt.client as mqtt

from functions.csv_logger import CsvLogger
from functions.models import AppConfig, StatusItem

LOGGER = logging.getLogger(__name__)


class MqttLoggingRuntime:
    def __init__(self, app_config: AppConfig, csv_logger: CsvLogger) -> None:
        self._app_config = app_config
        self._csv_logger = csv_logger
        self._items_by_topic = _group_items_by_topic(app_config.status_items)
        self._client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
        self._connected = False
        self._running = False

        if app_config.broker.username:
            self._client.username_pw_set(
                username=app_config.broker.username,
                password=app_config.broker.password,
            )

        self._client.on_connect = self._on_connect
        self._client.on_disconnect = self._on_disconnect
        self._client.on_message = self._on_message

    @property
    def running(self) -> bool:
        return self._running

    def start(self) -> None:
        if self._running:
            return

        broker = self._app_config.broker
        LOGGER.info("Connecting to broker %s:%s.", broker.host, broker.port)
        self._client.connect(broker.host, broker.port, keepalive=60)
        self._client.loop_start()
        self._running = True

    def stop(self) -> None:
        if not self._running:
            return

        LOGGER.info("Stopping MQTT runtime.")
        if self._connected:
            self._client.disconnect()
        self._client.loop_stop()
        self._running = False

    def _on_connect(
        self,
        client: mqtt.Client,
        userdata: Any,
        flags: mqtt.ConnectFlags,
        reason_code: mqtt.ReasonCode,
        properties: mqtt.Properties | None,
    ) -> None:
        if reason_code.is_failure:
            LOGGER.error("MQTT connection failed: %s", reason_code)
            print(f"MQTT connection failed: {reason_code}")
            return

        self._connected = True
        for topic in self._items_by_topic:
            client.subscribe(topic)
        LOGGER.info("Connected and subscribed to %s topics.", len(self._items_by_topic))
        print(f"Connected to MQTT broker and subscribed to {len(self._items_by_topic)} topics.")

    def _on_disconnect(
        self,
        client: mqtt.Client,
        userdata: Any,
        disconnect_flags: mqtt.DisconnectFlags,
        reason_code: mqtt.ReasonCode,
        properties: mqtt.Properties | None,
    ) -> None:
        self._connected = False
        if self._running:
            LOGGER.warning("MQTT connection closed: %s", reason_code)
            print(f"MQTT connection closed: {reason_code}")

    def _on_message(
        self,
        client: mqtt.Client,
        userdata: Any,
        message: mqtt.MQTTMessage,
    ) -> None:
        matching_items = self._items_by_topic.get(message.topic, [])
        if not matching_items:
            return

        try:
            payload = json.loads(message.payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            LOGGER.warning("Ignored invalid JSON payload on topic '%s'.", message.topic)
            print(f"Ignored invalid JSON payload on topic '{message.topic}'.")
            return

        timestamp_ms = _extract_timestamp_ms(payload)
        if timestamp_ms is None:
            timestamp_ms = _current_timestamp_ms()
            LOGGER.warning(
                "Payload on topic '%s' did not contain a usable 'ts'. Using the MQTT receive time instead.",
                message.topic,
            )
            print(f"Payload on topic '{message.topic}' did not contain a usable 'ts'. Using the receive time instead.")

        for status_item, value in _iter_status_values(payload, matching_items, message.topic):
            self._csv_logger.append_value(
                item_id=status_item.item_id,
                topic=message.topic,
                timestamp_ms=timestamp_ms,
                value=value,
            )


def _group_items_by_topic(status_items: list[StatusItem]) -> dict[str, list[StatusItem]]:
    grouped_items: dict[str, list[StatusItem]] = defaultdict(list)
    for status_item in status_items:
        grouped_items[status_item.topic].append(status_item)
    return dict(grouped_items)


def _extract_timestamp_ms(payload: object) -> int | None:
    if not isinstance(payload, dict):
        return None
    return _coerce_timestamp_ms(payload.get("ts"))


def _coerce_timestamp_ms(value: object) -> int | None:
    if value is None or isinstance(value, bool):
        return None

    if isinstance(value, int):
        return value

    if isinstance(value, float):
        if not math.isfinite(value):
            return None
        return int(value)

    if isinstance(value, str):
        stripped_value = value.strip()
        if not stripped_value:
            return None

        try:
            return int(stripped_value)
        except ValueError:
            try:
                float_value = float(stripped_value)
            except ValueError:
                return None

            if not math.isfinite(float_value):
                return None
            return int(float_value)

    return None


def _iter_status_values(
    payload: object,
    matching_items: list[StatusItem],
    topic: str,
) -> list[tuple[StatusItem, object]]:
    if isinstance(payload, dict):
        values = [
            (status_item, payload[status_item.key])
            for status_item in matching_items
            if status_item.key in payload
        ]
        if values:
            return values

    if len(matching_items) == 1:
        # Single-item topics can still be logged even when the broker sends a plain value
        # or a differently shaped JSON object than the exported configuration expects.
        return [(matching_items[0], _normalize_logged_value(payload))]

    LOGGER.warning(
        "Ignored payload on topic '%s' because no configured key matched and the topic maps to %s status items.",
        topic,
        len(matching_items),
    )
    print(
        "Ignored payload on topic "
        f"'{topic}' because no configured key matched and the topic maps to multiple status items."
    )
    return []


def _normalize_logged_value(value: object) -> object:
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    return value


def _current_timestamp_ms() -> int:
    return time_ns() // 1_000_000
