from __future__ import annotations

import json
from pathlib import Path

from functions.models import AppConfig, BrokerConfig, StatusItem


def load_config(config_path: Path) -> AppConfig:
    raw_data = json.loads(config_path.read_text(encoding="utf-8"))

    connection = raw_data.get("connection", {})
    host = _require_string(connection, "host")
    port = _require_int(connection, "port")
    username = _optional_string(connection.get("username"))
    password = _optional_string(connection.get("password"))

    raw_status_items = raw_data.get("statusItems")
    if not isinstance(raw_status_items, list) or not raw_status_items:
        raise ValueError("The configuration does not contain any status items.")

    status_items = [
        StatusItem(
            item_id=_require_string(item, "id"),
            label=_require_string(item, "label"),
            group=_require_string(item, "group"),
            topic=_require_string(item, "topic"),
            key=_require_string(item, "key"),
            unit=_optional_string(item.get("unit")) or "",
        )
        for item in raw_status_items
        if isinstance(item, dict)
    ]

    if not status_items:
        raise ValueError("The configuration does not contain valid status items.")

    return AppConfig(
        broker=BrokerConfig(
            host=host,
            port=port,
            username=username,
            password=password,
        ),
        status_items=status_items,
        source_path=config_path,
    )


def _require_string(source: dict, key: str) -> str:
    value = source.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"Missing or invalid string value for '{key}'.")
    return value.strip()


def _optional_string(value: object) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError("Expected a string value in the configuration.")
    stripped_value = value.strip()
    return stripped_value or None


def _require_int(source: dict, key: str) -> int:
    value = source.get(key)
    if not isinstance(value, int):
        raise ValueError(f"Missing or invalid integer value for '{key}'.")
    return value
