from __future__ import annotations

from datetime import date, datetime
import logging
from pathlib import Path
from queue import Empty, Queue
import sys
from threading import Thread
from time import sleep
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from functions.date_picker import CalendarTheme, DatePickerDialog
from functions.log_reader import compile_search_pattern, iter_matching_lines, pick_log_files, scan_log_files
from functions.search_navigation import SearchMatchLocation, build_render_window_for_line, find_search_matches
from functions.theme import DARK_THEME, LIGHT_THEME
from functions.windows_dragdrop import WindowsDirectoryDropTarget

DEFAULT_RENDER_LIMIT = 5000
RENDER_LIMIT_OPTIONS = ("1000", "5000", "10000", "20000")
QUEUE_CHUNK_SIZE = 200
QUEUE_MESSAGES_PER_POLL = 20
WORKER_YIELD_LINE_INTERVAL = 200
WORKER_YIELD_SLEEP_SECONDS = 0.001
LOGGER = logging.getLogger(__name__)
LEVEL_COLORS = {
    "Light": {
        "INF": "#6fa3f7",
        "WRN": "#daa53b",
        "ERR": "#f32727",
    },
    "Dark": {
        "INF": "#6fa3f7",
        "WRN": "#eff31f",
        "ERR": "#f32727",
    },
}
SEARCH_TAG_NAME = "search_match"
TAG_TEXT_COLORS = {
    "Light": "#ffffff",
    "Dark": "#10202b",
}


class LogViewerApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("PLC Log Viewer")
        self.root.geometry("1280x820")
        self.root.minsize(980, 640)

        self.theme_name = tk.StringVar(value=DARK_THEME["name"])
        self.directory_var = tk.StringVar(value=str(Path.cwd() / "testdata"))
        self.start_date = date(2026, 6, 10)
        self.end_date = date(2026, 6, 10)
        self.start_date_var = tk.StringVar(value=self.start_date.isoformat())
        self.end_date_var = tk.StringVar(value=self.end_date.isoformat())
        self.start_hour_var = tk.StringVar(value="08")
        self.start_minute_var = tk.StringVar(value="00")
        self.end_hour_var = tk.StringVar(value="10")
        self.end_minute_var = tk.StringVar(value="59")
        self.render_limit_var = tk.StringVar(value=str(DEFAULT_RENDER_LIMIT))
        self.search_var = tk.StringVar()
        self.info_var = tk.BooleanVar(value=False)
        self.warning_var = tk.BooleanVar(value=False)
        self.error_var = tk.BooleanVar(value=False)
        self.status_var = tk.StringVar(value="Choose a directory and time range.")
        self.is_loading = False
        self.result_queue: Queue[tuple[str, object]] = Queue()
        self.drop_target: WindowsDirectoryDropTarget | None = None
        self.all_match_lines: list[tuple[str, str | None]] = []
        self.current_loaded_lines: list[tuple[str, str | None]] = []
        self.pending_render_lines: list[tuple[str, str | None]] = []
        self.active_search_filter = ""
        self.render_window_start = 0
        self.render_window_end = 0
        self.rendered_line_count = 0
        self.total_match_count = 0
        self.search_matches: list[SearchMatchLocation] = []
        self.search_matches_term = ""
        self.current_search_match_index: int | None = None
        self.search_highlight_mode = "none"
        self.loading_indicator_visible = False
        self.loading_indicator_after_id: str | None = None

        self._build_layout()
        self._apply_theme()
        self.root.report_callback_exception = self._report_callback_exception
        self.root.protocol("WM_DELETE_WINDOW", self._close_application)
        self._setup_drag_and_drop()
        self.search_var.trace_add("write", self._handle_search_term_changed)

    def _build_layout(self) -> None:
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(1, weight=1)

        self.controls = tk.Frame(self.root, padx=16, pady=16)
        self.controls.grid(row=0, column=0, sticky="ew")
        self.controls.columnconfigure(1, weight=1)
        self.controls.columnconfigure(3, weight=1)

        tk.Label(self.controls, text="Directory").grid(row=0, column=0, sticky="w")
        tk.Entry(self.controls, textvariable=self.directory_var).grid(
            row=0,
            column=1,
            columnspan=3,
            sticky="ew",
            padx=(8, 8),
        )
        tk.Button(self.controls, text="Browse", command=self._select_directory).grid(
            row=0,
            column=4,
            sticky="ew",
        )

        tk.Label(self.controls, text="Start").grid(row=1, column=0, sticky="w", pady=(12, 0))
        self._build_datetime_selector(
            row=1,
            start_column=1,
            date_variable=self.start_date_var,
            select_date_command=self._select_start_date,
            hour_variable=self.start_hour_var,
            minute_variable=self.start_minute_var,
        )
        tk.Label(self.controls, text="End").grid(row=1, column=2, sticky="w", pady=(12, 0))
        self._build_datetime_selector(
            row=1,
            start_column=3,
            date_variable=self.end_date_var,
            select_date_command=self._select_end_date,
            hour_variable=self.end_hour_var,
            minute_variable=self.end_minute_var,
        )
        self.load_button = tk.Button(self.controls, text="Load Logs", command=self.load_logs)
        self.load_button.grid(row=1, column=4, sticky="ew", pady=(12, 0))

        tk.Label(self.controls, text="Contains").grid(row=2, column=0, sticky="w", pady=(12, 0))
        self.search_entry = tk.Entry(self.controls, textvariable=self.search_var)
        self.search_entry.grid(row=2, column=1, sticky="ew", padx=(8, 8), pady=(12, 0))
        self.search_entry.bind("<Return>", self._handle_search_confirmed)

        search_navigation = tk.Frame(self.controls)
        search_navigation.grid(row=2, column=2, sticky="w", pady=(12, 0))
        tk.Button(search_navigation, text="Find all", command=self._find_all_matches).pack(side="left", padx=(0, 8))
        tk.Button(search_navigation, text="Go to first", command=self._jump_to_first_search_match).pack(
            side="left",
            padx=(0, 8),
        )
        tk.Button(search_navigation, text="Find previous", command=self._jump_to_previous_search_match).pack(
            side="left",
            padx=(0, 8),
        )
        tk.Button(search_navigation, text="Find next", command=self._jump_to_next_search_match).pack(
            side="left",
            padx=(0, 8),
        )
        tk.Button(search_navigation, text="Go to last", command=self._jump_to_last_search_match).pack(
            side="left",
            padx=(0, 8),
        )
        tk.Button(search_navigation, text="Clear all filters", command=self._clear_all_filters).pack(side="left")

        level_frame = tk.Frame(self.controls)
        level_frame.grid(row=2, column=3, sticky="w", pady=(12, 0))
        tk.Checkbutton(level_frame, text="INF", variable=self.info_var, command=self._handle_filter_changed).pack(
            side="left",
            padx=(0, 10),
        )
        tk.Checkbutton(level_frame, text="WRN", variable=self.warning_var, command=self._handle_filter_changed).pack(
            side="left",
            padx=(0, 10),
        )
        tk.Checkbutton(level_frame, text="ERR", variable=self.error_var, command=self._handle_filter_changed).pack(
            side="left"
        )

        self.theme_combobox = ttk.Combobox(
            self.controls,
            textvariable=self.theme_name,
            values=[LIGHT_THEME["name"], DARK_THEME["name"]],
            state="readonly",
            style="Viewer.TCombobox",
            postcommand=lambda: self._refresh_combobox_popdown(self.theme_combobox),
        )
        self.theme_combobox.grid(row=2, column=4, sticky="ew", pady=(12, 0))
        self.theme_name.trace_add("write", lambda *_: self._apply_theme())

        tk.Label(self.controls, text="Initial render").grid(row=3, column=0, sticky="w", pady=(12, 0))
        self.render_limit_combobox = ttk.Combobox(
            self.controls,
            textvariable=self.render_limit_var,
            values=RENDER_LIMIT_OPTIONS,
            state="readonly",
            width=10,
            style="Viewer.TCombobox",
            postcommand=lambda: self._refresh_combobox_popdown(self.render_limit_combobox),
        )
        self.render_limit_combobox.grid(row=3, column=1, sticky="w", padx=(8, 16), pady=(12, 0))

        self.viewer_frame = tk.Frame(self.root)
        self.viewer_frame.grid(row=1, column=0, sticky="nsew", padx=16, pady=(0, 10))
        self.viewer_frame.columnconfigure(0, weight=1)
        self.viewer_frame.rowconfigure(1, weight=1)

        self.top_load_more_button = tk.Button(
            self.viewer_frame,
            text="^ Load previous",
            command=self._load_previous_lines,
            state=tk.DISABLED,
            width=18,
        )
        self.top_load_more_button.grid(row=0, column=0, pady=(0, 8))

        self.log_output_frame = tk.Frame(self.viewer_frame)
        self.log_output_frame.grid(row=1, column=0, sticky="nsew")
        self.log_output_frame.columnconfigure(0, weight=1)
        self.log_output_frame.rowconfigure(0, weight=1)

        self.log_output = tk.Text(
            self.log_output_frame,
            wrap=tk.NONE,
            font=("Consolas", 10),
            padx=12,
            pady=12,
        )
        self.log_output.grid(row=0, column=0, sticky="nsew")

        self.log_output_vertical_scrollbar = tk.Scrollbar(
            self.log_output_frame,
            orient=tk.VERTICAL,
            command=self.log_output.yview,
        )
        self.log_output_vertical_scrollbar.grid(row=0, column=1, sticky="ns")
        self.log_output_horizontal_scrollbar = tk.Scrollbar(
            self.log_output_frame,
            orient=tk.HORIZONTAL,
            command=self.log_output.xview,
        )
        self.log_output_horizontal_scrollbar.grid(row=1, column=0, sticky="ew")
        self.log_output.configure(
            yscrollcommand=self._handle_vertical_scroll,
            xscrollcommand=self._handle_horizontal_scroll,
        )

        self.bottom_load_more_button = tk.Button(
            self.viewer_frame,
            text="v Load more",
            command=self._load_next_lines,
            state=tk.DISABLED,
            width=18,
        )
        self.bottom_load_more_button.grid(row=2, column=0, pady=(8, 0))

        self.status_frame = tk.Frame(self.root, padx=16, pady=8)
        self.status_frame.grid(row=2, column=0, sticky="ew")
        self.status_frame.columnconfigure(0, weight=1)
        self.status_label = tk.Label(self.status_frame, textvariable=self.status_var, anchor="w")
        self.status_label.grid(row=0, column=0, sticky="ew")
        self.loading_progress = ttk.Progressbar(
            self.status_frame,
            mode="indeterminate",
            length=160,
            style="Viewer.Horizontal.TProgressbar",
        )
        self.loading_progress.grid(row=0, column=1, sticky="e", padx=(12, 0))
        self.loading_progress.grid_remove()

    def _build_datetime_selector(
        self,
        row: int,
        start_column: int,
        date_variable: tk.StringVar,
        select_date_command,
        hour_variable: tk.StringVar,
        minute_variable: tk.StringVar,
    ) -> None:
        selector_frame = tk.Frame(self.controls)
        selector_frame.grid(row=row, column=start_column, sticky="ew", padx=(8, 16), pady=(12, 0))
        selector_frame.columnconfigure(0, weight=1)

        tk.Entry(selector_frame, textvariable=date_variable, state="readonly").grid(row=0, column=0, sticky="ew")
        tk.Button(selector_frame, text="Date", command=select_date_command).grid(row=0, column=1, padx=(8, 0))
        tk.Spinbox(
            selector_frame,
            from_=0,
            to=23,
            wrap=True,
            width=3,
            format="%02.0f",
            textvariable=hour_variable,
        ).grid(row=0, column=2, padx=(12, 0))
        tk.Label(selector_frame, text=":").grid(row=0, column=3, padx=2)
        tk.Spinbox(
            selector_frame,
            from_=0,
            to=59,
            wrap=True,
            width=3,
            format="%02.0f",
            textvariable=minute_variable,
        ).grid(row=0, column=4)

    def _apply_theme(self) -> None:
        theme = LIGHT_THEME if self.theme_name.get() == LIGHT_THEME["name"] else DARK_THEME
        self.root.configure(bg=theme["background"])
        self.controls.configure(bg=theme["background"])
        self.viewer_frame.configure(bg=theme["background"])
        self.log_output_frame.configure(bg=theme["background"])
        self.status_frame.configure(bg=theme["background"])
        self.status_label.configure(bg=theme["background"], fg=theme["muted_text"])

        self._style_children(self.controls, theme)
        self._style_children(self.viewer_frame, theme)
        self.log_output.configure(
            bg=theme["log_background"],
            fg=theme["log_foreground"],
            insertbackground=theme["log_foreground"],
            selectbackground=theme["accent"],
        )
        self.log_output_vertical_scrollbar.configure(
            bg=theme["button_background"],
            activebackground=theme["accent"],
            troughcolor=theme["panel"],
        )
        self.log_output_horizontal_scrollbar.configure(
            bg=theme["button_background"],
            activebackground=theme["accent"],
            troughcolor=theme["panel"],
        )
        self._configure_text_tags(theme)
        self._configure_combobox_style(theme)
        self._configure_progressbar_style(theme)
        self._configure_combobox_popdown(self.theme_combobox, theme)
        self._configure_combobox_popdown(self.render_limit_combobox, theme)

    def _refresh_combobox_popdown(self, combobox: ttk.Combobox) -> None:
        theme = LIGHT_THEME if self.theme_name.get() == LIGHT_THEME["name"] else DARK_THEME
        self._configure_combobox_popdown(combobox, theme)

    def _handle_vertical_scroll(self, first: str, last: str) -> None:
        self.log_output_vertical_scrollbar.set(first, last)
        self._update_scrollbar_visibility()

    def _handle_horizontal_scroll(self, first: str, last: str) -> None:
        self.log_output_horizontal_scrollbar.set(first, last)
        self._update_scrollbar_visibility()

    def _update_scrollbar_visibility(self) -> None:
        vertical_first, vertical_last = self.log_output.yview()
        horizontal_first, horizontal_last = self.log_output.xview()

        if self._should_show_scrollbar(vertical_first, vertical_last):
            self.log_output_vertical_scrollbar.grid()
        else:
            self.log_output_vertical_scrollbar.grid_remove()

        if self._should_show_scrollbar(horizontal_first, horizontal_last):
            self.log_output_horizontal_scrollbar.grid()
        else:
            self.log_output_horizontal_scrollbar.grid_remove()

    def _should_show_scrollbar(self, first: float, last: float) -> bool:
        # Hiding unused scrollbars keeps the viewer clean while still showing them immediately on overflow.
        return first > 0.0 or last < 1.0

    def _configure_combobox_style(self, theme: dict[str, str]) -> None:
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(
            "Viewer.TCombobox",
            fieldbackground=theme["input_background"],
            background=theme["button_background"],
            foreground=theme["input_foreground"],
            arrowcolor=theme["input_foreground"],
            bordercolor=theme["button_background"],
            lightcolor=theme["button_background"],
            darkcolor=theme["button_background"],
        )
        style.map(
            "Viewer.TCombobox",
            fieldbackground=[("readonly", theme["input_background"])],
            foreground=[("readonly", theme["input_foreground"])],
            selectforeground=[("readonly", theme["input_foreground"])],
            selectbackground=[("readonly", theme["accent"])],
            background=[("readonly", theme["button_background"])],
        )

    def _configure_progressbar_style(self, theme: dict[str, str]) -> None:
        style = ttk.Style()
        style.configure(
            "Viewer.Horizontal.TProgressbar",
            troughcolor=theme["panel"],
            background=theme["accent"],
            bordercolor=theme["panel"],
            lightcolor=theme["accent"],
            darkcolor=theme["accent"],
        )

    def _configure_combobox_popdown(self, combobox: ttk.Combobox, theme: dict[str, str]) -> None:
        try:
            popdown_name = str(combobox.tk.call("ttk::combobox::PopdownWindow", str(combobox)))
            popdown_frame = self.root.nametowidget(f"{popdown_name}.f")
            popdown_listbox = self.root.nametowidget(f"{popdown_name}.f.l")
            popdown_frame.configure(bg=theme["panel"])
            popdown_listbox.configure(
                bg=theme["input_background"],
                fg=theme["input_foreground"],
                selectbackground=theme["accent"],
                selectforeground=theme["text"],
                highlightthickness=0,
            )
        except (KeyError, tk.TclError):
            # Some Tk builds create the popdown lazily, so styling can be retried during the next refresh.
            return

    def _style_children(self, widget: tk.Misc, theme: dict[str, str]) -> None:
        for child in widget.winfo_children():
            if isinstance(child, tk.Frame):
                child.configure(bg=theme["background"])
                self._style_children(child, theme)
            elif isinstance(child, ttk.Combobox):
                continue
            elif isinstance(child, tk.Spinbox):
                child.configure(
                    bg=theme["input_background"],
                    fg=theme["input_foreground"],
                    buttonbackground=theme["button_background"],
                    insertbackground=theme["input_foreground"],
                    relief=tk.FLAT,
                )
            elif isinstance(child, tk.Label):
                child.configure(bg=theme["background"], fg=theme["text"])
            elif isinstance(child, tk.Entry):
                child.configure(
                    bg=theme["input_background"],
                    fg=theme["input_foreground"],
                    readonlybackground=theme["input_background"],
                    disabledforeground=theme["input_foreground"],
                    insertbackground=theme["input_foreground"],
                    highlightthickness=1,
                    highlightbackground=theme["button_background"],
                    highlightcolor=theme["accent"],
                    relief=tk.FLAT,
                )
            elif isinstance(child, tk.Button):
                child.configure(
                    bg=theme["button_background"],
                    fg=theme["button_foreground"],
                    activebackground=theme["accent"],
                    activeforeground=theme["text"],
                    relief=tk.FLAT,
                )
            elif isinstance(child, tk.Scrollbar):
                child.configure(
                    bg=theme["button_background"],
                    activebackground=theme["accent"],
                    troughcolor=theme["panel"],
                )
            elif isinstance(child, tk.Checkbutton):
                child.configure(
                    bg=theme["background"],
                    fg=theme["text"],
                    activebackground=theme["background"],
                    activeforeground=theme["text"],
                    selectcolor=theme["panel"],
                )

    def _setup_drag_and_drop(self) -> None:
        if sys.platform != "win32":
            self.status_var.set("Choose a directory and time range. Drag and drop is available on Windows.")
            return

        try:
            self.drop_target = WindowsDirectoryDropTarget(self.root, self._handle_dropped_directory)
            self.root.after(150, self._poll_drag_and_drop)
        except Exception:
            LOGGER.exception("Failed to enable drag and drop support")

    def _select_directory(self) -> None:
        if self.is_loading:
            return
        selected_directory = filedialog.askdirectory(initialdir=self.directory_var.get() or str(Path.cwd()))
        if selected_directory:
            self.directory_var.set(selected_directory)
            self.load_logs()

    def _select_start_date(self) -> None:
        selected_date = self._open_date_picker(self.start_date)
        if selected_date is None:
            return
        self.start_date = selected_date
        self.start_date_var.set(selected_date.isoformat())

    def _select_end_date(self) -> None:
        selected_date = self._open_date_picker(self.end_date)
        if selected_date is None:
            return
        self.end_date = selected_date
        self.end_date_var.set(selected_date.isoformat())

    def _open_date_picker(self, initial_date: date) -> date | None:
        theme = LIGHT_THEME if self.theme_name.get() == LIGHT_THEME["name"] else DARK_THEME
        picker = DatePickerDialog(
            self.root,
            initial_date=initial_date,
            theme=CalendarTheme(
                background=theme["background"],
                panel=theme["panel"],
                text=theme["text"],
                accent=theme["accent"],
                button_background=theme["button_background"],
                button_foreground=theme["button_foreground"],
                muted_text=theme["muted_text"],
            ),
        )
        return picker.show()

    def _handle_dropped_directory(self, dropped_path: Path) -> None:
        self.directory_var.set(str(dropped_path))
        self.status_var.set(f"Working directory set to {dropped_path}")
        self.load_logs()

    def _poll_drag_and_drop(self) -> None:
        if self.drop_target is not None:
            self.drop_target.dispatch_pending_drops()
        if self.root.winfo_exists():
            self.root.after(150, self._poll_drag_and_drop)

    def _configure_text_tags(self, theme: dict[str, str]) -> None:
        level_colors = LEVEL_COLORS[theme["name"]]
        tag_text_color = TAG_TEXT_COLORS[theme["name"]]
        for level_name, level_color in level_colors.items():
            self.log_output.tag_configure(
                level_name,
                background=level_color,
                foreground=tag_text_color,
                borderwidth=0,
                relief=tk.FLAT,
            )
        self.log_output.tag_configure(
            SEARCH_TAG_NAME,
            background="#38e94f" if theme["name"] == "Dark" else "#be45c2",
            foreground=tag_text_color,
            borderwidth=0,
            relief=tk.FLAT,
        )

    def _handle_search_confirmed(self, _event: tk.Event) -> str:
        self._find_all_matches()
        return "break"

    def _find_all_matches(self) -> None:
        self.active_search_filter = self.search_var.get().strip()
        self.search_highlight_mode = "all"
        self.load_logs()

    def _handle_search_term_changed(self, *_args) -> None:
        self._invalidate_search_navigation()
        self._refresh_visible_search_highlights()

    def _invalidate_search_navigation(self, reset_highlight_mode: bool = True) -> None:
        self.search_matches = []
        self.search_matches_term = ""
        self.current_search_match_index = None
        if reset_highlight_mode:
            self.search_highlight_mode = "none"

    def _clear_all_filters(self) -> None:
        self.search_var.set("")
        self.active_search_filter = ""
        self.info_var.set(False)
        self.warning_var.set(False)
        self.error_var.set(False)
        self._invalidate_search_navigation()
        self.log_output.tag_remove(SEARCH_TAG_NAME, "1.0", tk.END)
        self.load_logs()

    def _jump_to_first_search_match(self) -> None:
        self._jump_to_search_match(target="first")

    def _jump_to_last_search_match(self) -> None:
        self._jump_to_search_match(target="last")

    def _jump_to_previous_search_match(self) -> None:
        self._jump_to_search_match(target="previous")

    def _jump_to_next_search_match(self) -> None:
        self._jump_to_search_match(target="next")

    def _jump_to_search_match(self, target: str) -> None:
        if self.is_loading:
            return

        matches = self._get_search_matches()
        if not matches:
            if self.search_var.get().strip():
                self.status_var.set("No matches for the current search term were found in the loaded result.")
            else:
                self.status_var.set("Enter a search term before using the search navigation buttons.")
            return

        if target == "first":
            target_index = 0
        elif target == "last":
            target_index = len(matches) - 1
        elif target == "previous":
            if self.current_search_match_index is None:
                target_index = len(matches) - 1
            else:
                target_index = max(0, self.current_search_match_index - 1)
        else:
            if self.current_search_match_index is None:
                target_index = 0
            else:
                target_index = min(len(matches) - 1, self.current_search_match_index + 1)

        self.current_search_match_index = target_index
        self.search_highlight_mode = "single"
        self._focus_search_match(matches[target_index])
        self.status_var.set(self._build_search_navigation_status(target, target_index, len(matches)))

    def _get_search_matches(self) -> list[SearchMatchLocation]:
        search_term = self.search_var.get().strip()
        if not search_term:
            return []

        if self.search_matches_term != search_term:
            self.search_matches = find_search_matches(self.all_match_lines, compile_search_pattern(search_term))
            self.search_matches_term = search_term
            self.current_search_match_index = None

        return self.search_matches

    def _focus_search_match(self, match: SearchMatchLocation) -> None:
        if not (self.render_window_start <= match.line_index < self.render_window_end):
            self.render_window_start, self.render_window_end = build_render_window_for_line(
                line_index=match.line_index,
                page_size=self._get_render_limit(),
                total_lines=len(self.all_match_lines),
            )
            self.rendered_line_count = self.render_window_end - self.render_window_start
            self._render_current_window()
            self._update_load_more_buttons()
            self._update_status()

        self._refresh_visible_search_highlights()
        visible_line_number = match.line_index - self.render_window_start + 1
        range_start = f"{visible_line_number}.0+{match.start_offset}c"
        range_end = f"{visible_line_number}.0+{match.end_offset}c"
        self.log_output.tag_remove(tk.SEL, "1.0", tk.END)
        self.log_output.tag_add(tk.SEL, range_start, range_end)
        self.log_output.mark_set(tk.INSERT, range_start)
        self.log_output.see(range_start)
        self.log_output.focus_set()

    def _build_search_navigation_status(self, target: str, match_index: int, match_count: int) -> str:
        action_lookup = {
            "first": "Jumped to the first match",
            "last": "Jumped to the last match",
            "previous": "Jumped to the previous match",
            "next": "Jumped to the next match",
        }
        return f"{action_lookup[target]} ({match_index + 1} of {match_count})."

    def _get_active_search_match_count(self) -> int:
        if not self.active_search_filter:
            return 0
        return len(find_search_matches(self.all_match_lines, compile_search_pattern(self.active_search_filter)))

    def _refresh_visible_search_highlights(self) -> None:
        self.log_output.tag_remove(SEARCH_TAG_NAME, "1.0", tk.END)
        search_term = self.search_var.get().strip()
        if not search_term:
            return

        if self.search_highlight_mode == "all":
            line_count = int(self.log_output.index("end-1c").split(".")[0])
            # Rebuilding visible tags after each render keeps highlights aligned with the current text widget content.
            for line_number in range(1, line_count + 1):
                line_start = f"{line_number}.0"
                line_end = f"{line_number}.end"
                line_text = self.log_output.get(line_start, line_end)
                if not line_text:
                    continue
                self._highlight_search_term(line_start, line_text)
            return

        if self.search_highlight_mode != "single" or self.current_search_match_index is None:
            return

        matches = self._get_search_matches()
        if not matches or self.current_search_match_index >= len(matches):
            return

        current_match = matches[self.current_search_match_index]
        if not (self.render_window_start <= current_match.line_index < self.render_window_end):
            return

        visible_line_number = current_match.line_index - self.render_window_start + 1
        range_start = f"{visible_line_number}.0+{current_match.start_offset}c"
        range_end = f"{visible_line_number}.0+{current_match.end_offset}c"
        self.log_output.tag_add(SEARCH_TAG_NAME, range_start, range_end)

    def _handle_filter_changed(self) -> None:
        if self.is_loading:
            return
        self.load_logs()

    def _get_render_limit(self) -> int:
        try:
            return int(self.render_limit_var.get())
        except ValueError:
            return DEFAULT_RENDER_LIMIT

    def _report_callback_exception(self, exc: type[BaseException], value: BaseException, traceback: object) -> None:
        LOGGER.exception("Unhandled Tkinter exception", exc_info=(exc, value, traceback))
        messagebox.showerror("Application error", str(value))

    def _set_loading_indicator_visible(self, visible: bool) -> None:
        self.loading_indicator_visible = visible
        if not hasattr(self, "loading_progress"):
            return

        if visible:
            self.loading_progress.grid()
            self.loading_progress.step(8)
            self.root.update_idletasks()
            self._schedule_loading_indicator_pulse()
            return

        if self.loading_indicator_after_id is not None:
            self.root.after_cancel(self.loading_indicator_after_id)
            self.loading_indicator_after_id = None
        self.loading_progress.grid_remove()

    def _schedule_loading_indicator_pulse(self) -> None:
        if self.loading_indicator_after_id is not None:
            return
        self.loading_indicator_after_id = self.root.after(80, self._pulse_loading_indicator)

    def _pulse_loading_indicator(self) -> None:
        self.loading_indicator_after_id = None
        if not self.loading_indicator_visible or not self.root.winfo_exists():
            return

        self.loading_progress.step(8)
        self._schedule_loading_indicator_pulse()

    def _should_pause_queue_drain(self, processed_messages: int) -> bool:
        # Short queue bursts keep the UI responsive so the loading indicator can continue animating.
        return processed_messages >= QUEUE_MESSAGES_PER_POLL

    def load_logs(self) -> None:
        if self.is_loading:
            return

        try:
            directory = Path(self.directory_var.get()).expanduser().resolve()
            start_time = self._build_selected_datetime(
                selected_date=self.start_date,
                hour_value=self.start_hour_var.get(),
                minute_value=self.start_minute_var.get(),
            )
            end_time = self._build_selected_datetime(
                selected_date=self.end_date,
                hour_value=self.end_hour_var.get(),
                minute_value=self.end_minute_var.get(),
            )
        except ValueError:
            messagebox.showerror("Invalid input", "Choose valid hour and minute values.")
            return

        if end_time < start_time:
            messagebox.showerror("Invalid range", "The end time must be after the start time.")
            return

        if not directory.exists() or not directory.is_dir():
            messagebox.showerror("Directory not found", "Choose an existing directory with log files.")
            return

        available_files = scan_log_files(directory)
        selected_files = pick_log_files(available_files, start_time, end_time)
        if not selected_files:
            self.log_output.delete("1.0", tk.END)
            self.all_match_lines = []
            self.current_loaded_lines = []
            self.pending_render_lines = []
            self.render_window_start = 0
            self.render_window_end = 0
            self.rendered_line_count = 0
            self.total_match_count = 0
            self._update_load_more_buttons()
            self.status_var.set("No matching log files were found for the selected time range.")
            return

        LOGGER.info(
            "Loading logs from %s between %s and %s with text filter '%s'",
            directory,
            start_time.isoformat(sep=" "),
            end_time.isoformat(sep=" "),
            self.active_search_filter,
        )
        render_limit = self._get_render_limit()
        self.log_output.delete("1.0", tk.END)
        self.all_match_lines = []
        self.current_loaded_lines = []
        self.pending_render_lines = []
        self._invalidate_search_navigation(reset_highlight_mode=False)
        self.render_window_start = 0
        self.render_window_end = 0
        self.rendered_line_count = 0
        self.total_match_count = 0
        self.is_loading = True
        self._set_loading_indicator_visible(True)
        self.load_button.configure(state=tk.DISABLED)
        self._update_load_more_buttons()
        self.status_var.set(f"Loading {len(selected_files)} file(s). Large files are processed in the background.")
        worker = Thread(
            target=self._load_logs_worker,
            kwargs={
                "selected_files": selected_files,
                "start_time": start_time,
                "end_time": end_time,
                "search_term": self.active_search_filter,
                "include_info": self.info_var.get(),
                "include_warning": self.warning_var.get(),
                "include_error": self.error_var.get(),
                "initial_render_limit": render_limit,
            },
            daemon=True,
        )
        worker.start()
        self.root.after(50, self._drain_result_queue)

    def _load_logs_worker(
        self,
        selected_files: list,
        start_time: datetime,
        end_time: datetime,
        search_term: str,
        include_info: bool,
        include_warning: bool,
        include_error: bool,
        initial_render_limit: int,
    ) -> None:
        total_matches = 0
        rendered_lines = 0
        buffered_lines: list[tuple[str, str | None]] = []
        deferred_lines: list[tuple[str, str | None]] = []

        try:
            # The viewer reads each file one line at a time so large logs do not need to fit into memory.
            for match in iter_matching_lines(
                files=selected_files,
                start_time=start_time,
                end_time=end_time,
                include_info=include_info,
                include_warning=include_warning,
                include_error=include_error,
                search_term=search_term,
                progress_callback=lambda: sleep(WORKER_YIELD_SLEEP_SECONDS),
                progress_interval=WORKER_YIELD_LINE_INTERVAL,
            ):
                total_matches += 1
                if rendered_lines < initial_render_limit:
                    buffered_lines.append((match.line, match.level))
                    rendered_lines += 1
                else:
                    # Keep the remaining matches available for later batches without re-reading the files.
                    deferred_lines.append((match.line, match.level))

                if len(buffered_lines) >= QUEUE_CHUNK_SIZE:
                    self.result_queue.put(("lines", buffered_lines.copy()))
                    buffered_lines.clear()

            if buffered_lines:
                self.result_queue.put(("lines", buffered_lines.copy()))

            self.result_queue.put(
                (
                    "done",
                    {
                        "total_matches": total_matches,
                        "rendered_lines": rendered_lines,
                        "file_count": len(selected_files),
                        "pending_lines": deferred_lines,
                    },
                )
            )
        except Exception as error:
            LOGGER.exception("Failed while loading logs")
            self.result_queue.put(("error", error))

    def _drain_result_queue(self) -> None:
        keep_polling = self.is_loading
        processed_messages = 0

        while True:
            if self._should_pause_queue_drain(processed_messages):
                break

            try:
                message_type, payload = self.result_queue.get_nowait()
            except Empty:
                break

            processed_messages += 1
            if message_type == "lines":
                self.current_loaded_lines.extend(payload)
                self._append_lines(payload, highlight_search=self.search_highlight_mode == "all")
                self.log_output.see(tk.END)
            elif message_type == "done":
                summary = payload
                total_matches = summary["total_matches"]
                rendered_lines = summary["rendered_lines"]
                file_count = summary["file_count"]
                self.pending_render_lines = summary["pending_lines"]
                self.all_match_lines = self.current_loaded_lines + self.pending_render_lines
                self.render_window_start = 0
                self.render_window_end = rendered_lines
                self.rendered_line_count = rendered_lines
                self.total_match_count = total_matches

                self._update_load_more_buttons()
                self._update_status(file_count)
                LOGGER.info(
                    "Finished loading %s matching lines from %s file(s); %s line(s) rendered",
                    total_matches,
                    file_count,
                    rendered_lines,
                )
                self._finish_loading()
                keep_polling = False
            elif message_type == "error":
                messagebox.showerror("Loading error", str(payload))
                self.status_var.set("Loading failed. See ./log for details.")
                self._finish_loading()
                keep_polling = False

        if keep_polling:
            self.root.after(50, self._drain_result_queue)

    def _finish_loading(self) -> None:
        self.is_loading = False
        self._set_loading_indicator_visible(False)
        self.load_button.configure(state=tk.NORMAL)
        self._apply_theme()
        self._update_scrollbar_visibility()

    def _load_previous_lines(self) -> None:
        if self.is_loading or self.render_window_start <= 0:
            return

        page_size = self._get_render_limit()
        self.render_window_start = max(0, self.render_window_start - page_size)
        self.render_window_end = min(len(self.all_match_lines), self.render_window_start + page_size)
        self.rendered_line_count = self.render_window_end - self.render_window_start
        self._render_current_window()
        self.log_output.see("1.0")
        self._update_load_more_buttons()
        self._update_status()

    def _load_next_lines(self) -> None:
        if self.is_loading or self.render_window_end >= len(self.all_match_lines):
            return

        page_size = self._get_render_limit()
        self.render_window_start = min(
            self.render_window_start + page_size,
            max(0, len(self.all_match_lines) - page_size),
        )
        self.render_window_end = min(len(self.all_match_lines), self.render_window_start + page_size)
        self.rendered_line_count = self.render_window_end - self.render_window_start
        self._render_current_window()
        self.log_output.see(tk.END)
        self._update_load_more_buttons()
        self._update_status()

    def _update_load_more_buttons(self) -> None:
        previous_lines_available = self.render_window_start
        next_lines_available = max(0, len(self.all_match_lines) - self.render_window_end)
        page_size = self._get_render_limit()

        if previous_lines_available > 0:
            previous_batch_size = min(page_size, previous_lines_available)
            self.top_load_more_button.configure(
                state=tk.NORMAL,
                text=f"^ Load previous ({previous_batch_size})",
            )
        else:
            self.top_load_more_button.configure(state=tk.DISABLED, text="^ Load previous")

        if next_lines_available > 0:
            next_batch_size = min(page_size, next_lines_available)
            self.bottom_load_more_button.configure(
                state=tk.NORMAL,
                text=f"v Load more ({next_batch_size})",
            )
            return

        self.bottom_load_more_button.configure(state=tk.DISABLED, text="v Load more")

    def _render_current_window(self) -> None:
        self.log_output.delete("1.0", tk.END)
        self._append_lines(self.all_match_lines[self.render_window_start : self.render_window_end])
        self._refresh_visible_search_highlights()
        self._update_scrollbar_visibility()

    def _update_status(self, file_count: int | None = None) -> None:
        if self.total_match_count == 0:
            status_text = "No matching lines were found."
            if self.active_search_filter:
                status_text += (
                    f" Active text filter: '{self.active_search_filter}'. "
                    f"Found {self._get_active_search_match_count()} occurrence(s) in the selected time range."
                )
            self.status_var.set(status_text)
            return

        first_visible_line = self.render_window_start + 1
        last_visible_line = self.render_window_end
        rendered_text = (
            f"Showing lines {first_visible_line}-{last_visible_line} of {self.total_match_count} matching lines"
        )
        if file_count is not None:
            rendered_text += f" from {file_count} file(s)"

        previous_lines_available = self.render_window_start
        next_lines_available = max(0, len(self.all_match_lines) - self.render_window_end)
        if previous_lines_available or next_lines_available:
            rendered_text += (
                f". {previous_lines_available} earlier line(s) and {next_lines_available} later line(s) are ready to load"
            )

        if self.active_search_filter:
            rendered_text += (
                f" Active text filter: '{self.active_search_filter}'. "
                f"Found {self._get_active_search_match_count()} occurrence(s) in the selected time range."
            )

        self.status_var.set(rendered_text + ".")

    def _append_lines(self, lines: list[tuple[str, str | None]], highlight_search: bool = False) -> None:
        for line, level in lines:
            start_index = self.log_output.index("end-1c")
            self.log_output.insert(tk.END, f"{line}\n")
            end_index = self.log_output.index("end-1c")
            self._highlight_level(start_index, end_index, level)
            if highlight_search:
                self._highlight_search_term(start_index, line)

    def _highlight_level(self, start_index: str, end_index: str, level: str | None) -> None:
        if level is None:
            return

        level_marker = f"DEBUG {level}:"
        start_offset = self._find_casefold_index(
            self.log_output.get(start_index, end_index),
            level_marker,
        )
        if start_offset < 0:
            return

        tag_start = f"{start_index}+{start_offset + 6}c"
        tag_end = f"{tag_start}+{len(level)}c"
        self.log_output.tag_add(level, tag_start, tag_end)

    def _highlight_search_term(self, start_index: str, line: str) -> None:
        search_term = self.search_var.get().strip()
        if not search_term:
            return

        search_pattern = compile_search_pattern(search_term)
        if search_pattern is None:
            return

        # Flexible whitespace matching keeps phrase searches usable with uneven spacing in log lines.
        for match in search_pattern.finditer(line):
            tag_start = f"{start_index}+{match.start()}c"
            tag_end = f"{start_index}+{match.end()}c"
            self.log_output.tag_add(SEARCH_TAG_NAME, tag_start, tag_end)

    def _find_casefold_index(self, text: str, needle: str) -> int:
        return text.casefold().find(needle.casefold())

    def _build_selected_datetime(
        self,
        selected_date: date,
        hour_value: str,
        minute_value: str,
    ) -> datetime:
        hour = int(hour_value)
        minute = int(minute_value)
        if hour < 0 or hour > 23 or minute < 0 or minute > 59:
            raise ValueError("Invalid time selection")
        return datetime(
            year=selected_date.year,
            month=selected_date.month,
            day=selected_date.day,
            hour=hour,
            minute=minute,
        )

    def _close_application(self) -> None:
        if self.drop_target is not None:
            self.drop_target.detach()
        self.root.destroy()


def run() -> None:
    root = tk.Tk()
    app = LogViewerApp(root)
    app.load_logs()
    root.mainloop()
