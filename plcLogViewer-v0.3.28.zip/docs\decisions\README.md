# Decisions

This directory stores architecture decision records for changes that need explicit technical reasoning.
