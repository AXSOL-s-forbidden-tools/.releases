from __future__ import annotations

from dataclasses import dataclass
import re


@dataclass(frozen=True)
class SearchMatchLocation:
    line_index: int
    start_offset: int
    end_offset: int


def find_search_matches(lines: list[tuple[str, str | None]], pattern: re.Pattern[str] | None) -> list[SearchMatchLocation]:
    if pattern is None:
        return []

    matches: list[SearchMatchLocation] = []
    for line_index, (line_text, _level) in enumerate(lines):
        for match in pattern.finditer(line_text):
            matches.append(
                SearchMatchLocation(
                    line_index=line_index,
                    start_offset=match.start(),
                    end_offset=match.end(),
                )
            )
    return matches


def build_render_window_for_line(line_index: int, page_size: int, total_lines: int) -> tuple[int, int]:
    if total_lines <= 0:
        return 0, 0

    safe_page_size = max(1, page_size)
    window_start = (line_index // safe_page_size) * safe_page_size
    window_end = min(total_lines, window_start + safe_page_size)
    return window_start, window_end
