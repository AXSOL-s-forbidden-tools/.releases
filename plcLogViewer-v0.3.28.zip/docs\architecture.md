# Architecture

## Overview

PLC Log Viewer is a local desktop application built with Python and `tkinter`. It reads log files from a working directory, selects the files that overlap a chosen time window, and streams matching lines into the user interface.

```mermaid
flowchart TD
  A[User selects directory and filters] --> B[GUI controller]
  A --> K[Calendar and time selectors]
  A --> L[Windows folder drag and drop]
  B --> C[Log file scanner]
  C --> D[Time range file selection]
  D --> E[Streaming line reader]
  E --> F[Level and text filters]
  F --> G[Background worker queue]
  G --> H[Rendered output in viewer]
  B --> I[Application logger]
  I --> J[Daily files in ./log]
```

## Main Modules

- `app.py`: application entry point
- `functions/app_logging.py`: application logging and log folder cleanup
- `functions/date_picker.py`: calendar dialog for date selection
- `functions/gui.py`: user interface, filter handling, theme switching
- `functions/log_parser.py`: filename parsing, timestamp parsing, level detection
- `functions/log_reader.py`: file discovery, time window selection, streaming match iteration
- `functions/theme.py`: light and dark theme definitions
- `functions/windows_dragdrop.py`: native Windows folder drop support

## Data Flow

1. The GUI reads the selected folder and time range from dedicated controls.
2. The scanner identifies supported log files by their file names.
3. The reader picks only files that can overlap the selected time window.
4. Each selected file is processed line by line.
5. Matching lines are filtered by timestamp, level, and the active `Find all` text filter.
6. The worker thread passes chunks of matching lines back to the GUI through a queue.
7. The GUI appends the initial chunks to the text view without blocking the window, keeps all matching lines available for previous and next block navigation, applies tag-based highlights, and can rebuild visible search highlights without reloading files.
