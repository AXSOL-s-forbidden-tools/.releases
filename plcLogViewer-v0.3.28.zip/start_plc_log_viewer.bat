@echo off
setlocal EnableExtensions

set "ROOT_DIR=%~dp0"
cd /d "%ROOT_DIR%"

set "PYTHON_VERSION=3.13.5"
set "PYTHON_INSTALLER=%TEMP%\plcLogViewer-python-installer.exe"
set "LOCAL_RUNTIME_DIR=%ROOT_DIR%.venv\python-runtime"
set "LOCAL_RUNTIME_PYTHON=%LOCAL_RUNTIME_DIR%\python.exe"
set "LEGACY_VENV_DIR=%ROOT_DIR%.venv"
set "LEGACY_VENV_PYTHON=%LEGACY_VENV_DIR%\Scripts\python.exe"
set "LEGACY_VENV_PYTHONW=%LEGACY_VENV_DIR%\Scripts\pythonw.exe"
set "APP_ENV_DIR=%ROOT_DIR%.venv\app-env"
set "APP_ENV_PYTHON=%APP_ENV_DIR%\Scripts\python.exe"
set "APP_ENV_PYTHONW=%APP_ENV_DIR%\Scripts\pythonw.exe"

if exist "%LEGACY_VENV_PYTHON%" (
    set "VENV_DIR=%LEGACY_VENV_DIR%"
    set "VENV_PYTHON=%LEGACY_VENV_PYTHON%"
    set "VENV_PYTHONW=%LEGACY_VENV_PYTHONW%"
) else (
    set "VENV_DIR=%APP_ENV_DIR%"
    set "VENV_PYTHON=%APP_ENV_PYTHON%"
    set "VENV_PYTHONW=%APP_ENV_PYTHONW%"
)

call :detect_bootstrap_python
if errorlevel 1 (
    pause
    exit /b 1
)

if not exist "%VENV_PYTHON%" (
    echo Creating local virtual environment in "%VENV_DIR%" ...
    %BOOTSTRAP_PYTHON% -m venv "%VENV_DIR%"
    if errorlevel 1 (
        echo Failed to create the local virtual environment.
        pause
        exit /b 1
    )
)

echo Preparing local environment ...
"%VENV_PYTHON%" -m pip install --upgrade pip >nul
if errorlevel 1 (
    echo Continuing with the existing pip version.
)
if exist "%ROOT_DIR%requirements.txt" (
    "%VENV_PYTHON%" -m pip install -r "%ROOT_DIR%requirements.txt"
    if errorlevel 1 (
        echo Failed to install local requirements.
        pause
        exit /b 1
    )
)

echo Starting PLC Log Viewer ...
if exist "%VENV_PYTHONW%" (
    start "" "%VENV_PYTHONW%" "%ROOT_DIR%app.py"
) else (
    start "" "%VENV_PYTHON%" "%ROOT_DIR%app.py"
)
endlocal
exit /b 0

:detect_bootstrap_python
where py >nul 2>nul
if %errorlevel%==0 (
    set "BOOTSTRAP_PYTHON=py -3"
    exit /b 0
)

where python >nul 2>nul
if %errorlevel%==0 (
    set "BOOTSTRAP_PYTHON=python"
    exit /b 0
)

if exist "%LOCAL_RUNTIME_PYTHON%" (
    set "BOOTSTRAP_PYTHON=%LOCAL_RUNTIME_PYTHON%"
    exit /b 0
)

call :install_local_python
if errorlevel 1 (
    exit /b 1
)

set "BOOTSTRAP_PYTHON=%LOCAL_RUNTIME_PYTHON%"
exit /b 0

:install_local_python
echo Python 3 was not found on this computer.
echo Installing a local Python runtime into ".venv" ...

if /I "%PROCESSOR_ARCHITECTURE%"=="ARM64" (
    set "PYTHON_DOWNLOAD_URL=https://www.python.org/ftp/python/%PYTHON_VERSION%/python-%PYTHON_VERSION%-arm64.exe"
) else (
    set "PYTHON_DOWNLOAD_URL=https://www.python.org/ftp/python/%PYTHON_VERSION%/python-%PYTHON_VERSION%-amd64.exe"
)

if not exist "%ROOT_DIR%.venv" (
    mkdir "%ROOT_DIR%.venv"
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference = 'SilentlyContinue'; Invoke-WebRequest -Uri '%PYTHON_DOWNLOAD_URL%' -OutFile '%PYTHON_INSTALLER%'"
if errorlevel 1 (
    echo Failed to download the local Python installer.
    exit /b 1
)

"%PYTHON_INSTALLER%" /quiet InstallAllUsers=0 PrependPath=0 Include_launcher=0 Include_test=0 Include_doc=0 Include_pip=1 Include_tcltk=1 Include_venv=1 Shortcuts=0 SimpleInstall=1 TargetDir="%LOCAL_RUNTIME_DIR%"
if errorlevel 1 (
    if exist "%PYTHON_INSTALLER%" del /q "%PYTHON_INSTALLER%"
    echo Failed to install the local Python runtime.
    exit /b 1
)

if exist "%PYTHON_INSTALLER%" del /q "%PYTHON_INSTALLER%"

if not exist "%LOCAL_RUNTIME_PYTHON%" (
    echo The local Python runtime was installed, but python.exe was not found.
    exit /b 1
)

exit /b 0
