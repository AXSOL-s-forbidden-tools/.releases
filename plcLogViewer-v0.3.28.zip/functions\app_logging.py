from __future__ import annotations

from datetime import datetime
import logging
from pathlib import Path

LOG_DIRECTORY_NAME = "log"
MAX_LOG_DIRECTORY_SIZE_BYTES = 250 * 1024 * 1024
TARGET_LOG_DIRECTORY_SIZE_BYTES = 150 * 1024 * 1024


def configure_application_logging() -> Path:
    log_directory = Path.cwd() / LOG_DIRECTORY_NAME
    log_directory.mkdir(exist_ok=True)
    shrink_log_directory_if_needed(log_directory)

    log_file = log_directory / f"{datetime.now():%Y-%m-%d}.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        handlers=[
            logging.FileHandler(log_file, encoding="utf-8"),
            logging.StreamHandler(),
        ],
        force=True,
    )
    logging.getLogger(__name__).info("Application logging initialized in %s", log_file)
    return log_directory


def shrink_log_directory_if_needed(log_directory: Path) -> None:
    log_files = sorted(
        (path for path in log_directory.glob("*.log") if path.is_file()),
        key=lambda path: path.stat().st_mtime,
    )
    total_size = sum(path.stat().st_size for path in log_files)
    if total_size <= MAX_LOG_DIRECTORY_SIZE_BYTES:
        return

    for log_file in log_files:
        total_size -= log_file.stat().st_size
        log_file.unlink(missing_ok=True)
        if total_size < TARGET_LOG_DIRECTORY_SIZE_BYTES:
            break
