from __future__ import annotations

import calendar
import re
from datetime import datetime
from pathlib import Path

from functions.log_models import LogFileInfo

MONTH_LOOKUP = {name: index for index, name in enumerate(calendar.month_abbr) if name}
HOURLY_FILE_PATTERNS = (
    re.compile(r"^(?P<date>\d{8})_(?P<hour>\d{4})_runtimelog\.log$"),
    re.compile(r"^(?P<date>\d{8})_(?P<hour>\d{4})_runtime\.log$"),
)
LIVE_FILE_PATTERN = re.compile(r"^(?P<date>\d{8})_runtimelog_live\.log$")
LINE_PATTERN = re.compile(
    r"^(?P<month>[A-Z][a-z]{2})\s+(?P<day>\d{1,2})\s+"
    r"(?P<time>\d{2}:\d{2}:\d{2})\s+(?P<rest>.*)$"
)
LEVEL_PATTERN = re.compile(r"\bDEBUG\s+(INF|WRN|ERR):")


def parse_log_file_name(path: Path) -> LogFileInfo | None:
    for pattern in HOURLY_FILE_PATTERNS:
        hourly_match = pattern.match(path.name)
        if hourly_match:
            return LogFileInfo(
                path=path,
                start=datetime.strptime(
                    f"{hourly_match.group('date')}{hourly_match.group('hour')}",
                    "%Y%m%d%H%M",
                ),
            )

    live_match = LIVE_FILE_PATTERN.match(path.name)
    if live_match:
        return LogFileInfo(
            path=path,
            start=datetime.strptime(live_match.group("date"), "%Y%m%d"),
            is_live_log=True,
        )

    return None


def parse_line_timestamp(line: str, default_year: int) -> datetime | None:
    line_match = LINE_PATTERN.match(line)
    if not line_match:
        return None

    month = MONTH_LOOKUP.get(line_match.group("month"))
    if month is None:
        return None

    try:
        return datetime.strptime(
            f"{default_year}-{month:02d}-{int(line_match.group('day')):02d} {line_match.group('time')}",
            "%Y-%m-%d %H:%M:%S",
        )
    except ValueError:
        return None


def detect_level(line: str) -> str | None:
    match = LEVEL_PATTERN.search(line)
    if not match:
        return None
    return match.group(1)
