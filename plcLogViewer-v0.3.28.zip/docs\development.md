# Development

## Local Development

1. For the standard workflow on Windows, start the application with:

```powershell
start_plc_log_viewer.bat
```

2. The launcher creates `.venv` automatically and, if needed, also installs a local Python runtime into `.venv\python-runtime`.
3. For direct development runs, you can also use a system Python installation or the local environment created by the batch file:

```powershell
python app.py
```

4. For a local release package dry run without publishing to GitHub, use:

```powershell
powershell -ExecutionPolicy Bypass -File .\release\publish_release.ps1 -SkipGitHubRelease
```

## Project Structure

- `app.py`: application start file
- `functions/`: reusable application logic
- `log/`: runtime application logs, created on demand
- `release/`: packaged release artifacts and the release publishing script
- `docs/`: project documentation
- `testdata/`: sample PLC log files for local checks

## Verification

- Run the application and open the sample folder `testdata/`.
- Confirm that the default range loads matching entries from the sample files.
- Test the level filters with `INF`, `WRN`, and `ERR`.
- Test a custom text filter such as `Undervoltage` with `Enter` or `Find all`.
- Test a multi-word search such as `Value for Watchdog` and confirm it still matches when the log line spacing is uneven.
- Confirm that `Find all` still highlights all visible matches after the filtered result has been reloaded.
- Confirm that the status bar shows the total occurrence count for the active `Find all` search term.
- Confirm that `Find all` keeps the UI responsive while many highlighted result batches are still streaming in.
- Confirm that `Go to first`, `Find previous`, `Find next`, and `Go to last` jump through custom text matches without changing the loaded result set.
- Confirm that search navigation still reaches matches outside the currently rendered block.
- Confirm that the navigation buttons highlight only the active match and that `Find all` highlights all visible matches.
- Confirm that `Go to first` and `Go to last` also work when the search term is only typed into the field and the logs were not reloaded with `Find all`.
- Confirm that `Clear all filters` resets the search field and all level filters.
- Reduce the window width and confirm that a horizontal scrollbar appears for long log lines.
- Confirm that both scrollbars stay hidden when the current content fits into the visible area.
- Confirm that a running loading indicator is visible while background log loading is still in progress.
- Confirm that the loading indicator keeps animating during long searches across many result batches.
- Confirm that the loading indicator also keeps animating during long scans before the first visible search matches arrive.
- Confirm that the loading indicator becomes visible immediately after pressing `Find all`.
- Confirm that the top centered button switches to an earlier block and the bottom centered button switches to a later block.
- Test the calendar buttons and the hour/minute fields for start and end selection.
- On Windows, test dropping a folder into the main window to change the working directory.
- Switch between light mode and dark mode and confirm that the combobox dropdown list updates with the selected theme.
- Confirm that `./log/<date>.log` is created on startup.
- Confirm that `start_plc_log_viewer.bat` creates `.venv` automatically if it does not exist.
- Confirm that `start_plc_log_viewer.bat` downloads and installs a local Python runtime into `.venv\python-runtime` when no system Python installation is available.
- Run the release script with `-SkipGitHubRelease` and confirm that a versioned ZIP file is created in `./release`.
