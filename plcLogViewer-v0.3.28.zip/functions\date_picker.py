from __future__ import annotations

import calendar
from dataclasses import dataclass
from datetime import date
import tkinter as tk


@dataclass(frozen=True)
class CalendarTheme:
    background: str
    panel: str
    text: str
    accent: str
    button_background: str
    button_foreground: str
    muted_text: str


class DatePickerDialog(tk.Toplevel):
    def __init__(
        self,
        parent: tk.Misc,
        initial_date: date,
        theme: CalendarTheme,
    ) -> None:
        super().__init__(parent)
        self.title("Select Date")
        self.resizable(False, False)
        self.configure(bg=theme.background)
        self.transient(parent.winfo_toplevel())
        self.grab_set()

        self._theme = theme
        self._selected_date: date | None = None
        self._visible_year = initial_date.year
        self._visible_month = initial_date.month
        self._initial_date = initial_date

        self._header = tk.Frame(self, bg=theme.background, padx=12, pady=12)
        self._header.grid(row=0, column=0, sticky="ew")
        self._calendar_frame = tk.Frame(self, bg=theme.panel, padx=12, pady=12)
        self._calendar_frame.grid(row=1, column=0, sticky="nsew", padx=12, pady=(0, 12))
        self._footer = tk.Frame(self, bg=theme.background, padx=12, pady=12)
        self._footer.grid(row=2, column=0, sticky="ew")

        self._month_label = tk.Label(
            self._header,
            bg=theme.background,
            fg=theme.text,
            font=("Segoe UI", 10, "bold"),
        )
        tk.Button(
            self._header,
            text="<",
            command=lambda: self._change_month(-1),
            bg=theme.button_background,
            fg=theme.button_foreground,
            relief=tk.FLAT,
            width=3,
        ).grid(row=0, column=0, padx=(0, 8))
        self._month_label.grid(row=0, column=1, padx=8)
        tk.Button(
            self._header,
            text=">",
            command=lambda: self._change_month(1),
            bg=theme.button_background,
            fg=theme.button_foreground,
            relief=tk.FLAT,
            width=3,
        ).grid(row=0, column=2, padx=(8, 0))

        tk.Button(
            self._footer,
            text="Cancel",
            command=self._cancel,
            bg=theme.button_background,
            fg=theme.button_foreground,
            relief=tk.FLAT,
            width=10,
        ).pack(side="right")

        self._render_calendar()
        self.bind("<Escape>", lambda _event: self._cancel())

    def _change_month(self, offset: int) -> None:
        new_month = self._visible_month + offset
        new_year = self._visible_year
        if new_month < 1:
            new_month = 12
            new_year -= 1
        elif new_month > 12:
            new_month = 1
            new_year += 1

        self._visible_year = new_year
        self._visible_month = new_month
        self._render_calendar()

    def _render_calendar(self) -> None:
        for child in self._calendar_frame.winfo_children():
            child.destroy()

        self._month_label.configure(
            text=f"{calendar.month_name[self._visible_month]} {self._visible_year}"
        )

        for column, weekday_name in enumerate(("Mo", "Tu", "We", "Th", "Fr", "Sa", "Su")):
            tk.Label(
                self._calendar_frame,
                text=weekday_name,
                bg=self._theme.panel,
                fg=self._theme.muted_text,
                width=4,
                pady=4,
            ).grid(row=0, column=column, padx=2, pady=2)

        month_matrix = calendar.Calendar(firstweekday=0).monthdayscalendar(
            self._visible_year,
            self._visible_month,
        )
        for row_index, week in enumerate(month_matrix, start=1):
            for column_index, day_number in enumerate(week):
                if day_number == 0:
                    tk.Label(
                        self._calendar_frame,
                        text="",
                        bg=self._theme.panel,
                        width=4,
                    ).grid(row=row_index, column=column_index, padx=2, pady=2)
                    continue

                current_date = date(self._visible_year, self._visible_month, day_number)
                is_initial = current_date == self._initial_date
                tk.Button(
                    self._calendar_frame,
                    text=str(day_number),
                    command=lambda chosen=current_date: self._select_date(chosen),
                    bg=self._theme.accent if is_initial else self._theme.button_background,
                    fg=self._theme.background if is_initial else self._theme.button_foreground,
                    activebackground=self._theme.accent,
                    activeforeground=self._theme.background,
                    relief=tk.FLAT,
                    width=4,
                    pady=4,
                ).grid(row=row_index, column=column_index, padx=2, pady=2)

    def _select_date(self, selected_date: date) -> None:
        self._selected_date = selected_date
        self.destroy()

    def _cancel(self) -> None:
        self._selected_date = None
        self.destroy()

    def show(self) -> date | None:
        self.wait_window()
        return self._selected_date
