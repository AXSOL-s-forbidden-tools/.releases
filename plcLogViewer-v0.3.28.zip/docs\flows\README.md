# Flows

This directory stores important runtime or user interaction flows when the project needs more detailed documentation.
