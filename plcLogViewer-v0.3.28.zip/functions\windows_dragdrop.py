from __future__ import annotations

import ctypes
from ctypes import wintypes
from queue import Empty, SimpleQueue
import logging
from pathlib import Path
import sys
import tkinter as tk
from typing import Callable

WM_DROPFILES = 0x0233
GWL_WNDPROC = -4
LRESULT = ctypes.c_ssize_t
WPARAM = ctypes.c_size_t
LPARAM = ctypes.c_ssize_t
LONG_PTR = ctypes.c_ssize_t
LOGGER = logging.getLogger(__name__)


class WindowsDirectoryDropTarget:
    def __init__(self, widget: tk.Misc, on_drop: Callable[[Path], None]) -> None:
        if sys.platform != "win32":
            raise RuntimeError("Windows drag and drop is only available on Windows.")

        self._widget = widget
        self._on_drop = on_drop
        self._pending_directories: SimpleQueue[Path] = SimpleQueue()
        self._shell32 = ctypes.windll.shell32
        self._user32 = ctypes.windll.user32
        self._shell32.DragQueryFileW.argtypes = [ctypes.c_void_p, wintypes.UINT, wintypes.LPWSTR, wintypes.UINT]
        self._shell32.DragQueryFileW.restype = wintypes.UINT
        self._shell32.DragFinish.argtypes = [ctypes.c_void_p]
        self._shell32.DragFinish.restype = None
        self._user32.SetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_void_p]
        self._user32.SetWindowLongPtrW.restype = ctypes.c_void_p
        self._user32.CallWindowProcW.argtypes = [ctypes.c_void_p, wintypes.HWND, wintypes.UINT, WPARAM, LPARAM]
        self._user32.CallWindowProcW.restype = LRESULT
        self._wndproc_type = ctypes.WINFUNCTYPE(
            LRESULT,
            wintypes.HWND,
            wintypes.UINT,
            WPARAM,
            LPARAM,
        )
        self._window_handle = widget.winfo_id()
        self._callback = self._wndproc_type(self._window_proc)
        self._original_wndproc = ctypes.cast(
            self._user32.SetWindowLongPtrW(
                self._window_handle,
                GWL_WNDPROC,
                self._callback,
            ),
            ctypes.c_void_p,
        )
        self._shell32.DragAcceptFiles(self._window_handle, True)
        LOGGER.info("Windows drag and drop enabled for window handle %s", self._window_handle)

    def _window_proc(self, hwnd: int, msg: int, wparam: int, lparam: int) -> int:
        try:
            if msg == WM_DROPFILES:
                LOGGER.info("Received WM_DROPFILES message for window handle %s", hwnd)
                self._handle_drop(wparam)
                return 0
        except Exception:
            LOGGER.exception("Failed to process dropped files")
            return 0

        return self._user32.CallWindowProcW(self._original_wndproc, hwnd, msg, wparam, lparam)

    def _handle_drop(self, drop_handle: int) -> None:
        drop_handle_pointer = ctypes.c_void_p(drop_handle)
        try:
            file_count = self._shell32.DragQueryFileW(drop_handle_pointer, 0xFFFFFFFF, None, 0)
            LOGGER.info("Drop event contains %s item(s)", file_count)
            for index in range(file_count):
                buffer_length = self._shell32.DragQueryFileW(drop_handle_pointer, index, None, 0) + 1
                path_buffer = ctypes.create_unicode_buffer(buffer_length)
                self._shell32.DragQueryFileW(drop_handle_pointer, index, path_buffer, buffer_length)
                dropped_path = Path(path_buffer.value)
                LOGGER.info("Dropped path candidate: %s", dropped_path)
                if dropped_path.is_dir():
                    self._pending_directories.put(dropped_path)
                    LOGGER.info("Queued dropped directory for GUI processing: %s", dropped_path)
                    break
            else:
                LOGGER.warning("Drop event did not contain a directory path")
        finally:
            self._shell32.DragFinish(drop_handle_pointer)

    def dispatch_pending_drops(self) -> None:
        while True:
            try:
                dropped_path = self._pending_directories.get_nowait()
            except Empty:
                return

            try:
                LOGGER.info("Dispatching dropped directory to GUI: %s", dropped_path)
                self._on_drop(dropped_path)
            except Exception:
                LOGGER.exception("Failed while applying dropped directory in GUI")

    def detach(self) -> None:
        self._shell32.DragAcceptFiles(self._window_handle, False)
        self._user32.SetWindowLongPtrW(
            self._window_handle,
            GWL_WNDPROC,
            self._original_wndproc,
        )
        LOGGER.info("Windows drag and drop disabled for window handle %s", self._window_handle)
