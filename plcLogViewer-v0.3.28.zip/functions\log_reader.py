from __future__ import annotations

from collections.abc import Callable, Iterable, Iterator
from datetime import datetime
from pathlib import Path
import re

from functions.log_models import LogFileInfo, LogMatch
from functions.log_parser import detect_level, parse_line_timestamp, parse_log_file_name

TEXT_FILE_EXTENSIONS = {".log", ".txt"}
WHITESPACE_PATTERN = re.compile(r"\s+")


def scan_log_files(directory: Path) -> list[LogFileInfo]:
    candidates: list[LogFileInfo] = []
    for path in sorted(directory.iterdir()):
        if not path.is_file():
            continue
        if path.suffix.lower() not in TEXT_FILE_EXTENSIONS:
            continue
        file_info = parse_log_file_name(path)
        if file_info is not None:
            candidates.append(file_info)
    return sorted(candidates, key=lambda item: (item.start, item.path.name))


def pick_log_files(
    files: Iterable[LogFileInfo], start_time: datetime, end_time: datetime
) -> list[LogFileInfo]:
    selected: list[LogFileInfo] = []
    for file_info in files:
        if file_info.is_live_log:
            if file_info.start.date() <= end_time.date():
                selected.append(file_info)
            continue

        file_end = file_info.start.replace(minute=59, second=59)
        if file_end < start_time or file_info.start > end_time:
            continue
        selected.append(file_info)
    return selected


def iter_matching_lines(
    files: Iterable[LogFileInfo],
    start_time: datetime,
    end_time: datetime,
    include_info: bool,
    include_warning: bool,
    include_error: bool,
    search_term: str,
    progress_callback: Callable[[], None] | None = None,
    progress_interval: int = 0,
) -> Iterator[LogMatch]:
    search_pattern = compile_search_pattern(search_term)
    allowed_levels = {
        level
        for level, enabled in (
            ("INF", include_info),
            ("WRN", include_warning),
            ("ERR", include_error),
        )
        if enabled
    }

    for file_info in files:
        default_year = file_info.start.year
        processed_lines = 0
        with file_info.path.open("r", encoding="utf-8", errors="replace") as handle:
            for line in handle:
                processed_lines += 1
                if (
                    progress_callback is not None
                    and progress_interval > 0
                    and processed_lines % progress_interval == 0
                ):
                    progress_callback()

                timestamp = parse_line_timestamp(line, default_year)
                if timestamp is not None and (timestamp < start_time or timestamp > end_time):
                    continue

                level = detect_level(line)
                if allowed_levels and level not in allowed_levels:
                    continue

                if search_pattern is not None and search_pattern.search(line) is None:
                    continue

                yield LogMatch(
                    timestamp=timestamp,
                    level=level,
                    line=line.rstrip("\n"),
                    source=file_info.path,
                )


def compile_search_pattern(search_term: str) -> re.Pattern[str] | None:
    tokens = [token for token in WHITESPACE_PATTERN.split(search_term.strip()) if token]
    if not tokens:
        return None
    return re.compile(r"\s+".join(re.escape(token) for token in tokens), re.IGNORECASE)
