LIGHT_THEME = {
    "name": "Light",
    "background": "#f4f6f8",
    "panel": "#ffffff",
    "text": "#182026",
    "muted_text": "#52606d",
    "accent": "#0b6e4f",
    "input_background": "#ffffff",
    "input_foreground": "#182026",
    "log_background": "#ffffff",
    "log_foreground": "#182026",
    "button_background": "#dfe7ec",
    "button_foreground": "#182026",
}

DARK_THEME = {
    "name": "Dark",
    "background": "#1e252c",
    "panel": "#2a333d",
    "text": "#edf2f7",
    "muted_text": "#b1c0cf",
    "accent": "#67d5cb",
    "input_background": "#34424d",
    "input_foreground": "#edf2f7",
    "log_background": "#202930",
    "log_foreground": "#edf2f7",
    "button_background": "#415363",
    "button_foreground": "#edf2f7",
}
