import logging

from functions.app_logging import configure_application_logging
from functions.gui import run


if __name__ == "__main__":
    configure_application_logging()
    try:
        run()
    except Exception:
        logging.getLogger(__name__).exception("Application startup failed")
        raise
