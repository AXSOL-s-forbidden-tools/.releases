from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path


@dataclass(frozen=True)
class LogFileInfo:
    path: Path
    start: datetime
    is_live_log: bool = False


@dataclass(frozen=True)
class LogMatch:
    timestamp: datetime | None
    level: str | None
    line: str
    source: Path
