# PLC Log Viewer

PLC Log Viewer is a lightweight desktop tool for browsing runtime log files from a PLC logging folder. It combines hourly log files across a selected time range, supports level-based and free-text filtering, and keeps memory usage predictable by streaming files line by line.

## Features

- View runtime logs from a chosen working directory
- Combine multiple hourly log files into one filtered result
- Filter by PLC log levels `INF`, `WRN`, and `ERR`
- Filter by custom search text with `Find all`
- Match multi-word search phrases even when log lines contain uneven whitespace
- Jump to the first, previous, next, or last custom text match across the entire loaded result
- Clear all active text and level filters with one button
- Choose start and end dates from an integrated calendar dialog
- Choose hours and minutes with dedicated time fields
- Choose how many matching lines should be rendered first
- Highlight custom search text directly in the log output
- Highlight `INF`, `WRN`, and `ERR` entries with colored boxes
- Handle very large log files because matching is processed as a stream
- Navigate to previous and next result blocks separately from centered buttons above and below the log view
- Use a horizontal scrollbar for long log lines
- Hide scrollbars until vertical or horizontal scrolling is actually needed
- Show a loading indicator while large files are still being processed in the background
- Keep the loading indicator responsive even while many result chunks are still arriving
- Keep the loading indicator moving during long file scans by yielding between worker batches
- Show the loading indicator immediately before the background search starts
- Switch between light mode and dark mode
- Start in dark mode by default
- Change the working directory by dragging a folder into the viewer on Windows
- Create and reuse a local `.venv` on startup through the Windows launcher script
- Download and install a local Python runtime into `.venv` automatically when no system Python is available
- Launch the GUI without leaving a console window open after startup
- Write application logs to `./log` with automatic size cleanup

## Setup

1. Clone or download this repository.
2. Start the project with the batch file.
3. The launcher creates a local `.venv` automatically.
4. If Python is not installed on the computer yet, the launcher downloads and installs a local Python runtime into `.venv\python-runtime`.
5. After startup, the batch file closes and leaves only the GUI application open.

## Commands

```powershell
start_plc_log_viewer.bat
```

```powershell
python app.py
```

```powershell
powershell -ExecutionPolicy Bypass -File .\release\publish_release.ps1 -SkipGitHubRelease
```

## Usage

1. Start the application with `start_plc_log_viewer.bat`.
2. Select the directory that contains your PLC log files.
3. Choose start and end dates with the `Date` buttons and adjust hours and minutes with the time fields.
4. Leave all level filters disabled if you want to see every log entry, or enable only the levels you want to include.
5. Optionally enter a free-text term and press `Enter` or click `Find all` to filter and highlight matching lines.
6. Enable or disable the `INF`, `WRN`, and `ERR` filters as needed.
7. You can also drag a working directory into the viewer window on Windows.
8. Choose the `Initial render` size that should be displayed first.
9. Click `Load Logs` to stream and display matching lines.
10. If more matches are available, use the top button to switch to earlier lines and the bottom button to switch to later lines.
11. Use `Go to first`, `Find previous`, `Find next`, or `Go to last` to move between custom text matches in the current loaded result without reloading the data.
12. Use `Clear all filters` to reset the text filter and all selected level filters.

## Release

1. Ensure that `gh` is installed and already authenticated for the target repository.
2. Update `VERSION` to the release version you want to publish.
3. Run the release script from the repository root:

```powershell
powershell -ExecutionPolicy Bypass -File .\release\publish_release.ps1
```

4. The script creates `./release/plcLogViewer-v<version>.zip`.
5. The script publishes or updates the GitHub release `v<version>` with the latest commit message as release notes and targets the current commit SHA.

For a local packaging test without publishing to GitHub, use:

```powershell
powershell -ExecutionPolicy Bypass -File .\release\publish_release.ps1 -SkipGitHubRelease
```

## Log File Naming

The viewer automatically detects these file names:

- `yyyymmdd_hh00_runtimelog.log`
- `yyyymmdd_hh00_runtime.log`
- `yyyymmdd_runtimelog_live.log`

## Notes

- The viewer looks for the effective log level in patterns such as `DEBUG INF:`, `DEBUG WRN:`, and `DEBUG ERR:`.
- `INF`, `WRN`, and `ERR` are highlighted with colored boxes.
- `Find all` filters the loaded logs by the current search term and highlights the matches.
- `Find all` keeps all visible matches highlighted after the filtered result is reloaded.
- The status bar shows how many occurrences the active `Find all` search term has in the selected time range.
- `Find all` applies highlights incrementally while result batches are appended so the UI stays responsive during large searches.
- Multi-word text searches treat whitespace flexibly so phrases still match when log lines contain repeated spaces.
- `Go to first`, `Find previous`, `Find next`, and `Go to last` search across the full loaded result, not only the currently visible render block.
- The navigation buttons highlight only the currently selected search match, while `Find all` highlights every visible match.
- `Clear all filters` resets the active text filter and all level filters before reloading the logs.
- The log view includes a horizontal scrollbar for long lines when the window becomes too narrow.
- Vertical and horizontal scrollbars stay hidden until the current content actually needs them.
- The status area shows a running loading indicator while background log processing is still active.
- Long-running searches process queued result batches in short UI-friendly bursts so the loading indicator keeps moving.
- Long file scans also yield control between worker batches so the loading indicator can keep pulsing during searches with few early matches.
- The loading indicator is painted once before the worker starts so the user gets immediate visual feedback.
- Highlight text colors adapt to light mode and dark mode for readability.
- The selected date and time stay readable in both light mode and dark mode.
- The combobox field and its dropdown list update automatically when the theme changes.
- The date selector opens as a built-in popup calendar.
- On startup, no level filter is enabled so the viewer shows all matching log entries.
- The viewer starts in dark mode by default.
- To keep the interface responsive, the text area renders only the selected block size and lets you move backward or forward through the matching lines in additional blocks.
- The application writes one log file per day to `./log`.
- On each startup, the `./log` directory is checked. If it grows beyond 250 MB, the oldest log files are deleted until the directory is below 150 MB.
- If the application fails during startup, the exception is also written to the daily log file.
- Drag-and-drop activity and related errors are also written to the daily log file.
- Dropped directories are processed through the normal GUI event loop to keep Windows drag-and-drop stable.
- If no system Python installation is available, the Windows launcher downloads the official Python installer and places a local runtime in `.venv\python-runtime`.
- The release script packages the required runtime files and can publish the matching GitHub release through `gh`.
